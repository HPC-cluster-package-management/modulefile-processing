-- -*- lua -*-
-- Module file created by spack (https://github.com/spack/spack) on 2019-09-16 14:06:32.773801
--
-- libxvmc@1.0.9%gcc@5.5.0 arch=linux-centos7-x86_64 /hrt7lmg
--

whatis([[Name : libxvmc]])
whatis([[Version : 1.0.9]])
whatis([[Short description : X.org libXvMC library.]])

help([[X.org libXvMC library.]])



prepend_path("LD_LIBRARY_PATH", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-5.5.0/libxvmc-1.0.9-hrt7lmgjwrcn4623dcd3we3a2iyjqjqr/lib", ":")
prepend_path("PKG_CONFIG_PATH", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-5.5.0/libxvmc-1.0.9-hrt7lmgjwrcn4623dcd3we3a2iyjqjqr/lib/pkgconfig", ":")
prepend_path("CMAKE_PREFIX_PATH", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-5.5.0/libxvmc-1.0.9-hrt7lmgjwrcn4623dcd3we3a2iyjqjqr/", ":")
setenv("LIBXVMC_ROOT", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-5.5.0/libxvmc-1.0.9-hrt7lmgjwrcn4623dcd3we3a2iyjqjqr")


-- -*- lua -*-
-- Module file created by spack (https://github.com/spack/spack) on 2019-09-16 14:25:54.447669
--
-- py-argparse@1.4.0%gcc@5.5.0 arch=linux-centos7-x86_64 /icwobd6
--

whatis([[Name : py-argparse]])
whatis([[Version : 1.4.0]])
whatis([[Short description : Python command-line parsing library.]])

help([[Python command-line parsing library.]])



prepend_path("LD_LIBRARY_PATH", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-5.5.0/py-argparse-1.4.0-icwobd62mnibuufni66zif7m3wgr5zqe/lib", ":")
prepend_path("CMAKE_PREFIX_PATH", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-5.5.0/py-argparse-1.4.0-icwobd62mnibuufni66zif7m3wgr5zqe/", ":")
prepend_path("PYTHONPATH", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-5.5.0/py-argparse-1.4.0-icwobd62mnibuufni66zif7m3wgr5zqe/lib/python2.7/site-packages", ":")
setenv("PY_ARGPARSE_ROOT", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-5.5.0/py-argparse-1.4.0-icwobd62mnibuufni66zif7m3wgr5zqe")


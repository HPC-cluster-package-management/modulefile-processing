-- -*- lua -*-
-- Module file created by spack (https://github.com/spack/spack) on 2019-09-16 13:41:04.799218
--
-- automake@1.16.1%gcc@5.5.0 arch=linux-centos7-x86_64 /otfffwo
--

whatis([[Name : automake]])
whatis([[Version : 1.16.1]])
whatis([[Short description : Automake -- make file builder part of autotools]])

help([[Automake -- make file builder part of autotools]])



prepend_path("PATH", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-5.5.0/automake-1.16.1-otfffwojkuz6savothi3oefhvd2ou6lk/bin", ":")
prepend_path("MANPATH", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-5.5.0/automake-1.16.1-otfffwojkuz6savothi3oefhvd2ou6lk/share/man", ":")
prepend_path("ACLOCAL_PATH", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-5.5.0/automake-1.16.1-otfffwojkuz6savothi3oefhvd2ou6lk/share/aclocal", ":")
prepend_path("CMAKE_PREFIX_PATH", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-5.5.0/automake-1.16.1-otfffwojkuz6savothi3oefhvd2ou6lk/", ":")
setenv("AUTOMAKE_ROOT", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-5.5.0/automake-1.16.1-otfffwojkuz6savothi3oefhvd2ou6lk")


-- -*- lua -*-
-- Module file created by spack (https://github.com/spack/spack) on 2019-09-16 13:59:59.662848
--
-- libtool@2.4.6%gcc@5.5.0 arch=linux-centos7-x86_64 /qmyakk6
--

whatis([[Name : libtool]])
whatis([[Version : 2.4.6]])
whatis([[Short description : libtool -- library building part of autotools.]])

help([[libtool -- library building part of autotools.]])



prepend_path("PATH", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-5.5.0/libtool-2.4.6-qmyakk6w2pgufe2ayzbwdso6swxhbbwk/bin", ":")
prepend_path("MANPATH", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-5.5.0/libtool-2.4.6-qmyakk6w2pgufe2ayzbwdso6swxhbbwk/share/man", ":")
prepend_path("ACLOCAL_PATH", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-5.5.0/libtool-2.4.6-qmyakk6w2pgufe2ayzbwdso6swxhbbwk/share/aclocal", ":")
prepend_path("LD_LIBRARY_PATH", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-5.5.0/libtool-2.4.6-qmyakk6w2pgufe2ayzbwdso6swxhbbwk/lib", ":")
prepend_path("CMAKE_PREFIX_PATH", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-5.5.0/libtool-2.4.6-qmyakk6w2pgufe2ayzbwdso6swxhbbwk/", ":")
setenv("LIBTOOL_ROOT", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-5.5.0/libtool-2.4.6-qmyakk6w2pgufe2ayzbwdso6swxhbbwk")


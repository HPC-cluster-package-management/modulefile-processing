-- -*- lua -*-
-- Module file created by spack (https://github.com/spack/spack) on 2019-09-16 13:41:06.418241
--
-- automake@1.16.1%gcc@7.2.0 arch=linux-centos7-x86_64 /6ixnp6l
--

whatis([[Name : automake]])
whatis([[Version : 1.16.1]])
whatis([[Short description : Automake -- make file builder part of autotools]])

help([[Automake -- make file builder part of autotools]])



prepend_path("PATH", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-7.2.0/automake-1.16.1-6ixnp6lypd6w3mld2x4pl74aoulqtzfc/bin", ":")
prepend_path("MANPATH", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-7.2.0/automake-1.16.1-6ixnp6lypd6w3mld2x4pl74aoulqtzfc/share/man", ":")
prepend_path("ACLOCAL_PATH", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-7.2.0/automake-1.16.1-6ixnp6lypd6w3mld2x4pl74aoulqtzfc/share/aclocal", ":")
prepend_path("CMAKE_PREFIX_PATH", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-7.2.0/automake-1.16.1-6ixnp6lypd6w3mld2x4pl74aoulqtzfc/", ":")
setenv("AUTOMAKE_ROOT", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-7.2.0/automake-1.16.1-6ixnp6lypd6w3mld2x4pl74aoulqtzfc")


-- -*- lua -*-
-- Module file created by spack (https://github.com/spack/spack) on 2019-09-16 13:43:35.668722
--
-- dropest@master%gcc@7.2.0 build_type=RelWithDebInfo arch=linux-centos7-x86_64 /hovyhyn
--

whatis([[Name : dropest]])
whatis([[Version : master]])
whatis([[Short description : FIXME: Put a proper description of your package here.]])

help([[FIXME: Put a proper description of your package here.]])



prepend_path("PATH", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-7.2.0/dropest-master-hovyhynfsto4iv6q2f23z5lmrymyo3sq/bin", ":")
prepend_path("LD_LIBRARY_PATH", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-7.2.0/dropest-master-hovyhynfsto4iv6q2f23z5lmrymyo3sq/lib", ":")
prepend_path("CMAKE_PREFIX_PATH", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-7.2.0/dropest-master-hovyhynfsto4iv6q2f23z5lmrymyo3sq/", ":")
prepend_path("XDG_DATA_DIRS", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-7.2.0/pango-1.41.0-hexufkrpcwcsq65ak5yytme5jru3frnr/share", ":")
setenv("DROPEST_ROOT", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-7.2.0/dropest-master-hovyhynfsto4iv6q2f23z5lmrymyo3sq")


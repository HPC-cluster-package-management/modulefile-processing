-- -*- lua -*-
-- Module file created by spack (https://github.com/spack/spack) on 2019-09-16 13:47:10.762722
--
-- ghostscript-fonts@8.11%gcc@7.2.0 arch=linux-centos7-x86_64 /elfjmp2
--

whatis([[Name : ghostscript-fonts]])
whatis([[Version : 8.11]])
whatis([[Short description : Ghostscript Fonts]])

help([[Ghostscript Fonts]])



prepend_path("CMAKE_PREFIX_PATH", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-7.2.0/ghostscript-fonts-8.11-elfjmp2nvhq3tgvarlexb73ofo5tgh76/", ":")
setenv("GHOSTSCRIPT_FONTS_ROOT", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-7.2.0/ghostscript-fonts-8.11-elfjmp2nvhq3tgvarlexb73ofo5tgh76")


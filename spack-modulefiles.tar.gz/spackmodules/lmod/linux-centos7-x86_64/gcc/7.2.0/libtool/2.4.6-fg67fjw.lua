-- -*- lua -*-
-- Module file created by spack (https://github.com/spack/spack) on 2019-09-16 14:00:05.966855
--
-- libtool@2.4.6%gcc@7.2.0 arch=linux-centos7-x86_64 /fg67fjw
--

whatis([[Name : libtool]])
whatis([[Version : 2.4.6]])
whatis([[Short description : libtool -- library building part of autotools.]])

help([[libtool -- library building part of autotools.]])



prepend_path("PATH", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-7.2.0/libtool-2.4.6-fg67fjwlct3pkle3u4wqpjwaqixgqkn6/bin", ":")
prepend_path("MANPATH", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-7.2.0/libtool-2.4.6-fg67fjwlct3pkle3u4wqpjwaqixgqkn6/share/man", ":")
prepend_path("ACLOCAL_PATH", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-7.2.0/libtool-2.4.6-fg67fjwlct3pkle3u4wqpjwaqixgqkn6/share/aclocal", ":")
prepend_path("LD_LIBRARY_PATH", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-7.2.0/libtool-2.4.6-fg67fjwlct3pkle3u4wqpjwaqixgqkn6/lib", ":")
prepend_path("CMAKE_PREFIX_PATH", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-7.2.0/libtool-2.4.6-fg67fjwlct3pkle3u4wqpjwaqixgqkn6/", ":")
setenv("LIBTOOL_ROOT", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-7.2.0/libtool-2.4.6-fg67fjwlct3pkle3u4wqpjwaqixgqkn6")


-- -*- lua -*-
-- Module file created by spack (https://github.com/spack/spack) on 2019-09-16 13:40:32.286810
--
-- aida@3.2.1%gcc@7.2.0 arch=linux-centos7-x86_64 /ulwtk4b
--

whatis([[Name : aida]])
whatis([[Version : 3.2.1]])
whatis([[Short description : Abstract Interfaces for Data Analysis]])

help([[Abstract Interfaces for Data Analysis]])



prepend_path("CMAKE_PREFIX_PATH", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-7.2.0/aida-3.2.1-ulwtk4bf6ul43p7o26w57qt6sbrkki5z/", ":")
setenv("AIDA_ROOT", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-7.2.0/aida-3.2.1-ulwtk4bf6ul43p7o26w57qt6sbrkki5z")


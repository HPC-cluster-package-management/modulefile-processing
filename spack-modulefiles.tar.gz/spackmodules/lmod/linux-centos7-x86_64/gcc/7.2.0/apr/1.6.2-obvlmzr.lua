-- -*- lua -*-
-- Module file created by spack (https://github.com/spack/spack) on 2019-09-16 13:40:37.961829
--
-- apr@1.6.2%gcc@7.2.0 arch=linux-centos7-x86_64 /obvlmzr
--

whatis([[Name : apr]])
whatis([[Version : 1.6.2]])
whatis([[Short description : Apache portable runtime.]])

help([[Apache portable runtime.]])



prepend_path("PATH", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-7.2.0/apr-1.6.2-obvlmzr5326z45nrc642lc7q5rmjtnyu/bin", ":")
prepend_path("LD_LIBRARY_PATH", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-7.2.0/apr-1.6.2-obvlmzr5326z45nrc642lc7q5rmjtnyu/lib", ":")
prepend_path("PKG_CONFIG_PATH", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-7.2.0/apr-1.6.2-obvlmzr5326z45nrc642lc7q5rmjtnyu/lib/pkgconfig", ":")
prepend_path("CMAKE_PREFIX_PATH", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-7.2.0/apr-1.6.2-obvlmzr5326z45nrc642lc7q5rmjtnyu/", ":")
setenv("APR_ROOT", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-7.2.0/apr-1.6.2-obvlmzr5326z45nrc642lc7q5rmjtnyu")


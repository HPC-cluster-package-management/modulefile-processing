-- -*- lua -*-
-- Module file created by spack (https://github.com/spack/spack) on 2019-09-16 14:06:40.423422
--
-- libxvmc@1.0.9%gcc@7.2.0 arch=linux-centos7-x86_64 /aivhd3o
--

whatis([[Name : libxvmc]])
whatis([[Version : 1.0.9]])
whatis([[Short description : X.org libXvMC library.]])

help([[X.org libXvMC library.]])



prepend_path("LD_LIBRARY_PATH", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-7.2.0/libxvmc-1.0.9-aivhd3ozvuf26ndbs22mlndrliqzz6fj/lib", ":")
prepend_path("PKG_CONFIG_PATH", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-7.2.0/libxvmc-1.0.9-aivhd3ozvuf26ndbs22mlndrliqzz6fj/lib/pkgconfig", ":")
prepend_path("CMAKE_PREFIX_PATH", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-7.2.0/libxvmc-1.0.9-aivhd3ozvuf26ndbs22mlndrliqzz6fj/", ":")
setenv("LIBXVMC_ROOT", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-7.2.0/libxvmc-1.0.9-aivhd3ozvuf26ndbs22mlndrliqzz6fj")


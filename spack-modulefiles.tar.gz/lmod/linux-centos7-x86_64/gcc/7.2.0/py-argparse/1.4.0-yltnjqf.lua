-- -*- lua -*-
-- Module file created by spack (https://github.com/spack/spack) on 2019-09-16 14:26:04.778702
--
-- py-argparse@1.4.0%gcc@7.2.0 arch=linux-centos7-x86_64 /yltnjqf
--

whatis([[Name : py-argparse]])
whatis([[Version : 1.4.0]])
whatis([[Short description : Python command-line parsing library.]])

help([[Python command-line parsing library.]])



prepend_path("LD_LIBRARY_PATH", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-7.2.0/py-argparse-1.4.0-yltnjqf7ehvv7oadfyoaovigvg3uozgs/lib", ":")
prepend_path("CMAKE_PREFIX_PATH", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-7.2.0/py-argparse-1.4.0-yltnjqf7ehvv7oadfyoaovigvg3uozgs/", ":")
prepend_path("PYTHONPATH", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-7.2.0/py-argparse-1.4.0-yltnjqf7ehvv7oadfyoaovigvg3uozgs/lib/python2.7/site-packages", ":")
setenv("PY_ARGPARSE_ROOT", "/u/local/spack/0.12/opt/spack/linux-centos7-x86_64/gcc-7.2.0/py-argparse-1.4.0-yltnjqf7ehvv7oadfyoaovigvg3uozgs")


--udunits

local help_message = [[
The udunits module file defines the following environment variables:
TACC_UDUNITS_DIR, TACC_UDUNITS_BIN, TACC_UDUNITS_LIB, and 
TACC_UDUNITS_INC forthe location of the UDUNITS distribution, binaries,
libraries, and include files, respectively.

UDUNITS 4.1.1 uses the hdf5 libraries to support the UDUNITS 4 file format 
in addition to the classic UDUNITS file format. 

To use the UDUNITS library, compile the source code with the option:

	-I${TACC_UDUNITS_INC} 

and add the following options to the link step: 

	-L${TACC_UDUNITS_LIB} -ludunits -L${TACC_HDF5_LIB} -lhdf5_hl -lhdf5 -lz -lm

Version 2.2.25

]]

help(help_message,"\n")


whatis("Udunits: Network Common Data Form")
whatis("Version: 2.2.25")
whatis("Category: library, runtime support")
whatis("Keywords: I/O, Library")
whatis("Description: I/O library which stores and retrieves data in self-describing, machine-independent datasets." )
whatis("URL: http://www.unidata.ucar.edu/software/udunits/")

-- Prerequisites
prereq("hdf5")

--Prepend paths
prepend_path("LD_LIBRARY_PATH","/opt/apps/intel18/udunits/2.2.25/lib")
prepend_path("PATH",           "/opt/apps/intel18/udunits/2.2.25/bin")
prepend_path("MANPATH",        "/opt/apps/intel18/udunits/2.2.25/share/man")
prepend_path("PKG_CONFIG_PATH","/opt/apps/intel18/udunits/2.2.25/lib/pkgconfig")

--Env variables 
setenv("TACC_UDUNITS_DIR", "/opt/apps/intel18/udunits/2.2.25")
setenv("TACC_UDUNITS_INC", "/opt/apps/intel18/udunits/2.2.25/include")
setenv("TACC_UDUNITS_LIB", "/opt/apps/intel18/udunits/2.2.25/lib")
setenv("TACC_UDUNITS_BIN", "/opt/apps/intel18/udunits/2.2.25/bin")


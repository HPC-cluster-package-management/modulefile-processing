local help_msg=[[
This module loads the MVAPICH2 MPI environment built with Intel compilers.
By loading this module, the following commands will be automatically available
for compiling MPI applications:
mpif77       (F77 source)
mpif90       (F90 source)
mpicc        (C   source)
mpiCC/mpicxx (C++ source)

Version 2.3
]]

help(help_msg)

whatis( "Name: mvapich2"                                       )
whatis( "Version: 2.3"                                          )
whatis( "Category: library, runtime support"                           )
whatis( "Keywords: System, Library"                                    )
whatis( "Description:  MPI-3.1 implementation"                         )
whatis( "URL: http://mvapich.cse.ohio-state.edu/overview/mvapich2"     )

local base_dir = "/opt/apps/intel18/mvapich2/2.3"

setenv( "MPICH_HOME"             , base_dir                            )
setenv( "TACC_MPI_GETMODE"       , "mvapich2_ssh"                      )
setenv( "MV2_FASTSSH_THRESHOLD"  , "10000"                             )
setenv( "MV2_HOMOGENEOUS_CLUSTER", "1"                                 )
setenv( "PSM2_KASSIST_MODE"      , "none"                              )

prepend_path( "PATH"             , pathJoin( base_dir , "bin"          ) )
prepend_path( "MANPATH"          , pathJoin( base_dir , "share/man"    ) )
prepend_path( "INFOPATH"         , pathJoin( base_dir , "doc"          ) )
prepend_path( "LD_LIBRARY_PATH"  , pathJoin( base_dir , "lib/shared"   ) )
prepend_path( "LD_LIBRARY_PATH"  , pathJoin( base_dir , "lib"          ) )
prepend_path( "PKG_CONFIG_PATH"  , pathJoin( base_dir , "lib/pkgconfig") )
prepend_path( "MODULEPATH"       ,"/opt/apps/intel18/mvapich2-2_3/modulefiles" )

family("MPI")


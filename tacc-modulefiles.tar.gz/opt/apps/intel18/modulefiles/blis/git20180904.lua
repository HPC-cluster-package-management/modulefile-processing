local help_message = [[

This module provides the BLIS environment variables:
TACC_BLIS_DIR, TACC_BLIS_LIB, TACC_BLIS_INC

Version git20180904
]]

help(help_message,"\n")

whatis("Name: BLIS")
whatis("Version: git20180904")
whatis("Category: ")
whatis("Keywords: library, numerics, BLAS")
whatis("URL: https://code.google.com/p/blis/")
whatis("Description: BLAS-like Library Instantiation Software")

local blis_dir="/home1/apps/intel18/blis/git20180904"

setenv("TACC_BLIS_DIR",blis_dir)
setenv("TACC_BLIS_LIB",pathJoin(blis_dir,"lib"))
setenv("TACC_BLIS_INC",pathJoin(blis_dir,"include"))

append_path("LD_LIBRARY_PATH",pathJoin(blis_dir,"lib"))


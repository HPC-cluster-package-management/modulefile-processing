--  modulefile for NCO

local help_message = [[
The nco module file defines the following environment variables:
TACC_NCO_DIR, TACC_NCO_BIN, TACC_NCO_LIB, and 
TACC_NCO_INC for the location of the NCO distribution, binaries,
libraries, and include files, respectively.

To use the NCO library, compile the source code with the option:
	-I\${TACC_NCO_INC 

and add the following options to the link step: 
	-L\${TACC_NCO_LIB -lnco

Version 4.6.9

]]

help(help_message,"\n")

whatis("Version: 4.6.9")
whatis("Category: utility, runtime support")
whatis("Description: Programs for manipulating and analyzing NetCDF files")
whatis("URL: http://nco.sourceforge.net")

setenv("TACC_NCO_DIR","/opt/apps/intel18/nco/4.6.9")
setenv("TACC_NCO_BIN","/opt/apps/intel18/nco/4.6.9/bin")
setenv("TACC_NCO_INC","/opt/apps/intel18/nco/4.6.9/include")
setenv("TACC_NCO_LIB","/opt/apps/intel18/nco/4.6.9/lib")
setenv("TACC_NCO_MAN","/opt/apps/intel18/nco/4.6.9/share/man")
prepend_path("PATH","/opt/apps/intel18/nco/4.6.9/bin")
prepend_path("LD_LIBRARY_PATH","/opt/apps/intel18/nco/4.6.9/lib")
prepend_path("MANPATH","/opt/apps/intel18/nco/4.6.9/share/man")
--prereq("gsl", "hdf5", "netcdf")


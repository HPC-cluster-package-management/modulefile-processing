help( [[
Simplified Wrapper and Interface Generator
This module loads swig.
The command directory is added to PATH.
The include directory is added to INCLUDE.
The lib     directory is added to LD_LIBRARY_PATH.

Version 3.0.12
]] )

whatis( "Simplified Wrapper and Interface Generator" )
whatis( "Version: 3.0.12" )
whatis( "Category: Development/Tools" )
whatis( "Description: SWIG is a software development tool that connects programs written in C and C++ with a variety of high-level programming languages." )
whatis( "URL: http://www.swig.org" )

local swig_dir = "/home1/apps/intel18/swig/3.0.12"

prepend_path( "PATH", pathJoin( swig_dir,"bin" ) )
setenv("TACC_SWIG_DIR", swig_dir )
setenv("TACC_SWIG_BIN", pathJoin(swig_dir,"bin" ) )

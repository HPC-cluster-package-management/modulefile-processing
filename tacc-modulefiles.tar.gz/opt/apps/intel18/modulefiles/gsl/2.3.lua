local help_msg=[[
The GSL module defines the following environment variables:
TACC_GSL_DIR, TACC_GSL_LIB, TACC_GSL_INC and
TACC_GSL_BIN for the location of the GSL distribution, libraries,
include files, and tools respectively.
]]

--help(help_msg)
help(help_msg)

whatis("Name: GSL")
whatis("Version: 2.3")

-- Create environment variables.
local bar_dir           = "/opt/apps/intel18/gsl/2.3"

family("GSL")
prepend_path(    "PATH",                pathJoin(bar_dir, "bin"))
prepend_path(    "LD_LIBRARY_PATH",     pathJoin(bar_dir, "lib"))
prepend_path(    "MODULEPATH",         "/opt/apps/bar1_1/modulefiles")
setenv( "TACC_GSL_DIR",                bar_dir)
setenv( "TACC_GSL_INC",       pathJoin(bar_dir, "include"))
setenv( "TACC_GSL_LIB",       pathJoin(bar_dir, "lib"))
setenv( "TACC_GSL_BIN",       pathJoin(bar_dir, "bin"))
setenv( "PKG_CONFIG_PATH",       pathJoin(bar_dir, "lib/pkgconfig"))

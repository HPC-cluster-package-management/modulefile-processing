local help_message = [[
The matplotlib basemap toolkit is a library for plotting 2D data on maps in
Python. It is similar in functionality to the matlab mapping toolbox, the IDL
mapping facilities, GrADS, or the Generic Mapping Tools. PyNGL and CDAT are
other libraries that provide similar capabilities in Python.

This module defines the environmental variables TACC_BASEMAP_LIB
and TACC_BASEMAP_DIR for the location of the main GEOS directory
and the libraries.

The location of the library files for GEOS and basemap are added to your
LD_LIBRARY_PATH while basemap is also added to your PYTHONPATH.


Version 1.1.0
]]

help(help_message,"\n")

whatis("Name: tacc-basemap-intel18")
whatis("Version: 1.1.0")
whatis("Category: Python Package")
whatis("Keywords: Cartography")
whatis("Description: Plot 2D data on maps in Python")
whatis("URL: https://matplotlib.org/basemap/users/intro.html")

-- Export environmental variables
local basemap_dir="/home1/apps/intel18/basemap/1.1.0"
local geos_lib=pathJoin(basemap_dir,"lib")
setenv("TACC_BASEMAP_DIR",basemap_dir)
setenv("TACC_GEOS_LIB",geos_lib)

-- Prepend the basemap directories to the adequate PATH variables
prepend_path("LD_LIBRARY_PATH", geos_lib)
prepend_path("LD_LIBRARY_PATH", pathJoin(basemap_dir,"lib"))
prepend_path("PYTHONPATH",      pathJoin(basemap_dir,"lib/python2.7/site-packages"))

depends_on("python2")


--ncview

local help_message = [[
The ncview module file defines the following environment variables:
TACC_NCVIEW_DIR, TACC_NCVIEW_BIN,
for the location of the NCVIEW distribution and binaries, respectively.

Version 2.1.7

]]

help(help_message,"\n")


whatis("Ncview: NetCDF data viewer")
whatis("Version: 2.1.7")
whatis("Category: visualization, application")
whatis("Keywords: I/O")
whatis("Description: Visualization program for NetCDF files")
whatis("URL: http://meteora.ucsd.edu/~pierce/ncview_home_page.html")

-- Prerequisites
prereq("hdf5","netcdf","udunits")

--Prepend paths
prepend_path("LD_LIBRARY_PATH","/opt/apps/intel18/ncview/2.1.7/lib")
prepend_path("PATH",           "/opt/apps/intel18/ncview/2.1.7/bin")

--Env variables 
setenv("TACC_NCVIEW_DIR", "/opt/apps/intel18/ncview/2.1.7")
setenv("TACC_NCVIEW_BIN", "/opt/apps/intel18/ncview/2.1.7/bin")


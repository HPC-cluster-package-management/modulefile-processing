help( [[
Simplified Wrapper and Interface Generator
This module loads loki.
The command directory is added to PATH.
The include directory is added to INCLUDE.
The lib     directory is added to LD_LIBRARY_PATH.

Version 0.1.7
]] )

whatis( "Simplified Wrapper and Interface Generator" )
whatis( "Version: 0.1.7" )
whatis( "Category: Development/Tools" )
whatis( "Description: LOKI is a software development tool that provides C++11 functionality" )
whatis( "URL: http://www.loki.org" )

local loki_dir = "/home1/apps/intel18/loki/0.1.7"

prepend_path( "PATH", pathJoin( loki_dir,"bin" ) )
setenv("TACC_LOKI_DIR", loki_dir )
setenv("TACC_LOKI_BIN", pathJoin(loki_dir,"bin" ) )
setenv("TACC_LOKI_INC", pathJoin(loki_dir,"include" ) )


help(
[[
Silo is a library for reading and writing a wide variety of scientific data to binary, disk files.
The files Silo produces and the data within them can be easily shared and exchanged
between wholly independently developed applications running on disparate computing platforms.
Consequently, Silo facilitates the development of general purpose tools for processing scientific data.

Version: 4.10.2
]]
)

whatis("Name:SILO scientific database library")
whatis("Version: 4.10.2")
whatis("Category: Library, Visualization")
whatis("Description: a scalable mesh and field I/O library and scientific database")
whatis("URL: https://wci.llnl.gov/codes/silo/")

prepend_path("PATH",    "/opt/apps/intel18/silo/4.10.2/bin")
prepend_path("INCLUDE", "/opt/apps/intel18/silo/4.10.2/include")
prepend_path("LD_LIBRARY_PATH", "/opt/apps/intel18/silo/4.10.2/lib")

setenv("TACC_SILO_DIR","/opt/apps/intel18/silo/4.10.2")
setenv("TACC_SILO_LIB","/opt/apps/intel18/silo/4.10.2/lib")
setenv("TACC_SILO_INC","/opt/apps/intel18/silo/4.10.2/include")
setenv("TACC_SILO_BIN","/opt/apps/intel18/silo/4.10.2/bin")


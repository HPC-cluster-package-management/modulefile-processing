help( [[
Python bindings to C++11. This module provides variables
TACC_PYBIND11_DIR, TACC_PYBIND11_INC, and TACC_PYBIND11_SHARE.
It also update the CMAKE_PREFIX_PATH.

Version 2.2.3
]] )

whatis( "Python bindings for C++11" )
whatis( "Version: 2.2.3" )
whatis( "Category: Development/Tools" )
whatis( "Description: PYBIND11 exposes C++11 functionality to Python" )
whatis( "URL: https://pybind1111.readthedocs.io/en/latest/" )

local pybind11_dir = "/home1/apps/intel18/pybind11/2.2.3"

setenv("TACC_PYBIND11_DIR", pybind11_dir )
setenv("TACC_PYBIND11_INC", pathJoin(pybind11_dir,"include" ) )
setenv("TACC_PYBIND11_SHARE", pathJoin(pybind11_dir,"share" ) )
append_path( "CMAKE_PREFIX_PATH", pathJoin( pybind11_dir,"share","cmake","pybind11" ) )

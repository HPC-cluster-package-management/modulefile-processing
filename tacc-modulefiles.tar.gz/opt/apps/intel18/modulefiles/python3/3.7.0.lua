help(
[[
This is the Python3 package built on February 06, 2019.

You can install your own modules (choose one method):
        1. python3 setup.py install --user
        2. python3 setup.py install --home=<dir>
        3. pip3 install --user module-name

Version 3.7.0
]]
)

whatis("Name: Python3")
whatis("Version: 3.7.0")
whatis("Version-notes: Compiler:intel18")
whatis("Category: Applications, Scientific, Graphics")
whatis("Keywords: Applications, Scientific, Graphics, Scripting Language")
whatis("URL: http://www.python.org/")
whatis("Description: scientific scripting package")

--
-- Create environment variables.
--
local python_dir   = "/opt/apps/intel18/python3/3.7.0"
local python_bin   = "/opt/apps/intel18/python3/3.7.0/bin"
local python_inc   = "/opt/apps/intel18/python3/3.7.0/include"
local python_lib   = "/opt/apps/intel18/python3/3.7.0/lib"
local python_man   = "/opt/apps/intel18/python3/3.7.0/share/man:/opt/apps/intel18/python3/3.7.0/man"


setenv("TACC_PYTHON3_DIR", python_dir)
setenv("TACC_PYTHON3_BIN", python_bin)
setenv("TACC_PYTHON3_INC", python_inc)
setenv("TACC_PYTHON3_LIB", python_lib)
setenv("TACC_PYTHON3_MAN", python_man)
setenv("TACC_PYTHON_VER", "3.7")

prepend_path("PATH", python_bin)
prepend_path("MANPATH", python_man)
prepend_path("LD_LIBRARY_PATH", python_lib)


prepend_path("PATH",       "/opt/apps/intel18/python3/3.7.0/bin")
family("python")

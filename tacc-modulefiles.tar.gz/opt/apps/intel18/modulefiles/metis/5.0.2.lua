
help(
[[
The metis modulefile defines the following environment variables:
TACC_METIS_DIR, TACC_METIS_DOC, TACC_METIS_BIN, TACC_METIS_LIB, 
and TACC_METIS_INC for the location of the Metis distribution, 
documentation, binaries, libraries, and include files, respectively.

To use the metis library, include compilation directives
of the form: -L$TACC_METIS_LIB -I$TACC_METIS_INC -lmetis

An example command to compile metis_test.c is as follows:

icc -I$TACC_METIS_INC metis_test.c -L$TACC_METIS_LIB -lmetis"

Version 5.0.2
]]
)

whatis("Name: METIS: Multilevel Partitioning Algorithms")
whatis("Version: 5.0.2")
whatis("Category: library, mathematics")
whatis("Keywords: Library, Mathematics")
whatis("Description: Serial graph partitioning and fill-reduction matrix ordering routines")
whatis("URL: http://glaros.dtc.umn.edu/gkhome/views/metis")
whatis("Packager: TACC - mclay@tacc.utexas.edu")


setenv(         "TACC_METIS_DIR",        "/opt/apps/intel18/metis/5.0.2")
setenv(         "TACC_METIS_BIN",        "/opt/apps/intel18/metis/5.0.2/bin")
setenv(         "TACC_METIS_DOC",        "/opt/apps/intel18/metis/5.0.2/manual")
setenv(         "TACC_METIS_LIB",        "/opt/apps/intel18/metis/5.0.2/lib")
setenv(         "TACC_METIS_INC",        "/opt/apps/intel18/metis/5.0.2/include")

--
-- prepend path
--

prepend_path(   "PATH",                  "/opt/apps/intel18/metis/5.0.2")
prepend_path(   "LD_LIBRARY_PATH",       "/opt/apps/intel18/metis/5.0.2/lib")

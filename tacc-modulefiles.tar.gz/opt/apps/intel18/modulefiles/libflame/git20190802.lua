local help_message = [[

This module provides the LIBFLAME environment variables:
TACC_LIBFLAME_DIR, TACC_LIBFLAME_LIB, TACC_LIBFLAME_INC

There are examples programs in \$TACC_LIBFLAME_DIR/examples

Version git20190802
]]

help(help_message,"\n")

whatis("Name: LIBFLAME")
whatis("Version: git20190802")
whatis("Category: ")
whatis("Keywords: library, numerics, BLAS")
whatis("URL: https://github.com/flame/libflame")
whatis("Description: BLAS-like Library Instantiation Software")

local libflame_dir="/home1/apps/intel18/libflame/git20190802"

setenv("TACC_LIBFLAME_DIR",libflame_dir)
setenv("TACC_LIBFLAME_LIB",pathJoin(libflame_dir,"lib"))
setenv("TACC_LIBFLAME_INC",pathJoin(libflame_dir,"include"))

append_path("LD_LIBRARY_PATH",pathJoin(libflame_dir,"lib"))


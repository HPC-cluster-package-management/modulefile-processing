help( [[
Module tacc-superlu_seq-intel18 loads environmental variables defining
the location of SUPERLUSEQ directory, libraries, and binaries:
TACC_SUPERLUSEQ_DIR TACC_SUPERLUSEQ_LIB TACC_SUPERLUSEQ_BIN

Version: 5.2.1
]] )

whatis( "SUPERLUSEQ" )
whatis( "Version: 5.2.1" )
whatis( "Category: system, development" )
whatis( "Keywords: System, Cartesian Grids" )
whatis( "Description: Supernodal LU factorization" )
whatis( "URL: http://crd-legacy.lbl.gov/~xiaoye/SuperLU/" )

local version =  "5.2.1"
local superlu_seq_dir =  "/home1/apps/intel18/superlu_seq/5.2.1"

setenv("TACC_SUPERLUSEQ_DIR",superlu_seq_dir)
-- setenv("TACC_SUPERLUSEQ_BIN",pathJoin( superlu_seq_dir,"bin" ) )
setenv("TACC_SUPERLUSEQ_INC",pathJoin( superlu_seq_dir,"include" ) )
setenv("TACC_SUPERLUSEQ_LIB",pathJoin( superlu_seq_dir,"lib64" ) )
setenv("TACC_SUPERLUSEQ_SHARE",pathJoin( superlu_seq_dir,"share" ) )

prepend_path ("PATH",pathJoin( superlu_seq_dir,"share" ) )
-- prepend_path ("PATH",pathJoin( superlu_seq_dir,"bin" ) )
prepend_path ("LD_LIBRARY_PATH",pathJoin( superlu_seq_dir, "lib64" ) )

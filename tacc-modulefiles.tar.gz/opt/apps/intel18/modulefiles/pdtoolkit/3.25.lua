
-- This module file sets up the environment variables & path for PDTtoolkit.

local help_message = [[

The pdtoolkit module defines the following environment variables:
TACC_PDTOOLKIT_DIR, TACC_PDTOOLKIT_BIN, TACC_PDTOOLKIT_LIB and 
TACC_PDTOOLKIT_INC for the location of the PDToolkit distribution,
binaries, libraries and include files.

Version 3.25

]]

help(help_message,"\n")

whatis("Name: PDT, Program Database Toolkit ")
whatis("Version: 3.25")
whatis("Category: library, profiling and optimization")
whatis("System: Profiling, Tools")
whatis("URL: http://www.cs.uoregon.edu/research/tau/home.php")
whatis("Description: Instruments code for TAU profiling and tracing")

--#
--# Create environment variables.
--#
family("pdtoolkit")
local         pdtoolkit_dir       = "/opt/apps/intel18/pdtoolkit/3.25"
local         pdtoolkit_bin       = "/opt/apps/intel18/pdtoolkit/3.25/x86_64/bin"
local         pdtoolkit_lib       = "/opt/apps/intel18/pdtoolkit/3.25/x86_64/lib"
local         pdtoolkit_inc       = "/opt/apps/intel18/pdtoolkit/3.25/x86_64/include"

prepend_path( "PATH"              , pdtoolkit_bin )
prepend_path( "LD_LIBRARY_PATH"   , pdtoolkit_lib )

setenv(       "TACC_PDTOOLKIT_DIR", pdtoolkit_dir )
setenv(       "TACC_PDTOOLKIT_BIN", pdtoolkit_bin )
setenv(       "TACC_PDTOOLKIT_LIB", pdtoolkit_lib )
setenv(       "TACC_PDTOOLKIT_INC", pdtoolkit_inc )


local help_message = [[
The canu module file defines the following environment variables:

 - TACC_CANU_DIR
 - TACC_CANU_BIN
 - TACC_CANU_LIB

for the location of the canu distribution.

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
   This version of canu only supports
           single node execution using the

                    useGrid=false

   paramter. TACC systems do NOT allow job arrays!
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

Documentation: https://github.com/marbl/canu

Version 1.8
]]

help(help_message,"\n")

whatis("Name: canu")
whatis("Version: 1.8")
whatis("Category: computational biology, genomics, assembly")
whatis("Keywords: Biology, Genomics, assembly, long-reads, nanopore")
whatis("Description: Canu is a fork of the Celera Assembler designed for high-noise single-molecule sequencing (such as the PacBio RSII or Oxford Nanopore MinION)")
whatis("URL: https://github.com/marbl/canu")

depends_on("python2")

prepend_path("PATH",		"/home1/apps/intel18/canu/1.8/bin")

setenv("TACC_CANU_DIR",     "/home1/apps/intel18/canu/1.8")
setenv("TACC_CANU_BIN",	"/home1/apps/intel18/canu/1.8/bin")
setenv("TACC_CANU_LIB",	"/home1/apps/intel18/canu/1.8/lib")

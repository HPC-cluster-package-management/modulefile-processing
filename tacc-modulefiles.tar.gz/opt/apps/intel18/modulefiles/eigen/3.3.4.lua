help( [[
Module tacc-eigen-intel18 loads environmental variables defining
the location of EIGEN directory, libraries, and binaries:
TACC_EIGEN_DIR TACC_EIGEN_BIN TACC_EIGEN_SHARE

Version: 3.3.4
]] )

whatis( "EIGEN" )
whatis( "Version: 3.3.4" )
whatis( "Category: system, development" )
whatis( "Keywords: Linear Algebra, C++" )
whatis( "Description: C++ template library for linear algebra" )
whatis( "URL: http://eigen.tuxfamily.org/" )

local version =  "3.3.4"
local eigen_dir =  "/home1/apps/intel18/eigen/3.3.4"

setenv("TACC_EIGEN_DIR",eigen_dir)
setenv("TACC_EIGEN_BIN",pathJoin( eigen_dir,"bin" ) )
setenv("TACC_EIGEN_INC",pathJoin( eigen_dir,"include","eigen3" ) )
setenv("TACC_EIGEN_SHARE",pathJoin( eigen_dir,"share" ) )

prepend_path ("PATH",pathJoin( eigen_dir,"share" ) )
prepend_path ("PATH",pathJoin( eigen_dir,"bin" ) )

local help_msg=[[
Intel MPI Library 18.0.2 focuses on making applications perform better on Intel
architecture-based clusters -- implementing the high performance Message Passing
Interface Version 3.0 specification on multiple fabrics. It enables you to
quickly deliver maximum end user performance even if you change or upgrade to
new interconnects, without requiring changes to the software or operating
environment.

This module loads the Intel MPI environment built with
Intel compilers. By loading this module, the following commands
will be automatically available for compiling MPI applications:
mpif77       (F77 source)
mpif90       (F90 source)
mpicc        (C   source)
mpicxx       (C++ source)

The IMPI module also defines the following environment variables:
TACC_IMPI_DIR, TACC_IMPI_LIB, TACC_IMPI_INC and
TACC_IMPI_BIN for the location of the IMPI distribution, libraries,
include files, and tools respectively.

Version 18.0.2
]]

--help(help_msg)
help(help_msg)

-- Create environment variables.
local base_dir           = "/opt/intel/compilers_and_libraries_2018.2.199/linux/mpi"

whatis("Name: Intel MPI"                                                    )
whatis("Version: 18.0.2"                                                )
whatis("Category: library, Runtime Support"                                 )
whatis("Description: Intel MPI Library (C/C++/Fortran for x86_64)"          )
whatis("URL: http://software.intel.com/en-us/articles/intel-mpi-library"    )
prepend_path( "PATH"                   , pathJoin( base_dir , "intel64/bin"      ) )
prepend_path( "PATH"                   , pathJoin( "/opt/apps/intel18/impi/18.0.2" , "bin"      ) )
prepend_path( "LD_LIBRARY_PATH"        , pathJoin( base_dir , "intel64/lib"      ) )
prepend_path( "MANPATH"                , pathJoin( base_dir , "man"              ) )
prepend_path( "MODULEPATH"             ,"/opt/apps/intel18/impi18_0/modulefiles" )
prepend_path( "I_MPI_ROOT"             , base_dir                                )
setenv(       "MPICH_HOME"             , base_dir                                )
setenv(       "TACC_MPI_GETMODE"       , "impi_hydra"                            )
setenv(       "TACC_IMPI_DIR"          , base_dir                                )
setenv(       "TACC_IMPI_BIN"          , pathJoin( base_dir , "intel64/bin"      ) )
setenv(       "TACC_IMPI_LIB"          , pathJoin( base_dir , "intel64/lib"      ) )
setenv(       "TACC_IMPI_INC"          , pathJoin( base_dir , "intel64/include"  ) )
setenv(       "I_MPI_JOB_FAST_STARTUP" , "1"                                     )
setenv(       "I_MPI_CC"               , "icc"                               )
setenv(       "I_MPI_CXX"              , "icpc"                              )
setenv(       "I_MPI_FC"               , "ifort"                               )
setenv(       "I_MPI_F77"              , "ifort"                               )
setenv(       "I_MPI_F90"              , "ifort"                               )
family(       "MPI"                                                              )


if (os.getenv("TACC_SYSTEM") == "stampede2") then
  depends_on("libfabric")
  local libfabric_lib = os.getenv("TACC_LIBFABRIC_LIB")
  setenv(     "I_MPI_OFI_LIBRARY"      , pathJoin(libfabric_lib,"libfabric.so" ) )
  setenv(     "FI_PSM2_LAZY_CONN"      , "1"                                     )
  setenv(     "FI_PROVIDER"            , "psm2"                                  )
  setenv(     "I_MPI_FABRICS"          , "shm:ofi"                               )
  setenv(     "I_MPI_STARTUP_MODE"     , "pmi_shm_netmod"                        )
end


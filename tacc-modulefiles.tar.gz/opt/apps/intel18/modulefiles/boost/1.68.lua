help([[
The boost module file defines the following environment variables:
BOOST_ROOT, TACC_BOOST_DIR, TACC_BOOST_LIB, and TACC_BOOST_INC for
the location of the boost distribution.

To load the rest of boost  do "module load boost"

Version 1.68"
]])

whatis("Name: boost")
whatis("Version: 1.68")
whatis("Category: Lmod/Modulefiles")
whatis("Keywords: System, Library, C++")
whatis("URL: http://www.boost.org")
whatis("Description: Boost provides free peer-reviewed portable C++ source libraries.")


setenv("TACC_BOOST_DIR","/opt/apps/intel18/boost/1.68")
setenv("TACC_BOOST_LIB","/opt/apps/intel18/boost/1.68/lib")
setenv("TACC_BOOST_INC","/opt/apps/intel18/boost/1.68/include")
setenv("TACC_BOOST_BIN","/opt/apps/intel18/boost/1.68/bin")
setenv("BOOST_ROOT","/opt/apps/intel18/boost/1.68")

conflict("boost","boost-mpi")

-- Add boost to the LD_LIBRARY_PATH
prepend_path("LD_LIBRARY_PATH","/opt/apps/intel18/boost/1.68/lib")
prepend_path("PATH", "/opt/apps/intel18/boost/1.68/bin")


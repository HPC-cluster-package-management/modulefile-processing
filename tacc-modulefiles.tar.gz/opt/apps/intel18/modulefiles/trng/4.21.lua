help( [[
Module tacc-trng-intel18 loads environmental variables defining
the location of TRNG directory, libraries, and binaries:
TACC_TRNG_DIR 
TACC_TRNG_BIN TACC_TRNG_INC TACC_TRNG_LIB
TACC_TRNG_SHARE

Version: 4.21
]] )

whatis( "TRNG" )
whatis( "Version: 4.21" )
whatis( "Category: system, development" )
whatis( "Keywords: Linear Algebra, C++" )
whatis( "Description: C++ template library for linear algebra" )
whatis( "URL: https://numbercrunch.de/trng/" )

local version =  "4.21"
local trng_dir =  "/home1/apps/intel18/trng/4.21"

setenv("TACC_TRNG_DIR",trng_dir)
setenv("TACC_TRNG_BIN",pathJoin( trng_dir,"bin" ) )
setenv("TACC_TRNG_INC",pathJoin( trng_dir,"include" ) )
setenv("TACC_TRNG_LIB",pathJoin( trng_dir,"lib" ) )
setenv("TACC_TRNG_SHARE",pathJoin( trng_dir,"share" ) )

prepend_path ("PATH",pathJoin( trng_dir,"share" ) )
prepend_path ("PATH",pathJoin( trng_dir,"bin" ) )
prepend_path ("LD_LIBRARY_PATH",pathJoin( trng_dir,"lib" ) )

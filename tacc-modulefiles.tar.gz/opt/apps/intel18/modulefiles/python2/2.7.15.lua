help(
[[
This is the Python2 package built on February 06, 2019.

You can install your own modules (choose one method):
        1. python2 setup.py install --user
        2. python2 setup.py install --home=<dir>
        3. pip2 install --user module-name

Version 2.7.15
]]
)

whatis("Name: Python2")
whatis("Version: 2.7.15")
whatis("Version-notes: Compiler:intel18")
whatis("Category: Applications, Scientific, Graphics")
whatis("Keywords: Applications, Scientific, Graphics, Scripting Language")
whatis("URL: http://www.python.org/")
whatis("Description: scientific scripting package")

--
-- Create environment variables.
--
local python_dir   = "/opt/apps/intel18/python2/2.7.15"
local python_bin   = "/opt/apps/intel18/python2/2.7.15/bin"
local python_inc   = "/opt/apps/intel18/python2/2.7.15/include"
local python_lib   = "/opt/apps/intel18/python2/2.7.15/lib"
local python_man   = "/opt/apps/intel18/python2/2.7.15/share/man:/opt/apps/intel18/python2/2.7.15/man"


setenv("TACC_PYTHON2_DIR", python_dir)
setenv("TACC_PYTHON2_BIN", python_bin)
setenv("TACC_PYTHON2_INC", python_inc)
setenv("TACC_PYTHON2_LIB", python_lib)
setenv("TACC_PYTHON2_MAN", python_man)
setenv("TACC_PYTHON_VER", "2.7")

prepend_path("PATH", python_bin)
prepend_path("MANPATH", python_man)
prepend_path("LD_LIBRARY_PATH", python_lib)


prepend_path("PATH",       "/opt/apps/intel18/python2/2.7.15/bin")
family("python")

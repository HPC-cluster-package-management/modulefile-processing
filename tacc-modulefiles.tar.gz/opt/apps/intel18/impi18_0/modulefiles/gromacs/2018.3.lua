
local help_msg=[[

The tacc-gromacs-intel18-impi18_0 module file defines the following environment variables:
TACC_GROMACS_DIR, TACC_GROMACS_BIN, TACC_GROMACS_DOC, TACC_GROMACS_LIB, and
TACC_GROMACS_INC for the location of the tacc-gromacs-intel18-impi18_0 distribution, binaries,
documentation, libraries, and include files, respectively. Also, GMXLIB has been
set to the topology-file directory in /opt/apps/intel18/impi18_0/gromacs/2018.3/share/gromacs/top.

The parallel component of gromacs is the molecular dynamics engine, mdrun_mpi.
The following command can be used to launch simulation jobs in Stampede2 Skylake(SKX) nodes :

 ibrun mdrun_mpi -s topol.tpr -o traj.trr -c confout.gro -e ener.edr -g md.log

To launch simulation jobs in Stampede2 Knights Landing(KNL) nodes, one has to use a different 
binary called mdrun_mpi_knl. For example:

 ibrun mdrun_mpi_knl -s topol.tpr -o traj.trr -c confout.gro -e ener.edr -g md.log 


The topology file topol.tpr, mdout.md, and deshuf.ndx should be generated with the
grompp command:

  grompp ... -po mdout.mdp -deshuf deshuf.ndx -o topol.tpr

TACC also provides a double-precision version of the mdrun application,
called mdrun_mpi_d.  To use the double-precision version, simply replace
mdrun_mpi in the commands above with mdrun_mpi_d.


To use the gromacs libraries, compile the source code with the option:

 -I\$TACC_GROMACS_INC

and add the following options to the link step:

 -L\$TACC_GROMACS_LIB -lgromacs

Here is an example command to compile test.c:

   icc -I\$TACC_GROMACS_INC test.c -L\$TACC_GROMACS_LIB -lgromacs

Version 2018.3

]]



--help(help_msg)
help(help_msg)

whatis("Name: gromacs")

whatis("Version: gromacs")
whatis("Category: Application, Biology")
whatis("Keywords: Biology, Chemistry, Molecular Dynamics, Application")
whatis("URL: http://www.gromacs.org")
whatis("Description: molecular dynamics simulation package")

-- Prerequisites

-- Create environment variables.

local gromacs_dir   = "/opt/apps/intel18/impi18_0/gromacs/2018.3"

family("gromacs")
prepend_path(    "PATH",    pathJoin(gromacs_dir, "bin"))
prepend_path(  "LD_LIBRARY_PATH", pathJoin(gromacs_dir, "lib64"))
setenv( "TACC_GROMACS_DIR",   gromacs_dir)
setenv( "TACC_GROMACS_INC",       pathJoin(gromacs_dir, "include"))
setenv( "TACC_GROMACS_LIB",       pathJoin(gromacs_dir, "lib64"))
setenv( "TACC_GROMACS_BIN", pathJoin(gromacs_dir, "bin"))

setenv("TACC_GROMACS_DOC",pathJoin(gromacs_dir,"share"))
setenv("GMXLIB",pathJoin(gromacs_dir,"share/gromacs/top"))
append_path("MANPATH",pathJoin(gromacs_dir,"share/man"))
append_path("PKG_CONFIG_PATH",pathJoin(gromacs_dir,"lib/pkgconfig"))


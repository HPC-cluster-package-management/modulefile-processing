local help_message = [[
The tacc-referencelapack-intel18-impi18_0 module file defines the following environment variables:
TACC_REFERENCELAPACK_DIR, TACC_REFERENCELAPACK_LIB, and 
for the location of sources and libraries respectively.

This Module Should NOT, I repeat !!!NOT!!!, Be Used In Production!

This module serves for debugging purposes or to compare against MKL.

Version 3.5.0

]]

help(help_message,"\n")


whatis("ReferenceLapack: Reference implementation of blas and lapack")
whatis("Version: 3.5.0")
whatis("Category: development, mathematics")
whatis("Keywords: Library, development, mathematics")
whatis("Description: Fortran reference implementation of Blas and Lapack.")
whatis("URL: http://netlib.org/lapack/")

-- Prerequisites

--Prepend paths
prepend_path("LD_LIBRARY_PATH","/opt/apps/intel18/impi18_0/referencelapack/3.5.0/lib")

--Env variables 
setenv("TACC_REFERENCELAPACK_DIR", "/opt/apps/intel18/impi18_0/referencelapack/3.5.0")
setenv("TACC_REFERENCELAPACK_LIB", "/opt/apps/intel18/impi18_0/referencelapack/3.5.0/lib")


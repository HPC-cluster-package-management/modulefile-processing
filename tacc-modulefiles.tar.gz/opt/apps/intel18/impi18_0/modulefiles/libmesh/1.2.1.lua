help( [[
The libmesh module defines the following environment variables:
TACC_LIBMESH_DIR, TACC_LIBMESH_BIN, and
TACC_LIBMESH_LIB for the location
of the Libmesh distribution, documentation, binaries,
and libraries.

Version 1.2.1
external packages installed: 
]] )

whatis( "Name: Libmesh" )
whatis( "Version: 1.2.1" )
whatis( "Category: library, mathematics" )
whatis( "URL: https://github.com/libMesh" )
whatis( "Description: C++ Finite Element Library" )

local             libmesh_dir =     "/home1/apps/intel18/impi18_0/libmesh/1.2.1/"

prepend_path("PATH",            pathJoin(libmesh_dir,libmesh_arch,"bin") )
prepend_path("LD_LIBRARY_PATH", pathJoin(libmesh_dir,libmesh_arch,"lib") )

setenv("TACC_LIBMESH_DIR",        libmesh_dir)
setenv("TACC_LIBMESH_BIN",        pathJoin(libmesh_dir,libmesh_arch,"bin") )
setenv("TACC_LIBMESH_INC",        pathJoin(libmesh_dir,libmesh_arch,"include") )
setenv("TACC_LIBMESH_LIB",        pathJoin(libmesh_dir,libmesh_arch,"lib") )

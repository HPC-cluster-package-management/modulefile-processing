local help_message = [[
HOOMD-blue is a general-purpose particle simulation toolkit. 
It scales from a single CPU core to thousands of GPUs.

You define particle initial conditions and interactions in a 
high-level python script. Then tell HOOMD-blue how you want to 
execute the job and it takes care of the rest. Python job 
scripts give you unlimited flexibility to create custom 
initialization routines, control simulation parameters, 
and perform in situ analysis.

For more information about using HOOMD-Blue package, please check
the website:

  https://hoomd-blue.readthedocs.io/en/stable/

* REFERENCE
      
  HOOMD-Blue website: http://glotzerlab.engin.umich.edu/hoomd-blue/

Version 2.4.2
]]

help(help_message,"\n")

whatis("Name: HOOMD-Blue")
whatis("Version: 2.4.2")
whatis("Category: application, chemistry")
whatis("Keywords: Chemistry, Molecular Dynamics, Application")
whatis("URL:  http://glotzerlab.engin.umich.edu/hoomd-blue/")
whatis("Description: General-purpose particle simulation toolkit")

local hoomd_dir="/opt/apps/intel18/impi18_0/hoomd/2.4.2/hoomd"

setenv("TACC_HOOMD_DIR"              ,hoomd_dir)
setenv("TACC_HOOMD_LIB"              ,pathJoin(hoomd_dir,"lib"))
prepend_path("PYTHONPATH",            pathJoin(hoomd_dir,"lib/python3"))
depends_on("python3/3.7.0")

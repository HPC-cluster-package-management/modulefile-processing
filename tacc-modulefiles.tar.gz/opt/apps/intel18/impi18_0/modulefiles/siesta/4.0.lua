local help_message=[[
This module loads Siesta built with Intel 17 and Intel MPI 17.
This module makes available the following executables:

siesta
transiesta

as well as the following utilities:

tbtrans
tbtrans_rep
denchar
dm_creator
mprop
stm
plstm
gen-basis
ioncat

In order to run siesta, please create a link to the binary inside the execution
directory, and make sure your submission script contains the lines:

module load siesta
ibrun ./siesta < input.fdf

As of version 4.0 Siesta no longer provides the Atom program to generate 
pseudopotentials. Please go to this addresss in order to obtain one:

http://nninc.cnf.cornell.edu

Version 4.0
]]

help(help_message,"\n")

whatis("Siesta")
whatis("Version: 4.0")
whatis("Category: application, chemistry")
whatis("Keywords: Chemistry, Molecular Dynamics, Application")
whatis("Description: Spanish Initiative for Electronic Simulations with Thousands of Atoms")
whatis("URL: http://www.icmab.es/siesta")

help(help_message,"\n")

local siesta_dir="/opt/apps/intel18/impi18_0/siesta/4.0"
setenv("TACC_SIESTA_DIR", siesta_dir)
setenv("TACC_SIESTA_BIN", pathJoin(siesta_dir, "bin"))
prepend_path("PATH",      pathJoin(siesta_dir, "bin"))


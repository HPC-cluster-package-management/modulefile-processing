help( [[
The Zoltan module defines the following environment variables:
TACC_ZOLTAN_INC and TACC_ZOLTAN_LIB for the location
of the Zoltan include files and libraries.

Version 3.83
]] )

whatis( "Name: Zoltan" )
whatis( "Version: 3.83" )
whatis( "Category: library, mathematics" )
whatis( "URL: http://graal.ens-lyon.fr/ZOLTAN/" )
whatis( "Description: Numerical library for sparse solvers" )

local             zoltan_arch =    "skylake-cxxcomplexdebug"
local             zoltan_dir  =     "/home1/apps/intel18/impi18_0/petsc/3.9/"
local             zoltan_inc  = pathJoin(zoltan_dir,zoltan_arch,"include")
local             zoltan_lib  = pathJoin(zoltan_dir,zoltan_arch,"lib")

prepend_path("LD_LIBRARY_PATH", zoltan_lib)

setenv("TACC_ZOLTAN_INC",        zoltan_inc )
setenv("TACC_ZOLTAN_LIB",        zoltan_lib)

help( [[
The P4EST modulefile defines the following environment variables:
TACC_P4EST_DIR, TACC_P4EST_LIB, and TACC_P4EST_INC 
for the location of the P4EST 2.0 distribution, 
libraries, and include files, respectively.\n

Version %{p4estversion}
]] )

whatis( "Name: P4est 'p4-est of octrees'" )
whatis( "Version: 2.0-" )
whatis( "Version-notes: " )
whatis( "Category: library, mathematics" )
whatis( "URL: https://github.com/cburstedde/p4est" )
whatis( "Description: octree support for dealii" )

local             p4est_dir =     "/home1/apps/intel18/impi18_0/p4est/2.0"

prepend_path("LD_LIBRARY_PATH", pathJoin(p4est_dir,"lib") )
prepend_path("PATH", pathJoin(p4est_dir,"bin") )

setenv(          "P4EST_DIR",             p4est_dir)
setenv(          "TACC_P4EST_DIR",        p4est_dir)
setenv(          "TACC_P4EST_BIN",        pathJoin(p4est_dir,"bin"))
setenv(          "TACC_P4EST_INC",        pathJoin(p4est_dir,"include"))
setenv(          "TACC_P4EST_LIB",        pathJoin(p4est_dir,"lib"))


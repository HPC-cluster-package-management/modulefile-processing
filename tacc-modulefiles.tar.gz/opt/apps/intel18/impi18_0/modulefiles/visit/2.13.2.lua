help([[
The VISIT module defines the following environment variables:
TACC_VISIT_DIR, TACC_VISIT_LIB, TACC_VISIT_INC, and
TACC_VISIT_BIN for the location of the VISIT distribution, libraries,
include files, and tools respectively. 
]])

--help(help_msg)
--help(help_msg)


whatis("Name: visit")
whatis("Version: 2.13.2")
whatis("Category: application, visualization")
whatis("Description: a parallel visualization suite based in part on VTK")
whatis("URL: https://wci.llnl.gov/simulation/computer-codes/visit")


local visit_dir = "/home1/apps/intel18/impi18_0/visit/2.13.2"
local SWRLIB = os.getenv("TACC_SWR_LIB") or " "

family("visit")

--conflict visit
prereq("swr")

set_alias("visit", "visit -v 2.13.2")

prepend_path("PATH",pathJoin(visit_dir,"bin"))
prepend_path("PYTHONPATH",pathJoin(visit_dir,"current/linux-x86_64/lib/site-packages/visit"))
prepend_path("INCLUDE",pathJoin(visit_dir,"current/linux-x86_64/include"))
prepend_path("LD_LIBRARY_PATH",pathJoin(visit_dir,"current/linux-x86_64/lib"))
prepend_path("LD_LIBRARY_PATH",SWRLIB)

setenv("TACC_VISIT_DIR", visit_dir)
setenv("TACC_VISIT_INC", pathJoin(visit_dir,"2.13.2/linux-x86_64/include"))
setenv("TACC_VISIT_LIB", pathJoin(visit_dir,"2.13.2/linux-x86_64/lib"))
setenv("TACC_VISIT_BIN", pathJoin(visit_dir,"2.13.2/linux-x86_64/bin"))

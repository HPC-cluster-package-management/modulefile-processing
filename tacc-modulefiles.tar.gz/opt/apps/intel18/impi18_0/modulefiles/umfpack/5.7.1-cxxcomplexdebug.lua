help( [[
The Umfpack module defines the following environment variables:
TACC_UMFPACK_INC and TACC_UMFPACK_LIB for the location
of the Umfpack include files and libraries.

Version 5.7.1
]] )

whatis( "Name: Umfpack" )
whatis( "Version: 5.7.1" )
whatis( "Category: library, mathematics" )
whatis( "URL: http://faculty.cse.tamu.edu/davis/suitesparse.html" )
whatis( "Description: Numerical library for sparse solvers" )

local             umfpack_arch =    "knightslanding-cxxcomplexdebug"
local             umfpack_dir  =     "/home1/apps/intel18/impi18_0/petsc/3.8/"
local             umfpack_inc  = pathJoin(umfpack_dir,umfpack_arch,"include")
local             umfpack_lib  = pathJoin(umfpack_dir,umfpack_arch,"lib")

prepend_path("LD_LIBRARY_PATH", umfpack_lib)

setenv("TACC_UMFPACK_INC",        umfpack_inc )
setenv("TACC_UMFPACK_LIB",        umfpack_lib)

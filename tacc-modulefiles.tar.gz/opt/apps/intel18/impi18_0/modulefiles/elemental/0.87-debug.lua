help( [[
The Elemental module defines the following environment variables:
TACC_ELEMENTAL_INC and TACC_ELEMENTAL_LIB for the location
of the Elemental include files and libraries.

Version 0.87
]] )

whatis( "Name: Elemental" )
whatis( "Version: 0.87" )
whatis( "Category: library, mathematics" )
whatis( "URL: http://graal.ens-lyon.fr/ELEMENTAL/" )
whatis( "Description: Numerical library for sparse solvers" )

local             elemental_arch =    "skylake-debug"
local             elemental_dir  =     "/home1/apps/intel18/impi18_0/petsc/3.10/"
local             elemental_inc  = pathJoin(elemental_dir,elemental_arch,"include")
local             elemental_lib  = pathJoin(elemental_dir,elemental_arch,"lib")

prepend_path("LD_LIBRARY_PATH", elemental_lib)

setenv("TACC_ELEMENTAL_INC",        elemental_inc )
setenv("TACC_ELEMENTAL_LIB",        elemental_lib)

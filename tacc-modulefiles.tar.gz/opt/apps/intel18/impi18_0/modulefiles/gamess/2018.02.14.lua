local help_message=[[
The GAMESS modulefile defines the following environment variables:
TACC_GAMESS_DIR/BIN/DOC/DATA/TOOLS for the location of the Gamess home,
documentation, binaries and aux data directories, respectively.
The modulefile defines GMSPATH (Gamess dir) used in rungms.

To run GAMESS, include the following lines in your job script.

       module load gamess
       rungms my_molecule or
       rungms my_molecule NCPUS

where my_molecule is the input file name. The input file must have an .inp suffix.
But it is not necessary to include the suffix in the name used on the rungms command.

The gamess.00.x executable is a fat binary-- it is compiled to run on either the
KNL or SKX nodes.  When running on a single KNL node the number of cpus requested 
(NCPUS) should be the number of cores on a node (68); this will create 68 processes 
on a node for running compute services, and another 68 processes for running data
services.  If you run on multiple nodes (N=2,3,4, etc.), make sure that NCPUS/N = 68.

***** IMPORTANT for SKYLAKE execution ****************
The present version of GAMESS will not run correctly if more than 48 services are
launched on a node. You should set NCPUS to be 24 for single-node execution, and
NCPUS/N = 24 when more than 1 node (N nodes) are to be used.  The rungms script
will not allow you to run more than 24 services per node.

e.g. for an h2.inp input file you can run gamess with

      rungms h2.inp  or rungms h2

(rungms uses a special mpirun launcher, mpiexec.hydra, to launch gamess, so you do not
need to use ibrun.)

NCPUS is number of computing processes you want to use and the default value is the total
tasks requested in the slurm job script. (This should be half the number of cores on a node.
The other half of the cores will be used a data servers.)

If you need to use the QUANPOL/RXNFLD3840.DAT data file please contact TACC.
The virtual memory for the GAMESS knl version has been reduced, by eliminating the
space bloat of the Effective Fragment Potential (EFP) module.  
If you need to use this method, please contact TACC.

Version 2018.02.14

]]

help(help_message,"\n")

whatis("Name: tacc-gamess-intel18-impi18_0")
whatis("Version: 2018.02.14")
whatis("Category: application, chemistry")
whatis("Keywords: Chemistry, Quantum, Application")
whatis("URL: http://www.msg.ameslab.gov/GAMESS/")
whatis("Description: General ab initio quantum chemistry package")

local gms_dir="/opt/apps/intel18/impi18_0/gamess/2018.02.14"
local intel_dir="$TACC_INTEL_LIB"
--
-- TACC Variables

whatis("Name: gamess")
whatis("Version: 2018.02.14")


-- Create environment variables.
local gms_dir           = "/opt/apps/intel18/impi18_0/gamess/2018.02.14"

family("GAMESS")

setenv("TACC_GAMESS_DIR",  gms_dir)
setenv("TACC_GAMESS_BIN",  gms_dir)
setenv("TACC_GAMESS_DOC",  pathJoin(gms_dir,"doc")     )
setenv("TACC_GAMESS_TOOLS",pathJoin(gms_dir,"tools")   )
setenv("TACC_GAMESS_DATA", pathJoin(gms_dir,"auxdata") )

--
-- GMS Variables and PATH append
--

setenv("VERNO",                 "00"      )
setenv("GMSPATH",               gms_dir   )
prepend_path("PATH",            gms_dir   )
prepend_path("LD_LIBRARY_PATH", intel_dir )


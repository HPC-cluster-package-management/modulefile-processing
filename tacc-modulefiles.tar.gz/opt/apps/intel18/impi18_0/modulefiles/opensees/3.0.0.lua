local help_msg=[[
The OPENSEES module file defines the following environment variables:
TACC_OPENSEES_DIR, TACC_OPENSEES_LIB, and TACC_OPENSEES_BIN for
the location of the tacc-opensees-intel18-impi18_0 distribution, 
libraries, and excutables,respectively. 
It also appends the path to the executables
to the PATH environment variable.

The excutables of OPENSEES include:

OpenSees	Sequential version
OpenSeesSP	Parallel version in master-worker mode
OpenSeesMP	Parallel version for parameter studies

Note that the libOpenSees.a is the version that goes with OpenSeesMP.

This version is built with the following modules enabled:

intel/18.0.2 impi/18.0.2 petsc/3.10

Version 3.0.0
]]

--help(help_msg)
help(help_msg)

whatis("OpenSees: Open System for Earthquake Engineering Simulation")
whatis("Version: 3.0.0")
whatis("Category: application, geoscience")
whatis("Keywords: Earthquake, Simulation")
whatis("Description: Software framework for developing applications to simulate the performance of structural and geotechnical systems subjected to earthquakes")
whatis("URL: http://opensees.berkeley.edu/")
prereq("petsc/3.10")



-- Create environment variables.
local opensees_dir           = "/work/projects/wma_apps/stampede2/opensees/opensees-3.0.0"

family("opensees")
prepend_path(    "PATH",                pathJoin(opensees_dir, "bin"))
setenv( "TACC_OPENSEES_DIR",                opensees_dir)
setenv( "TACC_OPENSEES_LIB",       pathJoin(opensees_dir, "lib"))
setenv( "TACC_OPENSEES_BIN",       pathJoin(opensees_dir, "bin"))

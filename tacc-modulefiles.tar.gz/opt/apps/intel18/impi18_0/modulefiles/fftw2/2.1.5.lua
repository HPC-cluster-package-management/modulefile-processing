local help_message = [[
The FFTW2 modulefile defines the following environment variables:
TACC_FFTW2_DIR, TACC_FFTW2_LIB, and TACC_FFTW2_INC
for the location of the FFTW 2.1.5 distribution,
libraries, and include files, respectively.

To use the FFTW library, compile the source code with the option:

        -I$TACC_FFTW2_INC

and add the following options to the link step for double precision:

        -L$TACC_FFTW2_LIB -ldrfftw -ldfftw

For single precison, link with:

        -L$TACC_FFTW2_LIB -lsrfftw -lsfftw

Version 2.1.5
]]

help(help_message,"\n")

whatis("Name: FFTW 2")
whatis("Version: 2.1.5")
whatis("Category: library, mathematics")
whatis("Keywords: Library, Mathematics, FFT")
whatis("URL: http://www.fftw.org")
whatis("Description: Numerical library, contains discrete Fourier transformation")


local fftw_dir="/home1/apps/intel18/impi18_0/fftw2/2.1.5"

setenv("TACC_FFTW2_DIR",fftw_dir)
setenv("TACC_FFTW2_LIB",pathJoin(fftw_dir,"lib"))
setenv("TACC_FFTW2_INC",pathJoin(fftw_dir,"include"))


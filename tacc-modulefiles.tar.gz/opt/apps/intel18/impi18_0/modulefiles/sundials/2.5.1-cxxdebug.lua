help( [[
The Sundials module defines the following environment variables:
TACC_SUNDIALS_INC and TACC_SUNDIALS_LIB for the location
of the Sundials include files and libraries.

Version 2.5.1
]] )

whatis( "Name: Sundials" )
whatis( "Version: 2.5.1" )
whatis( "Category: library, mathematics" )
whatis( "URL: http://crd-legacy.lbl.gov/~xiaoye/Sundials/" )
whatis( "Description: Numerical library for sparse solvers" )

local             sundials_arch =    "skylake-cxxdebug"
local             sundials_dir  =     "/home1/apps/intel18/impi18_0/petsc/3.10/"
local             sundials_inc  = pathJoin(sundials_dir,sundials_arch,"include","sundials")
local             sundials_lib  = pathJoin(sundials_dir,sundials_arch,"lib")

prepend_path("LD_LIBRARY_PATH", sundials_lib)

setenv("TACC_SUNDIALS_INC",        sundials_inc )
setenv("TACC_SUNDIALS_LIB",        sundials_lib)

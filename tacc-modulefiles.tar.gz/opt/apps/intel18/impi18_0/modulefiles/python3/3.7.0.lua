inherit()
whatis("Version-notes: Compiler:intel18. MPI:impi18_0")
prepend_path("PYTHONPATH", "/opt/apps/intel18/impi18_0/python3/3.7.0/lib/python3.7/site-packages")

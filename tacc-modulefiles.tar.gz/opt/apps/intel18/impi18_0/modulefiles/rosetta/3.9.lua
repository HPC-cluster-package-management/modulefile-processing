local help_msg=[[
The Rosetta software suite includes algorithms for computational modeling and
analysis of protein structures. It has enabled notable scientific advances in
computational biology, including de novo protein design, enzyme design, ligand
docking, and structure prediction of biological macromolecules and
macromolecular complexes.

The ROSETTA module defines the following environment variables:
TACC_ROSETTA_DIR, TACC_ROSETTA_BIN, and TACC_ROSETTA_DATABASE
for the location of the ROSETTA distribution, binaries, and database
respectively.

NOTE: ROSETTA is hard-coded to attempt to write temporary files within
the designated database location. This action will fail if the user sets
-database=$TACC_ROSETTA_DATABASE. Instead, copy the database from
TACC_ROSETTA_DATABASE to a writable location via something like:

cp -r $TACC_ROSETTA_DATABASE $WORK/rosetta_database

Then, to run:

$TACC_ROSETTA_BIN/<rosetta-executable>.mpi.linuxiccrelease [options] -database=$WORK/rosetta_database

Version 3.9
]]

local err_message = [[
You do not have access to rosetta 3.9.


Users have to show their licenses and be confirmed by the rosetta team
that they are registered users under that license.  Send a copy of the license
to https://portal.tacc.utexas.edu/tacc-consulting.
]]

local group  = "G-814534"
local grps   = capture("groups")
local found  = false
local isRoot = tonumber(capture("id -u")) == 0
for g in grps:split("[ \n]") do
   if (g == group or isRoot)  then
      found = true
      break
    end
end


--help(help_msg)
help(help_msg)

whatis("Name: rosetta")
whatis("Version: 3.9")
whatis("Category: Scientific Application")
whatis("Keywords: Molecular Dynamics, Folding, Biology")
whatis("URL: http://www.rosettacommons.org/")
whatis("Description: The premier software suite for macromolecular modeling")

if (found) then
  -- Create environment variables.
  local base_dir           = "/home1/apps/intel18/impi18_0/rosetta/3.9"
  local rosetta_lib        = "build/src/release/linux/3.10/64/x86/icc/18.0/cxx11-mpi"
  local ext_lib            = "build/external/release/linux/3.10/64/x86/icc/18.0/cxx11-mpi"


  prepend_path( "PATH",                   pathJoin(base_dir, "bin"))
  prepend_path( "LD_LIBRARY_PATH",        pathJoin(base_dir, ext_lib))
  prepend_path( "LD_LIBRARY_PATH",        pathJoin(base_dir, rosetta_lib))
  setenv( "TACC_ROSETTA_DIR",                base_dir)
  setenv( "TACC_ROSETTA_DATABASE",  pathJoin(base_dir, "database"))
  setenv( "TACC_ROSETTA_BIN",       pathJoin(base_dir, "bin"))
else
  LmodError(err_message,"\n")
end

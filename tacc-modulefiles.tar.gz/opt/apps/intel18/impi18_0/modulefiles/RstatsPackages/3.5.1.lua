help(
[[
This is the R statistics (RstatsPackages) package built on September 19, 2018.

It includes the following accessory packages including but not limited to:
Rmpi, snow, snowfall
pdbMPI, pbdSLAP, pbdBASE, pbdDMAT, pbdDEMO, pbdNCDF4, pmclust
multicore
doMC, doSNOW, doMPI, doParallel
BH, bigmemory, biganalytics, bigtabulate, synchronicity
Rdsm, SparseM, slam, cluster, randomForest, bit, ff, mchof
BioConductor (base installation plus some common packages)
ggplot2, rjags/r2jags, rgdal, rstan

The RstatsPackages modulefile extends the PATH and LD_LIBRARY_PATH paths as appropriate and creates the R_LIBS env variable.

Version 3.5.1
]]
)

--
-- Create environment variables.
--

local rstats_loaded = isloaded("Rstats/3.5.1")
if (not rstats_loaded) then
        load("Rstats/3.5.1")
end


--We want to ensure the users ~/R dir is always first, but also add these custom package locations
local r_libs   = "/opt/apps/intel18/impi18_0/RstatsPackages/3.5.1/packages" 
append_path("R_LIBS_SITE", r_libs)

local nlopt_lib = "/opt/apps/intel18/impi18_0/RstatsPackages/3.5.1/nlopt-2.4.2/lib"
prepend_path("LD_LIBRARY_PATH", nlopt_lib)

local snow_bin = "/opt/apps/intel18/impi18_0/RstatsPackages/3.5.1/packages/snow/"
local gdal_bin = "/opt/apps/intel18/impi18_0/RstatsPackages/3.5.1/gdal-2.3.1/bin"
local gdal_lib = "/opt/apps/intel18/impi18_0/RstatsPackages/3.5.1/gdal-2.3.1/lib"
local proj_lib = "/opt/apps/intel18/impi18_0/RstatsPackages/3.5.1/proj-5.1.0/lib"
local jags_bin = "/opt/apps/intel18/impi18_0/RstatsPackages/3.5.1/jags-4.3.0/bin"
local jags_lib = "/opt/apps/intel18/impi18_0/RstatsPackages/3.5.1/jags-4.3.0/lib64"
local jags_modules = "/opt/apps/intel18/impi18_0/RstatsPackages/3.5.1/jags-4.3.0/lib64/JAGS/modules-3"


prepend_path("PATH", snow_bin)
prepend_path("PATH", gdal_bin)
prepend_path("PATH", jags_bin)


prepend_path("LD_LIBRARY_PATH", gdal_lib)
prepend_path("LD_LIBRARY_PATH", proj_lib)
prepend_path("LD_LIBRARY_PATH", jags_lib)
prepend_path("LD_LIBRARY_PATH", jags_modules)



help( [[
The petsc module defines the PETSc variables
PETSC_DIR and PETSC_ARCH
as well as the following environment variables:
TACC_PETSC_DIR, TACC_PETSC_BIN, and
TACC_PETSC_LIB for the location
of the Petsc distribution, documentation, binaries,
and libraries. It also updates PATH and LD_LIBRARY_PATH.

Version 3.11; shared library support
external packages installed: chaco hypre  parmetis spai plapack sundials elemental mumps scalapack spooles suitesparse superlu (distributed/sequential) zoltan/ptscotch  
]] )

whatis( "Name: PETSc" )
whatis( "Version: 3.11; shared library support" )
whatis( "Version-notes: external packages installed:   --with-chaco=1 --download-chaco   --with-hypre=1 --download-hypre        --with-parmetis=1 --download-parmetis --with-metis=1 --download-metis   --with-plapack=1 --download-plapack --with-spai=1 --download-spai --with-sundials=1 --download-sundials      --with-elemental=1 --download-elemental --with-cxx-dialect=C++11 --with-parmetis=1 --download-parmetis --with-metis=1 --download-metis      --with-mumps=1 --download-mumps --with-parmetis=1 --download-parmetis --with-metis=1 --download-metis  --with-scalapack=1 --download-scalapack --with-blacs=1 --download-blacs --with-spooles=1 --download-spooles   --with-suitesparse=1 --download-suitesparse --with-superlu_dist=1 --download-superlu_dist    --with-superlu=1 --download-superlu --with-parmetis=1 --download-parmetis --with-metis=1 --download-metis   --with-zoltan=1 --download-zoltan=1 --download-ptscotch=1   " )
whatis( "Category: library, mathematics" )
whatis( "URL: http://www-unix.mcs.anl.gov/petsc/petsc-as/" )
whatis( "Description: Portable Extendible Toolkit for Scientific Computing, Numerical library for sparse linear algebra" )

local             petsc_arch =    "skylake-nohdf5"
local             petsc_dir =     "/home1/apps/intel18/impi18_0/petsc/3.11/"

prepend_path("PATH",            pathJoin(petsc_dir,petsc_arch,"bin") )
prepend_path("LD_LIBRARY_PATH", pathJoin(petsc_dir,petsc_arch,"lib") )

setenv("PETSC_ARCH",            petsc_arch)
setenv("PETSC_DIR",             petsc_dir)
setenv("TACC_PETSC_DIR",        petsc_dir)
setenv("TACC_PETSC_BIN",        pathJoin(petsc_dir,petsc_arch,"bin") )
setenv("TACC_PETSC_INC",        pathJoin(petsc_dir,petsc_arch,"include") )
setenv("TACC_PETSC_LIB",        pathJoin(petsc_dir,petsc_arch,"lib") )

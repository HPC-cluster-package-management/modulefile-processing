local help_message = [[
GPAW is a density-functional theory (DFT) Python code based on the 
projector-augmented wave (PAW) method and the atomic simulation 
environment (ASE). The wave functions can be described with:

  * Plane-waves (pw)
  * Real-space uniform grids, multigrid methods and the finite-difference approximation (fd)
  * Atom-centered basis-functions (lcao)

- To run GPAW program, use the following lines in the job script. 
  Vary the "-N" and "-n" directives base on your need.

     #SBATCH -N 1          # E.g. requesting 1 node
     #SBATCH -n 16         #      and 16 MPI tasks

     module load python3/3.7.0
     module load gpaw

     gpaw script.py               (serial)

     or

     ibrun gpaw-python script.py  (parallel)

- ENVIRONMENT VARIABLES 
      
  The GPAW module defines a set of environment variables for the locations of the 
  GPAW home, binaries, libraries and more with the prefix "TACC_GPAW_"
  Use the "env" command to display the variables:

      $ env | grep "TACC_GPAW"

- DATABASE and EXTERNAL LIBRARIES

  * Atomic PAW Setups
    gpaw-setups-0.9.20000 is located in the directory $GPAW_SETUP_PATH
    https://wiki.fysik.dtu.dk/gpaw/setups/setups.html    

  * LIBXC (4.3.0)
    http://www.tddft.org/programs/libxc/

  * LIBVDWXC (0.3.2)
    https://libvdwxc.org/

  * FFTW3 (3.3.6)
    http://www.fftw.org/

  * BLAS/BLACS/LAPACK/ScaLAPACK/Intel MKL (2017.4.196)

- REFERENCE
      
  Gpaw website: https://wiki.fysik.dtu.dk/gpaw

  Version 1.5.1
]]

help(help_message,"\n")

whatis("Name: Gpaw")
whatis("Version: 1.5.1")
whatis("Category: application, chemistry")
whatis("Keywords: Chemistry, Quantum, DFT, Application")
whatis("URL:  https://wiki.fysik.dtu.dk/gpaw")
whatis("Description: GPAW is a density-functional theory (DFT) Python code")

local gpaw_dir="/opt/apps/intel18/impi18_0/gpaw/1.5.1"

setenv("TACC_GPAW_DIR"              ,gpaw_dir)
setenv("TACC_GPAW_BIN"              ,pathJoin(gpaw_dir,"bin"))
setenv("TACC_GPAW_LIB"              ,pathJoin(gpaw_dir,"lib"))
setenv("TACC_GPAW_INC"              ,pathJoin(gpaw_dir,"include"))
setenv("GPAW_SETUP_PATH"            ,pathJoin(gpaw_dir,"gpaw-setups-0.9.20000"))

load("fftw3/3.3.6")
depends_on("python3/3.7.0")

append_path("PATH",pathJoin(gpaw_dir,"bin"))
append_path("PATH",pathJoin(gpaw_dir,"ase/tools"))
prepend_path("PYTHONPATH",pathJoin(gpaw_dir,"lib"))
prepend_path("PYTHONPATH",pathJoin(gpaw_dir,"lib/python3.7/site-packages/"))
prepend_path("PYTHONPATH",pathJoin(gpaw_dir,"lib/python3.7/site-packages/pylibxc-4.3.0-py3.7-linux-x86_64.egg/"))
prepend_path("PYTHONPATH",pathJoin(gpaw_dir,"ase"))
prepend_path("LD_LIBRARY_PATH",pathJoin(gpaw_dir,"lib"))


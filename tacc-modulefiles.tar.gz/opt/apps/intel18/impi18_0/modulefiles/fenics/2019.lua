help( [[
The fenics module defines the Fenics variable
TACC_FENICS_DIR for the location
of the Fenics distribution. It also updates PYTHONPATH.

Version 2019
external packages installed: 
]] )

whatis( "Name: Fenics" )
whatis( "Version: 2019" )
whatis( "Version-notes: external packages installed: " )
whatis( "Category: library, mathematics" )
whatis( "URL: https://fenicsproject.org/" )
whatis( "Description: Portable Extendible Toolkit for Scientific Computing, Numerical library for sparse linear algebra" )

local             fenics_dir =     "/home1/apps/intel18/impi18_0/fenics/2019/"

prepend_path("PYTHONPATH",      pathJoin(fenics_dir,"dolfin","python") )
prepend_path("PYTHONPATH",      pathJoin(fenics_dir,"dolfin","python","src") )
prepend_path("PYTHONPATH",
      pathJoin(fenics_dir,"python","lib","python3.7","site-packages") )

setenv("FENICS_DIR",             fenics_dir)
setenv("TACC_FENICS_DIR",        fenics_dir)

depends_on("boost/1.65")
depends_on("python3")
depends_on("petsc/3.11")
depends_on("slepc/3.11")

local help_message = [[
LAMMPS (Large-scale Atomic/Molecular Massively Parallel Simulator) 
is a classical molecular dynamics code developed at Sandia 
National Laboratories. 

- TO RUN LAMMPS

Set the number of nodes (N) and MPI tasks (n) in the job script.

  E.g. One node with two MPI tasks 

    #SBATCH -N 1
    #SBATCH -n 2

Load required modules and set library paths

  $ module load intel/18.0.2
  $ module load impi/18.0.2
  $ module load lammps/16Mar18

Run LAMMPS program

  * Basic

    ibrun lmp_stampede -in lammps_input > log_file

  * Use USER-OMP package (E.g. with 2 omp threads)

    ibrun lmp_stampede -sf omp -pk omp 2 -in lammps_input > log_file

  * Use USER-INTEL package (E.g. with 2 omp threads)

    ibrun lmp_stampede -sf intel -pk intel 0 omp 2 -in lammps_input > log_file

- ENVIRONMENT VARIABLES 

The LAMMPS modulefile defines the following environment 
variables (with the prefix "TACC_LAMMPS_"):

TACC_LAMMPS_DIR/BIN/BENCH/EXAM/LIB/POT/PYTHON/SRC/TOOLS

for the location of the LAMMPS home, binaries, benchmarks, examples, 
libraries, potentials, python, source, and tools, respectively.
The modulefile also appends TACC_LAMMPS_BIN & TACC_LAMMPS_TOOLS to PATH.

Folders "benchmark" and "examples" are now kept in the
/work/apps/lammps/production_src/16Mar18 directory.

Not all the tools are compiled and included in the TOOLS directory.

- PACKAGES

The following packages were not installed:

  GPU, KOKKOS, LATTE, MSCG, REAX, USER-MOLFILE, USER-QMMM, USER-VTK

Library REAX was not compiled with this version, because the default virtual 
space of the library consumes 1.6 GB/task (for a total of 2.2 GB per task), and
the TACC monitor kills jobs that use over 2.0 GB/task (32 GB for 16 tasks).

Information of external libraries:

  * OpenKIM
    kim-api-v1.9.6
    https://openkim.org

    The KIM package defines environment variables KIM_API_MODELS_DIR and 
    KIM_API_MODEL_DRIVERS_DIR for the locations of the installed KIM models 
    and model drivers. Use command : 
    
      $ kim-api-v1-collections-management list
    
    to show the collections.

  * QUIP
    https://github.com/libAtoms/QUIP.git

  * VORONOI  
    voro++-0.4.6
    http://math.lbl.gov/voro++/download/dir/voro++-0.4.6.tar.gz
    
  * USER-SMD
    Eigen-3.3.4
    https://github.com/eigenteam/eigen-git-mirror.git

- LIBRARIES

  LAMMPS libraries liblammps_stampede.a (static), liblammps_stampede.so (dynamic) are kept in TACC_LAMMPS_LIB/lammps.

- REFERENCE

  LAMMPS website: http://lammps.sandia.gov
  LAMMPS at TACC: https://portal.tacc.utexas.edu/software/lammps     

Version 16Mar18
]]

help(help_message,"\n")

whatis("Name: LAMMPS")
whatis("Version: 16Mar18")
whatis("Category: application, chemistry")
whatis("Keywords: Chemistry, Biology, Molecular Dynamics, Application")
whatis("URL:  http://lammps.sandia.gov/index.html")
whatis("Description: Molecular Dynamics Chemistry Package")

local lmp_dir="/opt/apps/intel18/impi18_0/lammps/16Mar18"
local lmp_example_dir="/work/apps/lammps/production_src/16Mar18/"

setenv("TACC_LAMMPS_DIR"       ,lmp_dir)
setenv("TACC_LAMMPS_BIN"       ,pathJoin(lmp_dir,"bin"))
setenv("TACC_LAMMPS_LIB"       ,pathJoin(lmp_dir,"lib"))
setenv("TACC_LAMMPS_POT"       ,pathJoin(lmp_dir,"potentials"))
setenv("TACC_LAMMPS_PYTHON"    ,pathJoin(lmp_dir,"python"))
setenv("TACC_LAMMPS_TOOLS"     ,pathJoin(lmp_dir,"tools"))

setenv("TACC_LAMMPS_BENCH"     ,pathJoin(lmp_example_dir,"bench"))
setenv("TACC_LAMMPS_EXAM"      ,pathJoin(lmp_example_dir,"examples"))
setenv("TACC_LAMMPS_SRC"       ,pathJoin(lmp_dir,"src"))

local kim_dir="/opt/apps/intel18/impi18_0/lammps/16Mar18/lib/kim/"
local kim_model_dir="/opt/apps/intel18/impi18_0/lammps/16Mar18/lib/kim/kim_env_collection/models"
local kim_driver_dir="/opt/apps/intel18/impi18_0/lammps/16Mar18/lib/kim/kim_env_collection/model_drivers"

append_path("PATH",pathJoin(lmp_dir,"bin"))
append_path("PATH",pathJoin(lmp_dir,"lib/ffmpeg/bin"))
append_path("PATH",pathJoin(lmp_dir,"tools"))
append_path("PATH","/opt/apps/gcc7_1/impi18_0/kim/1.9.6/kim-api/bin")

setenv("TACC_KIM_DIR"              ,kim_dir)
setenv("TACC_KIM_API"              ,pathJoin(kim_dir,"kim-api"))
setenv("TACC_KIM_MODEL"            ,kim_model_dir)
setenv("TACC_KIM_DRIVER"           ,kim_driver_dir)
setenv("KIM_API_MODELS_DIR"        ,kim_model_dir)
setenv("KIM_API_MODEL_DRIVERS_DIR" ,kim_driver_dir)

append_path("LD_LIBRARY_PATH",pathJoin(lmp_dir,"lib/ffmpeg/lib"))
append_path("LD_LIBRARY_PATH",pathJoin(lmp_dir,"lib/lammps"))
append_path("LD_LIBRARY_PATH","/opt/apps/gcc/7.1.0/lib64/")
append_path("LD_LIBRARY_PATH","/opt/intel/compilers_and_libraries_2018.2.199/linux/mkl/lib/intel64_lin/")
append_path("LD_LIBRARY_PATH","/opt/intel/compilers_and_libraries_2018.2.199/linux/compiler/lib/intel64_lin/")
append_path("LD_LIBRARY_PATH","/opt/apps/intel18/hdf5/1.8.16/x86_64/lib/")

prepend_path("PYTHONPATH", pathJoin(lmp_dir,"python"))
prepend_path("PYTHONPATH", pathJoin(lmp_dir,"lib/lammps"))


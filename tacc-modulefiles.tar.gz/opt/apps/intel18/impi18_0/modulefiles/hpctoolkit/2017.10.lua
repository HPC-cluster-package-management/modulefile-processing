local help_msg=[[
The HPCTOOLKIT module defines the following environment variables:
TACC_HPCTOOLKIT_DIR, TACC_HPCTOOLKIT_LIB, TACC_HPCTOOLKIT_INC and
TACC_HPCTOOLKIT_BIN for the location of the HPCTOOLKIT distribution, libraries,
include files, and tools respectively.

To use hpctoolkit compile your source with debugging flags:

icc   -g -debug inline-debug-info <source.c>
mpicc -g -debug inline-debug-info <mpi_source.c>

Then run your code in the batch system using hpcrun:

(serial/threaded): hpcrun <executable>
(mpi/hybrid):      ibrun hpcrun <executable>

This will create a directory with the collected measurements.
Once the run is complete obtain the static structure of the program :

hpcstruct <executable>

Then form the database from the measurements:

(serial/threaded): hpcprof     -S <executable.hpcstruct> <measurementDirName>
(mpi/hybrid):      hpcprof-mpi -S <executable.hpcstruct> <measurementDirName>

This will create a database directory that can then be examined:

hpcviewer <databaseDirName>

For more details go to http://www.hpctoolkit.org

Version 2017.10
]]

--help(help_msg)
help(help_msg)

whatis("Name: HPCToolkit")
whatis("Version: 2017.10")
whatis("Category: application,HPC ")
whatis("Keywords: HPC, profiling, parallel, performance")
whatis("URL: http://www.hpctoolkit.org")
whatis("Description: Profiler")

-- Create environment variables.
local hpct_dir          = "/opt/apps/intel18/impi18_0/hpctoolkit/2017.10"

prepend_path(    "PATH",                pathJoin(hpct_dir, "bin"))
setenv( "TACC_HPCTOOLKIT_DIR",       hpct_dir)
setenv( "TACC_HPCTOOLKIT_LIB",       pathJoin(hpct_dir, "lib"))
setenv( "TACC_HPCTOOLKIT_INC",       pathJoin(hpct_dir, "include"))
setenv( "TACC_HPCTOOLKIT_BIN",       pathJoin(hpct_dir, "bin"))

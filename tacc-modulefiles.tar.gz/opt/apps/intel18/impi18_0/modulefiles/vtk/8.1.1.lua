help([[
The VTK module defines the following environment variables:
TACC_VTK_DIR, TACC_VTK_LIB, TACC_VTK_INC, and
TACC_VTK_BIN for the location of the VTK distribution, libraries,
include files, and tools respectively.
]])

--help(help_msg)
--help(help_msg)

whatis("Name: vtk")
whatis("Version: 8.1.1%{dgb}")
whatis("Category: application, visualization")
whatis("Description: a C++ visualization library")
whatis("URL: https/www.vtk.org")


local vtk_dir ="/home1/apps/intel18/impi18_0/vtk/8.1.1"

family("vtk")

--conflict vtk
prereq("qt5")

prepend_path("PATH",pathJoin(vtk_dir,"bin"))
prepend_path("LD_LIBRARY_PATH",pathJoin(vtk_dir,"lib"))
prepend_path("INCLUDE",pathJoin(vtk_dir,"include"))
prepend_path("PYTHONPATH",pathJoin(vtk_dir,"lib/python2.7/site-packages/vtk"))
prepend_path("PYTHONPATH",pathJoin(vtk_dir,"lib/site-packages/mpi4py"))

setenv("TACC_VTK_DIR", vtk_dir)
setenv("TACC_VTK_INC", pathJoin(vtk_dir,"include"))
setenv("TACC_VTK_LIB", pathJoin(vtk_dir,"lib"))
setenv("TACC_VTK_BIN", pathJoin(vtk_dir,"bin"))
setenv("VTK_LOCATION",vtk_dir)

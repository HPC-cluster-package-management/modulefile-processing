help( [[
The Parmetis module defines the following environment variables:
TACC_PARMETIS_INC and TACC_PARMETIS_LIB for the location
of the Parmetis include files and libraries.

Version 4.0
]] )

whatis( "Name: Parmetis" )
whatis( "Version: 4.0" )
whatis( "Category: library, mathematics" )
whatis( "URL: http://graal.ens-lyon.fr/PARMETIS/" )
whatis( "Description: Numerical library for sparse solvers" )

local             parmetis_arch =    "knightslanding-cxxcomplexdebug"
local             parmetis_dir  =     "/home1/apps/intel18/impi18_0/petsc/3.10/"
local             parmetis_inc  = pathJoin(parmetis_dir,parmetis_arch,"include")
local             parmetis_lib  = pathJoin(parmetis_dir,parmetis_arch,"lib")

prepend_path("LD_LIBRARY_PATH", parmetis_lib)

setenv("TACC_PARMETIS_INC",        parmetis_inc )
setenv("TACC_PARMETIS_LIB",        parmetis_lib)

conflict("pmetis")

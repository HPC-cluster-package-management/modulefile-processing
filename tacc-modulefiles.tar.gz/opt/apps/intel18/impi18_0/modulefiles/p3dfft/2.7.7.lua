
local help_message=[[
P3DFFT is a highly scalable numerical library for programs running on 
parallel computers. P3DFFT implements Fourier Transforms in three 
dimensions as well as related algorithms, in a highly efficient manner.
More information may be found at: https://portal.xsede.org/software/p3dfft

The p3dfft modulefile defines the following environment variables
for the double-precison, stride-1 optimized version of the 
library:
    $TACC_P3DFFT_DIR 
    $TACC_P3DFFT_LIB
    $TACC_P3DFFT_INC
    $TACC_P3DFFT_TESTS

To use the p3dfft library, compile your source code with:

	-I$TACC_P3DFFT_INC

and add the following options to the link step:

	-Wl,-rpath,$TACC_P3DFFT_LIB  -L$TACC_P3DFFT_LIB -lp3dfft

Other versions of the p3dfft libraries that are optimized for 
single-precision calculations or non-contiguous data are available.  
Please refer to the software distribution page for more details:
    https://code.google.com/p/p3dfft 

To use one of the the other libraries, use the appropriate environment 
variable for compiling and linking.

Single Precision, stride-1:
    $TACC_P3DFFT_SINGLE_LIB
    $TACC_P3DFFT_SINGLE_INC

Single Precision, non-contiguous:
    $TACC_P3DFFT_SINGLE_NONCONTIG_LIB
    $TACC_P3DFFT_SINGLE_NONCONTIG_INC

Double Precision, non-contiguous:
    $TACC_P3DFFT_NONCONTIG_LIB
    $TACC_P3DFFT_NONCONTIG_INC


Version 2.7.7
]]

help(help_message,"\n")

whatis("Name: p3dfft ")
whatis("Version: 2.7.7")
whatis("Category: library, mathematics")
whatis("Keywords: Library, Mathematics, FFT, Parallel")
whatis("URL: https://code.google.com/p/p3dfft ")
whatis("Description: Numerical library, contains discrete Fourier transformation")

--  Regular build, double precision, stride 1
local p3dfft_dir="/opt/apps/intel18/impi18_0/p3dfft/2.7.7"
setenv("TACC_P3DFFT_DIR",p3dfft_dir)
setenv("TACC_P3DFFT_LIB",pathJoin(p3dfft_dir,"lib"))
setenv("TACC_P3DFFT_INC",pathJoin(p3dfft_dir,"include"))
setenv("TACC_P3DFFT_TESTS",pathJoin(p3dfft_dir,"share/p3dfft-samples"))

--  build, double precision, non-contiguous
local p3dfft_dir="/opt/apps/intel18/impi18_0/p3dfft/2.7.7/noncontiguous"
setenv("TACC_P3DFFT_NONCONTIG_LIB",pathJoin(p3dfft_dir,"lib"))
setenv("TACC_P3DFFT_NONCONTIG_INC",pathJoin(p3dfft_dir,"include"))

--  build, single precision, stride1
local p3dfft_dir="/opt/apps/intel18/impi18_0/p3dfft/2.7.7/single_stride1"
setenv("TACC_P3DFFT_SINGLE_LIB",pathJoin(p3dfft_dir,"lib"))
setenv("TACC_P3DFFT_SINGLE_INC",pathJoin(p3dfft_dir,"include"))

--  build, single precision, non-contiguous
local p3dfft_dir="/opt/apps/intel18/impi18_0/p3dfft/2.7.7/single_noncontiguous"
setenv("TACC_P3DFFT_SINGLE_NONCONTIG_LIB",pathJoin(p3dfft_dir,"lib"))
setenv("TACC_P3DFFT_SINGLE_NONCONTIG_INC",pathJoin(p3dfft_dir,"include"))

--
-- Append paths
-- only for default install
append_path("LD_LIBRARY_PATH",pathJoin(p3dfft_dir,"lib"))

help( [[
The PETSC4PY modulefile defines the following environment variables:
TACC_PETSC4PY_DIR
for the location of the PETSC4PY 3.10 distribution;
it also updates PYTHONPATH.

Version 3.10-cxxdebug
]] )

whatis( "Name: Petsc4py" )
whatis( "Version: 3.10-cxxdebug" )
whatis( "Version-notes: 3.10-cxxdebug" )
whatis( "Category: library, mathematics" )
whatis( "URL: https://bitbucket.org/petsc/petsc4py/" )
whatis( "Description: python interface to PETSc" )

local             petsc_arch =    "skylake-cxxdebug"
local             petsc4py_dir =     "/home1/apps/intel18/impi18_0/petsc4py/3.10"

prepend_path("PYTHONPATH", pathJoin(petsc4py_dir,"lib","python2.7","site-packages") )

setenv(          "TACC_PETSC4PY_DIR",        petsc4py_dir)

prereq("petsc/3.10-cxxdebug")

help( [[
The Superlu module defines the following environment variables:
TACC_SUPERLU_INC and TACC_SUPERLU_LIB for the location
of the Superlu include files and libraries.

Version 5.1
]] )

whatis( "Name: Superlu" )
whatis( "Version: 5.1" )
whatis( "Category: library, mathematics" )
whatis( "URL: http://graal.ens-lyon.fr/SUPERLU/" )
whatis( "Description: Numerical library for sparse solvers" )

local             superlu_arch =    "skylake-cxxcomplex"
local             superlu_dir  =     "/home1/apps/intel18/impi18_0/petsc/3.8/"
local             superlu_bin  = pathJoin(superlu_dir,"bin")
local             superlu_inc  = pathJoin(superlu_dir,superlu_arch,"include")
local             superlu_lib  = pathJoin(superlu_dir,superlu_arch,"lib")

setenv("TACC_SUPERLU_DIR",        superlu_dir )
setenv("TACC_SUPERLU_BIN",        superlu_bin )
setenv("TACC_SUPERLU_INC",        superlu_inc )
setenv("TACC_SUPERLU_LIB",        superlu_lib)

prepend_path("LD_LIBRARY_PATH", superlu_lib)


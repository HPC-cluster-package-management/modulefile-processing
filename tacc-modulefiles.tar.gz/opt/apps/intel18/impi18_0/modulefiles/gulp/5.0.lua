local help_msg=[[
GULP is a program for performing a variety of types of simulation on materials
using boundary conditions of 0-D (molecules and clusters), 1-D (polymers), 2-D
(surfaces, slabs and grain boundaries), or 3-D (periodic solids). The focus of
the code is on analytical solutions, through the use of lattice dynamics, where
possible, rather than on molecular dynamics. A variety of force fields can be
used within GULP spanning the shell model for ionic materials, molecular
mechanics for organic systems, the embedded atom model for metals and the
reactive REBO potential for hydrocarbons. Analytic derivatives are included up
to at least second order for most force fields, and to third order for many.

The GULP module file defines the following environment variables:\n
TACC_GULP_DIR, TACC_GULP_LIB, TACC_GULP_DOC, and TACC_GULP_BIN.

The gulp executables are located in $TACC_GULP_BIN as gulp and gulp.mpi


Version 5.0
]]

--help(help_msg)
help(help_msg)


local err_message = [[
You do not have access to Gulp!

GULP is available for free for academic use by anyone with a valid University
email account. Users must provide license or demonstrate academic usership and
must request to be added to GULP user UNIX group through TACC User Portal
Attention: cproctor@tacc.utexas.edu

]]

local group  = "G-801978"
local grps   = capture("groups")
local found  = false
local isRoot = tonumber(capture("id -u")) == 0
local isBuild = tonumber(capture("id -u")) == 500
for g in grps:split("[ \n]") do
  if (g == group or isRoot or isBuild)  then
    found = true
    break
  end
end

whatis("Name: gulp")
whatis("Version: 5.0")
whatis("Category: Applications/Physics")
whatis("Description: Gulp - A lattice dynamics program")
whatis("URL: http://nanochemistry.curtin.edu.au/gulp")

if (found) then
  setenv("TACC_GULP_DIR", "/home1/apps/intel18/impi18_0/gulp/5.0/")
  setenv("TACC_GULP_LIB", "/home1/apps/intel18/impi18_0/gulp/5.0/Libraries")
  setenv("TACC_GULP_DOC", "/home1/apps/intel18/impi18_0/gulp/5.0/Docs")
  setenv("TACC_GULP_BIN", "/home1/apps/intel18/impi18_0/gulp/5.0/bin")

  prepend_path("PATH", "/home1/apps/intel18/impi18_0/gulp/5.0/bin")

  setenv("GULP_LIB", "/home1/apps/intel18/impi18_0/gulp/5.0/Libraries")
  setenv("GULP_DOC", "/home1/apps/intel18/impi18_0/gulp/5.0/Docs")
else
  LmodError(err_message,"\n")
end


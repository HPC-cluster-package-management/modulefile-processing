local err_message = [[

   NAMD 2017_12_05 is not available under Intel 17 and 18 at this time. 
Please load NAMD/2017_12_05 using the following command, 

module load intel/16.0.3 impi namd/2017_12_05
module help namd 
for more information about running NAMD jobs. 

  Please note that the way to run NAMD on Stampede 2 has been changed. 
The executable files for KNL and SKX nodes are different to get best performance.

]]

LmodError(err_message,"\n")


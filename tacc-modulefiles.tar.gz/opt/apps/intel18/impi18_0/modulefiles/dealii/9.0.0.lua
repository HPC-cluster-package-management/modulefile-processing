help( [[
The dealii module defines the following environment variables:
TACC_DEALII_DIR, TACC_DEALII_BIN, and
TACC_DEALII_LIB for the location
of the Dealii distribution, documentation, binaries,
and libraries.

Version 9.0.0
external packages installed: 
]] )

whatis( "Name: Dealii" )
whatis( "Version: 9.0.0" )
whatis( "Version-notes: external packages installed: " )
whatis( "Category: library, mathematics" )
whatis( "URL: http://www-unix.mcs.anl.gov/dealii/dealii-as/" )
whatis( "Description: Portable Extendible Toolkit for Scientific Computing, Numerical library for sparse linear algebra" )

local             dealii_arch =    ""
local             dealii_dir =     "/home1/apps/intel18/impi18_0/dealii/9.0.0/"

prepend_path("PATH",            pathJoin(dealii_dir,dealii_arch,"bin") )
prepend_path("LD_LIBRARY_PATH", pathJoin(dealii_dir,dealii_arch,"lib") )

setenv("DEALII_ARCH",            dealii_arch)
setenv("DEALII_DIR",             dealii_dir)
setenv("TACC_DEALII_DIR",        dealii_dir)
setenv("TACC_DEALII_BIN",        pathJoin(dealii_dir,dealii_arch,"bin") )
setenv("TACC_DEALII_INC",        pathJoin(dealii_dir,dealii_arch,"include") )
setenv("TACC_DEALII_LIB",        pathJoin(dealii_dir,dealii_arch,"lib") )

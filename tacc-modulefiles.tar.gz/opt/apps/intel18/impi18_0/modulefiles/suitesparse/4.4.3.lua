help( [[
The Suitesparse module defines the following environment variables:
TACC_SUITESPARSE_INC and TACC_SUITESPARSE_LIB for the location
of the Suitesparse include files and libraries.

Version 4.4.3
]] )

whatis( "Name: Suitesparse" )
whatis( "Version: 4.4.3" )
whatis( "Category: library, mathematics" )
whatis( "URL: http://faculty.cse.tamu.edu/davis/suitesparse.html" )
whatis( "Description: Numerical library for sparse solvers" )

local             suitesparse_arch =    "skylake"
local             suitesparse_dir  =     "/home1/apps/intel18/impi18_0/petsc/3.10/"
local             suitesparse_inc  = pathJoin(suitesparse_dir,suitesparse_arch,"include")
local             suitesparse_lib  = pathJoin(suitesparse_dir,suitesparse_arch,"lib")

prepend_path("LD_LIBRARY_PATH", suitesparse_lib)

setenv("TACC_SUITESPARSE_INC",        suitesparse_inc )
setenv("TACC_SUITESPARSE_LIB",        suitesparse_lib)

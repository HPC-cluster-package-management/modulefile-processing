local help_msg=[[
The HDF5 module defines the following environment variables:
TACC_HDF5_DIR, TACC_HDF5_DOC, TACC_HDF5_LIB, and TACC_HDF5_INC for
the location of the HDF5 distribution, documentation,
libraries, and include files, respectively.

To use the HDF5 library, compile the source code with the option:

     -I$TACC_HDF5_INC

and add the following options to the link step: 

     -Wl,-rpath,$TACC_HDF5_LIB -L$TACC_HDF5_LIB -lhdf5 -lz

The -Wl,-rpath,$TACC_HDF5_LIB option is not required, however,
if it is used, then this module will not have to be loaded
to run the program during future login sessions.

]]

local help_msg_mic=[[
-----------------------------
To build a MIC native code:
-----------------------------

Compile the source code with the option:

     -I$MIC_TACC_HDF5_INC

and add the following options to the link step: 

     -Wl,-rpath,$MIC_TACC_HDF5_LIB -L$MIC_TACC_HDF5_LIB -lhdf5 -lz
]]

local help_msg_version = [[

Version 1.8.16
]]




whatis("Name: HDF5")
whatis("Version: 1.8.16")
whatis("Category: library, runtime support")
whatis("Keywords: I/0, Library")
whatis("Description: General purpose library and file format for storing scientific data (Parallel Version).")
whatis("URL: http://www.hdfgroup.org/HDF5/")



-- Create environment variables.


local hdf5_dir    = "/opt/apps/intel18/impi18_0/phdf5/1.8.16/x86_64"
local hdf5_micdir = "/opt/apps/intel18/impi18_0/phdf5/1.8.16/k1om"

family("hdf5")
setenv(       "TACC_HDF5_DIR",    hdf5_dir)
setenv(       "TACC_HDF5_DOC",    pathJoin(hdf5_dir,"doc"))
setenv(       "TACC_HDF5_INC",    pathJoin(hdf5_dir,"include"))
setenv(       "TACC_HDF5_LIB",    pathJoin(hdf5_dir,"lib"))

setenv(       "TACC_HDF5_BIN",    pathJoin(hdf5_dir,"bin"))
prepend_path( "PATH"         ,    pathJoin(hdf5_dir,"bin"))
prepend_path( "LD_LIBRARY_PATH",  pathJoin(hdf5_dir,"lib"))

local have_mic = ("" == "k1om")

if (have_mic) then
   help(help_msg, help_msg_mic, help_msg_version)
   setenv(       "MIC_TACC_HDF5_DIR",    hdf5_micdir)
   setenv(       "MIC_TACC_HDF5_DOC",    pathJoin(hdf5_micdir,"doc"))
   setenv(       "MIC_TACC_HDF5_INC",    pathJoin(hdf5_micdir,"include"))
   setenv(       "MIC_TACC_HDF5_LIB",    pathJoin(hdf5_micdir,"lib"))
   setenv(       "MIC_TACC_HDF5_BIN",    pathJoin(hdf5_micdir,"bin"))
   prepend_path( "MIC_LD_LIBRARY_PATH",  pathJoin(hdf5_micdir,"lib"))
   add_property("arch","mic")
else
   help(help_msg, help_msg_version)
end


help([[
The ARPACK modulefile defines the following environment variables:
TACC_ARPACK_DIR, TACC_ARPACK_LIB, and TACC_ARPACK_INC 
for the location of the ARPACK 3.1.4 distribution, and 
libraries respectively.

Add the following options to the link step:

      -Wl,-rpath,$TACC_ARPACK_LIB -L$TACC_ARPACK_LIB -larpack

This is a fortran 77 library. It has no include files.

Version 3.1.4
]])

whatis("ARPACK/PARPACK: Arnoldi package")
whatis("Version: 3.1.4")
whatis("Category: library, mathematics")
whatis("Keywords: library, mathematics")
whatis("Description: eigenvalue computations based on restarted Arnoldi method")
whatis("URL: http://www.caam.rice.edu/software/ARPACK/")


-- Create environment variables.

local arpack_dir="/opt/apps/intel18/impi18_0/arpack/3.1.4"

setenv(          "TACC_ARPACK_DIR",      arpack_dir)
setenv(          "TACC_ARPACK_LIB",      pathJoin(arpack_dir,"lib"))

--  Append path


prepend_path(    "LD_LIBRARY_PATH",      pathJoin(arpack_dir,"lib"))


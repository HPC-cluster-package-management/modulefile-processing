local help_msg=[[


To run codes in quantum espresso, e.g. pw.x, include the following lines in
your job script, using the appropriate input file name:
module load qe/6.2
ibrun pw.x -input input.scf

IMPORTANT NOTES:

1. Run your jobs on $SCRATCH rather than $WORK. The $SCRATCH file system is better able to handle these kinds of loads.

2. Especially when running pw.x, set the keyword disk_io to low or none in input so that wavefunction
will not be written to file at each scf iteration step, but stored in memory.

3. When running ph.x, set the  reduced_io to .true. and run it and redirect its IO to $SCRATCH.
Do not run multiple ph.x jobs at given time.

Version 6.2
]]

--help(help_msg)
help(help_msg)

whatis("Name: Quantum Espresso")
whatis("Version: 6.2")
whatis "Category: application, chemistry"
whatis "Keywords: Chemistry, Density Functional Theory, Plane Wave, Peudo potentials"
whatis "URL: http://www.quantum-espresso.org"
whatis "Description: Integrated suite of computer codes for electronic structure calculations and material modeling at the nanoscale."

-- Create environment variables.
local qe_dir="/home1/apps/intel18/impi18_0/qe/6.2"

prepend_path(    "PATH",                pathJoin(qe_dir, "bin"))

setenv( "TACC_QE_DIR",                qe_dir)
setenv( "TACC_QE_BIN",       pathJoin(qe_dir, "bin"))
setenv("TACC_QE_PSEUDO",pathJoin(qe_dir,"pseudo"))



-- This module file sets up the environment variables and path for TAU.

local help_message = [[
The tau module defines the following standard environment variables:
TACC_TAU_DIR and TAU, TACC_TAU_BIN, TACC_TAU_LIB, and TACC_TAU_DOC 
TACC_TAU_EXM, TACC_TAU_TOL for the location of the TAU distribution, 
binaries, libraries, documents, examples and tools, respectively.  

It also defines defaults: 
   TAU_PROFILE=1, 
   TAU_MAKEFILE=Makefile.tau-intelmpi-icpc-papi-ompt-mpi-pdt-openmp,
   TAU_METRICS=GET_TIME_OF_DAY:PAPI_TOT_CYC:PAPI_L2_LDM.

TAU_MAKEFILE sets the tools (pdt), compilers (intel) and parallel 
paradigm (serial, or mpi and/or openmp) to be used in the instrumentation.

For TAU 2.27.2 it is only necessary to load up the TAU
2.27.2 environment. Advanced users may need to load up
papi/5.6.0 and pdtoolkit/3.25 for library and command access.
For normal usage use the defaults: just load up tau, recompile, and run.
See the User Guide and Reference pdf files in the $TACC_TAU_DOC directory. 
Man pages are available for commands (e.g. paraprof, tauf90, etc.),
and the application program interface. 

Load command:

    module load tau

    or

    module load tau/2.27.2

Java is used in the TAU gui, paraprof, and is available in the default
environment.

The Tau makefile (for the Tau compiler wrappers to use) is specified in the 
TAU_MAKEFILE environement variable. The syntax for makefile name is:

    <path>/Makefile.tau-<hyphen_separated_component_list>\n

and the components are:
    Intel Compilers (icpc)
    MPI             (mpi)    also has intelmpi tag name
    OMP             (openmp)
    OpenMP Tool     (ompt)   openmp events
    PAPI            (papi)   now included by default
    PDtoolkit       (pdt)    now included by default

The default TAU Makefile is set for MPI and hybrid applications.
It has the intelmpi tag in its name.
For pure OpenMP applications use a Makefile with the 
intelomp tag (and no mpi component).

The default TAU Makefile has been set in the TAU_MAKEFILE variable,
(it is for MPI codes, with|without OpenMP):

    $TACC_TAU_LIB/Makefile.tau-intelmpi-icpc-papi-ompt-mpi-pdt-openmp

For pure OpenMP code, set TAU_MAKEFILE as show here:

    export TAU_MAKEFILE=$TACC_TAU_LIB/Makefile.tau-intelomp-icpc-papi-ompt-pdt-openmp

(All TAU Makefiles are stored in the $TACC_TAU_LIB directory.)

To compile your code with TAU, use one of the TAU compiler wrappers:

   tau_f90.sh
   tau_cc.sh
   tau_cxx.sh

for constructing an instrumented code (instead of mpif90, mpicc, etc.).

E.g.  tau_f90.sh mpihello.f90, tau_cc.sh mpihello.c, etc.

These may also be used in makefiles, using macro definitions:

E.g.  F90=tau_f90.sh, CC=tau_cc.sh, Cxx=tau_cxx.sh.

-- To enable callpath information collection set TAU_CALLPATH to 1.
-- To enable trace collection set the environmental variable TAU_TRACE to 1.

Version 2.27.2

]]

help(help_message,"\n")

whatis("Name: Tuning Analysis Utilities ")
whatis("Version: 2.27.2")
whatis("Category: library, profiling and optimization")
whatis("System: Profiling, Tools")
whatis("URL: http://www.cs.uoregon.edu/research/tau/home.php")
whatis("Description: Framework for Application profiling and optimization")


--#
--# Create environment variables.
--#
local             tau_dir        =  "/opt/apps/intel18/impi18_0/tau/2.27.2"
local             tau_bin        =  "/opt/apps/intel18/impi18_0/tau/2.27.2/x86_64/bin"
local             tau_lib        =  "/opt/apps/intel18/impi18_0/tau/2.27.2/x86_64/lib"

prepend_path(    "PATH"           , tau_bin                 )
prepend_path(    "LD_LIBRARY_PATH", tau_lib                 )
prepend_path(    "MANPATH"        , pathJoin(tau_dir,"man") )

prepend_path(    "LD_LIBRARY_PATH", "/opt/apps/papi/5.6.0/lib"       )
prepend_path(    "MANPATH"        , "/opt/apps/papi/5.6.0/man"       )

setenv(           "TACC_TAU_DIR",            tau_dir        )
setenv(           "TACC_TAU_BIN",            tau_bin        )
setenv(           "TACC_TAU_LIB",            tau_lib        )
setenv(           "TACC_TAU_INC",   pathJoin(tau_dir,"include"))
setenv(           "TACC_TAU_DOC",   pathJoin(tau_dir,"docs"))
setenv(           "TACC_TAU_EXM",   pathJoin(tau_dir,"examples"))
setenv(           "TACC_TAU_TOL",   pathJoin(tau_dir,"tools"))
setenv(                "TAU",                tau_lib        )
setenv(           "TAU_MAKEFILE", pathJoin(tau_lib,"Makefile.tau-intelmpi-icpc-papi-ompt-mpi-pdt-openmp") )
setenv("PAPI_PERFMON_EVENT_FILE",   "/opt/apps/papi/5.6.0/share/papi/papi_events.csv"        )
setenv(            "TAU_METRICS",   "GET_TIME_OF_DAY:PAPI_TOT_CYC:PAPI_L2_LDM"        )
setenv(            "TAU_PROFILE",            "1"            )

-- setenv(              "TAU_TRACE",            "0"            )
-- setenv(           "TAU_CALLPATH",            "0"            )


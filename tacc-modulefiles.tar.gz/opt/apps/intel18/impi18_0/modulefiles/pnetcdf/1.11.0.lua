--netcdf

local help_message = [[
IMPORTANT NOTE: TACC has several different versions of netcdf
installed.  Below is a list of each module type:

netcdf/3.6.3           -- Classic netcdf (serial)
netcdf/4.x.x           -- Serial version of Netcdf4 based upon hdf5 and
is backwards compatiable with classic netcdf (serial)
parallel-netcdf/4.x.x  -- Parallel version of Netcdf4 based upon
parallel hdf5 (parallel)
pnetcdf/1.x.x          -- Parallel netcdf(PnetCDF) that supports netcdf
in the classic formats, CDF-1 and CDF-2 (parallel)

The command "module avail netcdf" will show which versions of netcdf are
available for your current compiler/mpi module environment.

The pnetcdf module file defines the following environment variables:
TACC_PNETCDF_DIR, TACC_PNETCDF_BIN, TACC_PNETCDF_LIB, and 
TACC_PNETCDF_INC forthe location of the NETCDF distribution, binaries,
libraries, and include files, respectively.

Parallel netCDF (PnetCDF) is a library providing high-performance I/O while still maintaining file-format compatibility with Unidata's NetCDF.  NetCDF gives scientific programmers a space-efficient and portable means for storing data. However, it does so in a serial manner, making it difficult to achieve high I/O performance. By making some small changes to the NetCDF APIs, PnetCDF can use MPI-IO to achieve high-performance parallel I/O. 

To use the NETCDF library, compile the source code with the option:

	-I${TACC_PNETCDF_INC} 

Add the following options to the link step: 

	-L${TACC_PNETCDF_LIB} -lpnetcdf 

Version 1.11.0

]]

help(help_message,"\n")


whatis("Parallel-netCDF(Pnetcdf)")
whatis("Version: 1.11.0")
whatis("Category: library, runtime support")
whatis("Keywords: I/O, Library")
whatis("Description: I/O library which stores and retrieves data in self-describing, machine-independent datasets(PnetCDF)." )
whatis(" URL: trac.mcs.anl.gov/projects/parallel-netcdf")

--Prepend paths
prepend_path("LD_LIBRARY_PATH","/opt/apps/intel18/impi18_0/pnetcdf/1.11.0/lib")
prepend_path("PATH",           "/opt/apps/intel18/impi18_0/pnetcdf/1.11.0/bin")
prepend_path("MANPATH",        "/opt/apps/intel18/impi18_0/pnetcdf/1.11.0/share/man")

--Env variables 
setenv("PNETCDF", "/opt/apps/intel18/impi18_0/pnetcdf/1.11.0")
setenv("TACC_PNETCDF_DIR", "/opt/apps/intel18/impi18_0/pnetcdf/1.11.0")
setenv("TACC_PNETCDF_INC", "/opt/apps/intel18/impi18_0/pnetcdf/1.11.0/include")
setenv("TACC_PNETCDF_LIB", "/opt/apps/intel18/impi18_0/pnetcdf/1.11.0/lib")
setenv("TACC_PNETCDF_BIN", "/opt/apps/intel18/impi18_0/pnetcdf/1.11.0/bin")


local help_msg=[[ 
The PARAVIEW module defines the following environment variables:
TACC_PARAVIEW_DIR, TACC_PARAVIEW_LIB, TACC_PARAVIEW_INC,
TACC_PARAVIEW_BIN and TACC_PARAVIEW_PYTHONPATH for the location of the
PARAVIEW distribution, libraries, include files, tools, and python packages
respectively.
]]

--help(help_msg)
help(help_msg)

whatis("Name: paraview")
whatis("Version: 5.6.0")

-- Create environment variables.
local paraview_dir           = "/opt/apps/intel18/impi18_0/paraview-osmesa/5.6.0"

family("paraview")

prereq("swr", "qt5", "ospray")

prepend_path("PATH",              pathJoin(paraview_dir, "bin"))
prepend_path("LD_LIBRARY_PATH",   pathJoin(paraview_dir, "lib"))
prepend_path("PYTHONPATH",        pathJoin(paraview_dir, "lib", "paraview-5.6", "site-packages"))
prepend_path("PYTHONPATH",        pathJoin(paraview_dir, "lib", "paraview-5.6", "site-packages", "vtk"))

prepend_path("MODULEPATH",        "/opt/apps/paraview5.6/modulefiles")

setenv("OSPRAY_SET_AFFINITY", 0)

setenv("TACC_PARAVIEW_DIR",  paraview_dir)
setenv("TACC_PARAVIEW_INC",  pathJoin(paraview_dir, "include"))
setenv("TACC_PARAVIEW_LIB",  pathJoin(paraview_dir, "lib"))
setenv("TACC_PARAVIEW_BIN",  pathJoin(paraview_dir, "bin"))

setenv("OSPRAY_SET_AFFINITY",  "0")

local help_message=[[
The default envs of the installed NWCHEM
NWCHEM_TOP  /opt/apps/intel18/impi18_0/nwchem/6.6/
NWCHEM_NWPW_LIBRARY  /opt/apps/intel18/impi18_0/nwchem/6.6/data/
NWCHEM_BASIS_LIBRARY /opt/apps/intel18/impi18_0/nwchem/6.6/data/libraries/
 
To run NWChem, please include the following lines in
your job script, using the appropriate input file name:
module load nwchem
ibrun nwchem input.nw
 
You need to reset envs BY YOUR OWN if your calculation needs configuration
and input beyond the above defaults

Version 6.6
]]

help(help_message,"\n")

whatis("Name: NWCHEM")
whatis("Version: 6.6")
whatis("Category: Application, Chemistry")
whatis("Keywords: Chemistry, Open Souece")
whatis("URL: http://www.nwchem-sw.org/")
whatis("Description: NWChem aims to provide its users with computational chemistry tools that are scalable both in their ability to treat large scientific computational chemistry problems efficiently, and in their use of available parallel computing resources from high-performance parallel supercomputers to conventional workstation clusters.")

local nwchem_dir="/opt/apps/intel18/impi18_0/nwchem/6.6"

prepend_path(    "PATH",                pathJoin(nwchem_dir, "bin"))
 
setenv("NWCHEM_TOP",nwchem_dir)
setenv("TACC_NWCHEM_DIR",nwchem_dir)
setenv("TACC_NWCHEM_BIN",pathJoin(nwchem_dir,"bin"))
setenv("NWCHEM_NWPW_LIBRARY",pathJoin(nwchem_dir,"data/")..'/')
setenv("NWCHEM_BASIS_LIBRARY",pathJoin(nwchem_dir,"data/libraries/")..'/')


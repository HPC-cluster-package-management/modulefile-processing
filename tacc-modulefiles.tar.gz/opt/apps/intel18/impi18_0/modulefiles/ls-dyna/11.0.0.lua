local help_msg=[[

LS-DYNA, developed by Livermore Software Technology Corporation (LSTC),
is a multi purpose explicit and implicit finite element and multiphysics program used to analyse the nonlinear response of structures.

Its fully automated contact analysis and wide range of material models enable users worldwide to solve complex, real world problems.

The LSDYNA module file defines the following environment variables:
TACC_LSDYNA_DIR, TACC_LSDYNA_BIN for
the location of the tacc-ls-dyna-intel18-impi18_0 distribution and excutables,respectively.
 also appends the path to the executables
to the PATH environment variable.

The excutables of LSDYNA in this version include:
        lsdyna_d and lsdyna_s

A license is required to run LS-DYNA on TACC systems. 
Please submit a ticket via the DesignSafe web portal for license request. 
Our administrator team will work with LSTC to verify your license.
https://portal.tacc.utexas.edu/tacc-consulting

Version 11.0.0
]]

help(help_msg)

whatis("LS_DYN: a general-purpose finite element program capable of simulating complex real world problems")
whatis("Version: 11.0.0")
whatis("Category: application, finite element")
whatis("URL: https://www.oasys-software.com/dyna/software/ls-dyna/")


-- Create environment variables.

family("lsdyna")
prepend_path(    "PATH",               "/work/projects/wma_apps/stampede2/ls-dyna/ls-dyna_11.0.0/bin")
setenv( "TACC_LSDYNA_DIR",      "/work/projects/wma_apps/stampede2/ls-dyna/ls-dyna_11.0.0")
setenv( "TACC_LSDYNA_BIN",      "/work/projects/wma_apps/stampede2/ls-dyna/ls-dyna_11.0.0/bin")

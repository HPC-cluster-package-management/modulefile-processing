help( [[
The Hypre module defines the following environment variables:
TACC_HYPRE_INC and TACC_HYPRE_LIB for the location
of the Hypre include files and libraries.

Version 2.14
]] )

whatis( "Name: Hypre" )
whatis( "Version: 2.14" )
whatis( "Category: library, mathematics" )
whatis( "URL: http://llnl.gov/hypre/" )
whatis( "Description: Numerical library for sparse solvers" )

local             hypre_arch =    "skylake-debug"
local             hypre_dir  =     "/home1/apps/intel18/impi18_0/petsc/3.10/"
local             hypre_inc  = pathJoin(hypre_dir,hypre_arch,"include")
local             hypre_lib  = pathJoin(hypre_dir,hypre_arch,"lib")

prepend_path("LD_LIBRARY_PATH", hypre_lib)

setenv("TACC_HYPRE_DIR",        hypre_dir )
setenv("TACC_HYPRE_INC",        hypre_inc )
setenv("TACC_HYPRE_LIB",        hypre_lib)

help( [[
The Mumps module defines the following environment variables:
TACC_MUMPS_INC and TACC_MUMPS_LIB for the location
of the Mumps include files and libraries.

Version 5.1
]] )

whatis( "Name: Mumps" )
whatis( "Version: 5.1" )
whatis( "Category: library, mathematics" )
whatis( "URL: http://graal.ens-lyon.fr/MUMPS/" )
whatis( "Description: Numerical library for sparse solvers" )

local             mumps_arch =    "knightslanding-cxxdebug"
local             mumps_dir  =     "/home1/apps/intel18/impi18_0/petsc/3.9/"
local             mumps_inc  = pathJoin(mumps_dir,mumps_arch,"include")
local             mumps_lib  = pathJoin(mumps_dir,mumps_arch,"lib")

prepend_path("LD_LIBRARY_PATH", mumps_lib)

setenv("TACC_MUMPS_INC",        mumps_inc )
setenv("TACC_MUMPS_LIB",        mumps_lib)

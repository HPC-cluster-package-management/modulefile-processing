local help_msg=[[
The CAFFE module defines the following environment variables:
TACC_CAFFE_DIR, TACC_CAFFE_LIB, TACC_CAFFE_INC and
TACC_CAFFE_BIN for the location of the CAFFE distribution, libraries,
include files, and tools respectively.
]]

--help(help_msg)
help(help_msg)

whatis("Name: caffe")
whatis("Version: 1.1.4")

-- Create environment variables.
local bar_dir           = "/opt/apps/intel18/impi18_0/caffe/1.1.4"

family("caffe")
prepend_path(    "PATH",                pathJoin(bar_dir, "bin"))
prepend_path(    "LD_LIBRARY_PATH",     pathJoin(bar_dir, "lib"))
prepend_path(    "PYTHONPATH",          pathJoin(bar_dir, "python"))
prepend_path(    "PYTHONPATH",          pathJoin(bar_dir, "libraries/mlsl/intel64/include"))
prepend_path(    "LD_LIBRARY_PATH",     pathJoin(bar_dir, "libraries/gflags/lib"))
prepend_path(    "LD_LIBRARY_PATH",     pathJoin(bar_dir, "libraries/glog/lib"))
prepend_path(    "LD_LIBRARY_PATH",     pathJoin(bar_dir, "libraries/leveldb/lib"))
prepend_path(    "LD_LIBRARY_PATH",     pathJoin(bar_dir, "libraries/lmdb/lib"))
prepend_path(    "LD_LIBRARY_PATH",     pathJoin(bar_dir, "libraries/mlsl/intel64/lib"))
prepend_path(    "LD_LIBRARY_PATH",     pathJoin(bar_dir, "libraries/opencv/lib"))
prepend_path(    "LD_LIBRARY_PATH",     pathJoin(bar_dir, "libraries/protocol-buffer/lib"))
prepend_path(    "LD_LIBRARY_PATH",     pathJoin(bar_dir, "libraries/snappy/lib"))
prepend_path(    "LD_LIBRARY_PATH",     pathJoin(bar_dir, "libraries/mklml/lib"))
prepend_path(    "LD_LIBRARY_PATH",     pathJoin(bar_dir, "libraries/mkldnn/lib"))
prepend_path(    "LD_LIBRARY_PATH",     pathJoin(bar_dir, "libraries/dlcp/lib"))
prepend_path(    "MODULEPATH",         "/opt/apps/bar1_1/modulefiles")
setenv( "TACC_CAFFE_DIR",                bar_dir)
setenv( "TACC_CAFFE_INC",       pathJoin(bar_dir, "include"))
setenv( "TACC_CAFFE_LIB",       pathJoin(bar_dir, "lib"))
setenv( "TACC_CAFFE_BIN",       pathJoin(bar_dir, "bin"))
setenv( "MLSL_ROOT",       pathJoin(bar_dir, "libraries/mlsl"))
load("hdf5")
load("boost")
prepend_path(    "LD_LIBRARY_PATH",     pathJoin(bar_dir, "libraries/boost/lib"))

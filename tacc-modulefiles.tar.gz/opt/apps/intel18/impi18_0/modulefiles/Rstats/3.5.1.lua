help(
[[
This is the R statistics (Rstats) package built on September 27, 2018.

Please load RstatsPackages to all pre-installed packages for this Rstats module.

The R modulefile defines the environment variables TACC_R_DIR, TACC_R_BIN,
TACC_R_LIB and extends the PATH and LD_LIBRARY_PATH paths as appropriate.

Version 3.5.1
]]
)

--
-- Create environment variables.
--
local r_dir   = "/opt/apps/intel18/impi18_0/Rstats/3.5.1"
local r_bin   = "/opt/apps/intel18/impi18_0/Rstats/3.5.1/bin"
local r_inc   = "/opt/apps/intel18/impi18_0/Rstats/3.5.1/include"
local r_lib   = "/opt/apps/intel18/impi18_0/Rstats/3.5.1/lib64/R/lib"
local r_man   = "/opt/apps/intel18/impi18_0/Rstats/3.5.1/share/man"
local r_profile = "/opt/apps/intel18/impi18_0/Rstats/3.5.1/etc/Rprofile.site"

setenv("R_PROFILE", r_profile)
setenv("TACC_R_DIR", r_dir)
setenv("TACC_R_BIN", r_bin)
setenv("TACC_R_INC", r_inc)
setenv("TACC_R_LIB", r_lib)
setenv("TACC_R_MAN", r_man)
setenv("MV2_SUPPORT_DPM", 1)

prepend_path("PATH", r_bin)
prepend_path("MANPATH", r_man)

prepend_path("LD_LIBRARY_PATH", r_lib)

try_load("RstatsPackages/3.5.1")

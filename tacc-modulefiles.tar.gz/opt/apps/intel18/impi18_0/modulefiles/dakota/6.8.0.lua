local help_message = [[
The Dakota toolkit provides a flexible, extensible interface between analysis
codes and iterative systems analysis methods. Dakota contains algorithms for:
optimization with gradient and nongradient-based methods; uncertainty
quantification with sampling, reliability, stochastic expansion, and epistemic
methods; parameter estimation with nonlinear least squares methods; and
sensitivity/variance analysis with design of experiments and parameter study
methods.  These capabilities may be used on their own or as components within
advanced strategies such as hybrid optimization, surrogate-based optimization,
mixed integer nonlinear programming, or optimization under uncertainty.

This module defines the environmental variables TACC_DAKOTA_DIR,
TACC_DAKOTA_BIN, TACC_DAKOTA_LIB, TACC_DAKOTA_INC,
and TACC_DAKOTA_DOC for the location of the main Dakota directory,
the binaries, the libraries, the include files, and TACC-specific documentation
respectively.

The location of the binary files and tests are also added to your PATH.
The location of the libraries files are also added to your LD_LIBRARY_PATH.

To get started, copy the TACC examples:
mkdir -p ${WORK}/apps/dakota
cp -r ${TACC_DAKOTA_DOC} ${WORK}/apps/dakota
cat ${WORK}/apps/dakota/TACC_parallelism/README

Extended documentation on Dakota can be found under ${TACC_DAKOTA_DIR}/examples.

Version 6.8.0
]]

help(help_message,"\n")

whatis("Name: tacc-dakota-intel18-impi18_0")
whatis("Version: 6.8.0")
whatis("Category: system, application")
whatis("Keywords: optimization, uncertainty quantification, parameter estimation, sensitivity analysis")
whatis("Description: Dakota toolkit provides a flexible, extensible interface between analysis codes and iterative systems analysis methods")
whatis("URL: https://dakota.sandia.gov")

-- Export environmental variables
local dakota_dir="/home1/apps/intel18/impi18_0/dakota/6.8.0"
local dakota_bin=pathJoin(dakota_dir,"bin")
local dakota_test=pathJoin(dakota_dir,"test")
local dakota_lib=pathJoin(dakota_dir,"lib")
local dakota_inc=pathJoin(dakota_dir,"include")
local dakota_doc=pathJoin(dakota_dir,"examples/TACC_parallelism")
setenv("TACC_DAKOTA_DIR",dakota_dir)
setenv("TACC_DAKOTA_BIN",dakota_bin)
setenv("TACC_DAKOTA_LIB",dakota_lib)
setenv("TACC_DAKOTA_INC",dakota_inc)
setenv("TACC_DAKOTA_DOC",dakota_doc)

-- Prepend the dakota directories to the adequate PATH variables
prepend_path("PATH",dakota_bin)
prepend_path("PATH",dakota_test)
prepend_path("LD_LIBRARY_PATH",dakota_bin)
prepend_path("LD_LIBRARY_PATH",dakota_lib)


help( [[
The SLEPC4PY modulefile defines the following environment variables:
TACC_SLEPC4PY_DIR
for the location of the SLEPC4PY 3.11 distribution;
it also updates PYTHONPATH.

Version 3.11-complex
]] )

whatis( "Name: Slepc4py" )
whatis( "Version: 3.11-complex" )
whatis( "Version-notes: 3.11-complex" )
whatis( "Category: library, mathematics" )
whatis( "URL: https://bitbucket.org/slepc/slepc4py/" )
whatis( "Description: python interface to Slepc" )

local             slepc_arch =    "skylake-complex"
local             slepc4py_dir =     "/home1/apps/intel18/impi18_0/python2_7/slepc4py/3.11"

prepend_path("PYTHONPATH", pathJoin(slepc4py_dir,"skylake-complex","lib","python2.7","site-packages") )

setenv(          "TACC_SLEPC4PY_DIR",        slepc4py_dir)

depends_on("petsc/3.11-complex")
depends_on("petsc4py/3.11-complex")
depends_on("slepc/3.11-complex")

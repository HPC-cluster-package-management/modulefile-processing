local help_msg=[[
The netcdf module file defines the following environment variables:
TACC_NETCDF_DIR, TACC_NETCDF_BIN, TACC_NETCDF_LIB, and 
TACC_NETCDF_INC forthe location of the NETCDF distribution, binaries,
libraries, and include files, respectively.

IMPORTANT NOTE: TACC has several different versions of netcdf installed.  Below is a list of each module type:

netcdf/3.6.3           -- Classic netcdf (serial)
netcdf/4.x.x           -- Serial version of Netcdf4 based upon hdf5 and is backwards compatiable with classic netcdf (serial)
parallel-netcdf/4.x.x  -- Parallel version of Netcdf4 based upon parallel hdf5 (parallel)
pnetcdf/1.x.x          -- Parallel netcdf(PnetCDF) that supports netcdf in the classic formats, CDF-1 and CDF-2 (parallel)


NETCDF 4.6.2 uses the hdf5 libraries to support the NETCDF 4 file format 
in addition to the classic NETCDF file format. 

To use the NETCDF library, compile the source code with the option:

	-I${TACC_NETCDF_INC} 

Add the following options to the link step for C codes: 

	-L${TACC_NETCDF_LIB} -lnetcdf 

Add the following options to the link step for Fortran codes: 

	-L${TACC_NETCDF_LIB} -lnetcdf -lnetcdff 

Add the following options to the link step for C++ codes: 

	-L${TACC_NETCDF_LIB} -lnetcdf -lnetcdf_c++4 

Version 4.6.2


]]

local help_msg_mic=[[
-----------------------------
To build a MIC native code:
-----------------------------

Compile the source code with the option:

     -I$MIC_TACC_NETCDF_INC

and add the following options to the link step: 
     -Wl,-rpath,${MIC_TACC_NETCDF_LIB} -L${MIC_TACC_NETCDF_LIB} -lnetcdf

]]

local help_msg_version = [[

Version 4.6.2
]]

whatis("NetCDF: Network Common Data Form")
whatis("Version: 4.6.2")
whatis("Category: library, runtime support")
whatis("Keywords: I/O, Library")
whatis("Description: I/O library which stores and retrieves data in self-describing, machine-independent datasets (Parallel Version)." )
whatis("URL: http://www.unidata.ucar.edu/software/netcdf/")

local ncdf_dir    = "/opt/apps/gcc7_1/impi18_0/parallel-netcdf/4.6.2/x86_64"
local ncdf_micdir = "/opt/apps/gcc7_1/impi18_0/parallel-netcdf/4.6.2/k1om"

--Prepend paths

prepend_path("LD_LIBRARY_PATH",	pathJoin(ncdf_dir,"lib"))
prepend_path("PATH",           	pathJoin(ncdf_dir,"bin"))
prepend_path("MANPATH",        	pathJoin(ncdf_dir,"share/man"))
prepend_path("PKG_CONFIG_PATH",	pathJoin(ncdf_dir,"lib/pkgconfig"))

--Env variables 
setenv("TACC_NETCDF_DIR", ncdf_dir)
setenv("TACC_NETCDF_INC", pathJoin(ncdf_dir,"include"))
setenv("TACC_NETCDF_LIB", pathJoin(ncdf_dir,"lib"))
setenv("TACC_NETCDF_BIN", pathJoin(ncdf_dir,"bin"))

local have_mic = ("" == "k1om")

if (have_mic) then

   --MIC Env variables 
   help(help_msg,help_msg_mic,help_msg_version)
   prepend_path("MIC_LD_LIBRARY_PATH", pathJoin(ncdf_micdir,"lib"))
   prepend_path("MIC_PKG_CONFIG_PATH", pathJoin(ncdf_micdir,"lib/pkgconfig"))
   setenv("MIC_TACC_NETCDF_DIR", ncdf_micdir)
   setenv("MIC_TACC_NETCDF_INC", pathJoin(ncdf_micdir, "include"))
   setenv("MIC_TACC_NETCDF_LIB", pathJoin(ncdf_micdir, "lib"))
   setenv("MIC_TACC_NETCDF_BIN", pathJoin(ncdf_micdir, "bin"))
   add_property("arch","mic")
else
   help(help_msg, help_msg_version)
end


-- prepend path


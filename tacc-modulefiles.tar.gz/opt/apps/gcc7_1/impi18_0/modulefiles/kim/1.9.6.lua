local help_message = [[
The KIM API is an Application Programming Interface for atomistic 
simulations. The API provides a standard for exchanging information 
between atomistic simulation codes (molecular dynamics, molecular 
statics, lattice dynamics, Monte Carlo, etc.) and interatomic models 
(potentials or force fields). 

It also includes a set of library routines for using the API with 
bindings for:

  FORTRAN 77, Fortran 90/95, Fortran 2003, C, C++

The KIM module defines a set of environment variables for the locations
of the KIM home, binaries, library and more with the prefix "TACC_KIM_".
Use the "env" command to display the variables:

  $ env | grep "TACC_KIM"

LAMMPS (version 16Mar18) installed on Stampede2 was compiled with the
KIM package.

For more information about using KIM package in LAMMPS, please see
the website:

  http://lammps.sandia.gov/doc/pair_kim.html

* REFERENCE
      
  OpenKIM website: https://openkim.org

  Version 1.9.6
]]

help(help_message,"\n")

whatis("Name: OpenKIM API")
whatis("Version: 1.9.6")
whatis("Category: application, chemistry")
whatis("Keywords: Chemistry, Molecular Dynamics, Application")
whatis("URL:  https://openkim.org")
whatis("Description: Application Programming Interface for atomistic simulations")

local kim_dir="/opt/apps/gcc7_1/impi18_0/kim/1.9.6"

setenv("TACC_KIM_DIR"              ,kim_dir)
setenv("TACC_KIM_API"              ,pathJoin(kim_dir,"kim-api"))
setenv("TACC_KIM_BIN"              ,pathJoin(kim_dir,"kim-api/bin"))
setenv("TACC_KIM_LIB"              ,pathJoin(kim_dir,"kim-api/lib"))

append_path("PATH",pathJoin(kim_dir,"kim-api/bin"))
prepend_path("LD_LIBRARY_PATH","/opt/apps/gcc/7.1.0/lib64")

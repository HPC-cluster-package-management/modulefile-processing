local help_message = [[

RDKit is an open-source cheminformatics software written in C++.
Python (3.6) wrapper is generated using Boost.Python.

Compiler and external libraries:

  - GCC     (7.1)
  - Python3 (3.6.1)
  - Boost   (1.61.0)
  - Eigen3  (3.3.5)

The RDKit module defines a set of environment variables for the
locations of the RDKit home, libraries, include and more, with 
the prefix "TACC_RDKIT_". Use the "env" command to display the variables:

  $ env | grep "TACC_RDKIT"

For more information about using RDKit, visit the RDKit documentation website: 

http://www.rdkit.org/docs/index.html

Version 2018_03
]]

help(help_message,"\n")

whatis("Name: RDKit")
whatis("Version: 2018_03")
whatis("Category: application, chemistry")
whatis("Keywords: Chemistry, Cheminformatics, Application")
whatis("URL:  http://www.rdkit.org/")
whatis("Description: Application Programming Interface for atomistic simulations")

local rdkit_dir="/home1/apps/gcc7_1/impi18_0/rdkit/2018_03"

setenv("TACC_RDKIT_DIR"              ,pathJoin(rdkit_dir,"rdkit/"))
setenv("TACC_RDKIT_LIB"              ,pathJoin(rdkit_dir,"rdkit/lib/"))
setenv("TACC_RDKIT_INC"              ,pathJoin(rdkit_dir,"rdkit/include/"))
setenv("TACC_RDKIT_SHARE"            ,pathJoin(rdkit_dir,"rdkit/share/"))
setenv("RDBASE"                      ,pathJoin(rdkit_dir,"rdkit/"))
setenv("EIGEN3_INCLUDE_DIR"          ,pathJoin(rdkit_dir,"eigen/"))

prepend_path("PYTHONPATH",pathJoin(rdkit_dir,"rdkit/"))
prepend_path("PYTHONPATH",pathJoin(rdkit_dir,"rdkit/lib/"))
prepend_path("PYTHONPATH",pathJoin(rdkit_dir,"rdkit/lib/python3.6/site-packages/"))
prepend_path("LD_LIBRARY_PATH",pathJoin(rdkit_dir,"boost_1_61_0/lib"))
prepend_path("LD_LIBRARY_PATH",pathJoin(rdkit_dir,"rdkit/lib"))

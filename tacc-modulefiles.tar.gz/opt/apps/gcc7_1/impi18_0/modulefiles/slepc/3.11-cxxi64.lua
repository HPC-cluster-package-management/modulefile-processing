help( [[
The SLEPC modulefile defines the following environment variables:
TACC_SLEPC_DIR, TACC_SLEPC_LIB, and TACC_SLEPC_INC 
for the location of the SLEPC 3.11 distribution, 
libraries, and include files, respectively.\n

Usage:
    include $(SLEPC_DIR)/conf/slepc_common
(Alternatively:
    include $(SLEPC_DIR)/conf/slepc_variables
    include $(SLEPC_DIR)/conf/slepc_rules
) in your makefile, then compile
    $(CC) -c yourfile.c $(PETSC_INCLUDE)
and link with
    $(CLINKER) -o yourprog yourfile.o $(SLEPC_LIB)

Version 3.11-cxxi64
]] )

whatis( "Name: SLEPc" )
whatis( "Version: 3.11-cxxi64" )
whatis( "Version-notes: 3.11-cxxi64" )
whatis( "Category: library, mathematics" )
whatis( "URL: http://www.grycap.upv.es/slepc/" )
whatis( "Description: Scalable Library for Eigen Problem Computations, Library of eigensolvers" )

local             petsc_arch =    "skylake-cxxi64"
local             slepc_dir =     "/home1/apps/gcc7_1/impi18_0/slepc/3.11"

prepend_path("LD_LIBRARY_PATH", pathJoin(slepc_dir,petsc_arch,"lib") )

setenv(          "SLEPC_DIR",             slepc_dir)
setenv(          "TACC_SLEPC_DIR",        slepc_dir)
setenv(          "TACC_SLEPC_LIB",        pathJoin(slepc_dir,petsc_arch,"lib"))
setenv(          "TACC_SLEPC_INC",        pathJoin(slepc_dir,petsc_arch,"include"))
setenv(          "SLEPC_VERSION",         "3.11-cxxi64")
setenv(          "TACC_SLEPC_VERSION",    "3.11-cxxi64")

prereq("petsc/3.11-cxxi64")

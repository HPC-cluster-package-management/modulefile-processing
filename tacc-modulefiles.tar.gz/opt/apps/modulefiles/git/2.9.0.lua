help([[
Git is a free and open source distributed version control system designed to
handle everything from small to very large projects with speed and efficiency.
Git is easy to learn and has a tiny footprint with lightning fast performance.

The GIT module file defines the following environment variables:
TACC_GIT_DIR, TACC_GIT_BIN, TACC_GIT_LIB for the
location of the GIT distribution, binaries, and libraries
respectively. GIT_EXEC_PATH, which is also defined, determines where Git looks
for its sub-programs. You can check the current setting by running 
"git --exec-path".

Version 2.9.0
]])

whatis("Name: Git")
whatis("Version: 2.9.0")
whatis("Category: library, tools")
whatis("Keywords: System, Source Control Management, Tools")
whatis("URL: http://git-scm.com")
whatis("Description: Fast Version Control System")


prepend_path(                  "PATH" , "/opt/apps/git/2.9.0/bin"              )
prepend_path(               "MANPATH" , "/opt/apps/git/2.9.0/share/man"        )
setenv (     "TACC_GIT_DIR" , "/opt/apps/git/2.9.0"                  )
setenv (     "TACC_GIT_LIB" , "/opt/apps/git/2.9.0/lib"              )
setenv (     "TACC_GIT_BIN" , "/opt/apps/git/2.9.0/bin"              )
setenv (     "GIT_EXEC_PATH"          , "/opt/apps/git/2.9.0/libexec/git-core" )
setenv (     "GIT_TEMPLATE_DIR"       , "/opt/apps/git/2.9.0/share/git-core/templates" )


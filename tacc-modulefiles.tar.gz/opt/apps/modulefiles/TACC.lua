local helpMsg = [[
The TACC modulefile defines the default paths and environment
variables needed to use the local software and utilities
available, placing them after the vendor-supplied
paths in PATH and MANPATH.
]]

help(helpMsg)


if (os.getenv("USER") ~= "root") then
  append_path("PATH",  ".")
end

load("intel")
load("impi")
load("git")
load("autotools")
load("python2")
load("cmake")
try_load("xalt")

prepend_path("MANPATH","/usr/local/man:/usr/share/man:/usr/X11R6/man:/usr/kerberos/man:/usr/man")

-- Environment change - assume single threaded to fix silly MKL
if (mode() == "load" and os.getenv("OMP_NUM_THREADS") == nil) then
  setenv("OMP_NUM_THREADS","1")
end

--prepend_path{ "PATH", "/opt/apps/tacc/bin", priority=10 }


local help_msg=[[
The PAPI module file defines the following environment variables:
TACC_PAPI_DIR, TACC_PAPI_LIB, and TACC_PAPI_INC for
the location of the tacc-papi distribution, libraries,
and include files, respectively.

To use the PAPI library, compile the source code with the option:
-I\$TACC_PAPI_INC
add the following options to the link step:
-Wl,-rpath,\$TACC_PAPI_LIB -L\$TACC_PAPI_LIB -lpapi

The -Wl,-rpath,\$TACC_PAPI_LIB option is not required, however,
if it is used, then this module will not have to be loaded
to run the program during future login sessions.

Version 5.7.0
]]

--help(help_msg)
help(help_msg)

whatis("PAPI: Performance Application Programming Interface")
whatis("Version: 5.7.0")
whatis("Category: library, performance measurement")
whatis("Keywords: Profiling, Library, Performance Measurement")
whatis("Description: Interface to monitor performance counter hardware for quantifying application behavior")
whatis("URL: http://icl.cs.utk.edu/papi/")



-- Create environment variables.
local papi_dir           = "/opt/apps/papi/5.7.0"

family("papi")
prepend_path(    "PATH",                pathJoin(papi_dir, "bin"))
prepend_path(    "LD_LIBRARY_PATH",     pathJoin(papi_dir, "lib"))
prepend_path(    "MANPATH",             pathJoin(papi_dir, "share/man"))
setenv( "TACC_PAPI_DIR",                papi_dir)
setenv( "TACC_PAPI_LIB",       pathJoin(papi_dir, "lib"))
setenv( "TACC_PAPI_BIN",       pathJoin(papi_dir, "bin"))
setenv( "TACC_PAPI_INC",       pathJoin(papi_dir, "include"))

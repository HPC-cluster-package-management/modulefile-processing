help([[
mkmod creates modulefiles using three environment varibles:
NAME, VER, and TOPDIR (having values of the name, version,
and top-level directory of the package.

The MKMOD module file defines the following environment variables:
TACC_MKMOD_DIR, TACC_MKMOD_BIN and TACC_MKMOD_DOC
and TACC_MKMOD_EXM for the location of the MKMOD 
distribution, binaries, docs and examples, respectively.
The binary dirrectory is pre-appended to the PATH variable.

Version 2.0
]])

whatis("Name: MKMOD")
whatis("Version: 2.0")
whatis("Category: library, tools")
whatis("Keywords: System, Process Viewer, Tools")
whatis("URL: https://github.com/tacc/mkmod")
whatis("Description: Modulefile Maker")


prepend_path(                  "PATH" , "/opt/apps/mkmod/2.0/bin"              )
setenv (     "TACC_MKMOD_DIR" , "/opt/apps/mkmod/2.0"                  )
setenv (     "TACC_MKMOD_BIN" , "/opt/apps/mkmod/2.0/bin"              )
setenv (     "TACC_MKMOD_DOC" , "/opt/apps/mkmod/2.0/docs"             )
setenv (     "TACC_MKMOD_EXM" , "/opt/apps/mkmod/2.0/examples"         )


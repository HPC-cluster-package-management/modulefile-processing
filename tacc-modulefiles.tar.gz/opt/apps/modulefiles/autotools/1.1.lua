local help_msg=[[
The AUTOTOOLS module file defines the environment variable
TACC_AUTOTOOLS_DIR for the location of the GNU autotools
package which provides a collection of common development utilties.
TACC_AUTOTOOLS_BIN is also defined for the location of the
tools.

Loading the AUTOTOOLS module will update your PATH to access a
recent version of m4, autoconf, automake, and libtool.

Version 1.1
]]

--help(help_msg)
help(help_msg)

whatis("Name: tacc-autotools")
whatis("Version: 1.1")

-- Create environment variables.
local autotools_dir           = "/opt/apps/autotools/1.1"

prepend_path(    "PATH",                pathJoin(autotools_dir, "bin"))
setenv( "TACC_AUTOTOOLS_DIR",                autotools_dir)
setenv( "TACC_AUTOTOOLS_BIN",       pathJoin(autotools_dir, "bin"))

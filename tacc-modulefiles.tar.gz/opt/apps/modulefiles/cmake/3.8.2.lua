local help_message = [[
CMake is an open-source, cross-platform family of tools designed to build, test
and package software. CMake is used to control the software compilation process
using simple platform and compiler independent configuration files, and
generate native makefiles and workspaces that can be used in the compiler
environment of your choice. 

This module defines the environmental variables TACC_CMAKE_BIN
and TACC_CMAKE_DIR for the location of the main CMake directory
and the binaries.

The location of the binary files is also added to your PATH.

Extended documentation on CMake can be found under $TACC_CMAKE_DIR/doc.

Version 3.8.2
]]

help(help_message,"\n")

whatis("Name: tacc-cmake")
whatis("Version: 3.8.2")
whatis("Category: system, utilities")
whatis("Keywords: System, Utility")
whatis("Description: tool for generation of files from source")
whatis("URL: http://www.cmake.org")

-- Export environmental variables
local cmake_dir="/opt/apps/cmake/3.8.2"
local cmake_bin=pathJoin(cmake_dir,"bin")
setenv("TACC_CMAKE_DIR",cmake_dir)
setenv("TACC_CMAKE_BIN",cmake_bin)

-- Prepend the cmake directories to the adequate PATH variables
prepend_path("PATH",cmake_bin)


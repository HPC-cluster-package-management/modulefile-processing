help(
[[
RStudio Desktop provides the leading R GUI to VNC desktop based interactive computing sessions.

Version 1.1.423
]]
)

whatis("Name: RstudioDesktop")
whatis("Version: 1.1.423")
whatis("Category: Applications, Statistics, Graphics")
whatis("Keywords: Applications, Statistics, Graphics, Scripting Language")
whatis("URL: https://www.rstudio.com/")
whatis("Description: Powerful IDE for R")

--
-- Create environment variables.
--
local rstudio_dir   = "/opt/apps/RstudioDesktop/1.1.423"
local rstudio_bin   = "/opt/apps/RstudioDesktop/1.1.423/bin"
local rstudio_inc   = "/opt/apps/RstudioDesktop/1.1.423/include"
local rstudio_lib   = "/opt/apps/RstudioDesktop/1.1.423/lib"
local rstudio_lib64 = "/opt/apps/RstudioDesktop/1.1.423/lib64"
local rstudio_man   = "/opt/apps/RstudioDesktop/1.1.423/share/man:/opt/apps/RstudioDesktop/1.1.423/man"

setenv("TACC_RSTUDIO_DESKTOP_DIR", rstudio_dir)
setenv("TACC_RSTUDIO_DESKTOP_BIN", rstudio_bin)
setenv("TACC_RSTUDIO_DESKTOP_LIB", rstudio_lib)

prepend_path("PATH", rstudio_bin)
prepend_path("LD_LIBRARY_PATH", rstudio_lib)
prepend_path("LD_LIBRARY_PATH", rstudio_lib64)


help(
[[
MATLAB interpreter and compiler MATLAB is a high-level language
and interactive environment that enables you to perform computationally
intensive tasks faster than with traditional programming languages
such as C, C++, and Fortran.
 
Unless you are supplying your own MATLAB license file,
you are using a license owned by University of Texas at Austin.

The UT license is for ACADEMIC USE ONLY!

Version 2018a
]]
)

whatis("Name: MATLAB")
whatis("Version: 2018a")
whatis("Category: library, mathematics")
whatis("Keywords: Library, Mathematics, Tools")
whatis("URL: http://www.mathworks.com/")
whatis("Description: Matlab 2018a from MathWorks")

prepend_path("PATH", "/home1/apps/matlab/2018a/bin")

append_path("LD_LIBRARY_PATH", "/home1/apps/matlab/2018a/bin/glnxa64")
append_path("LD_LIBRARY_PATH", "/home1/apps/matlab/2018a/runtime/glnxa64")
append_path("LD_LIBRARY_PATH", "/home1/apps/matlab/2018a/sys/java/jre/glnxa64/jre/lib/amd64/server/")

setenv ("TACC_MATLAB_DIR", "/home1/apps/matlab/2018a")
setenv ("DVS_CACHE","off")

--Set MKLROOT, BLAS_VERSION, and LAPACK_VERSION for matlab
local mklroot=os.getenv("MKLROOT")

if mklroot then
  setenv("BLAS_VERSION", pathJoin(mklroot,"lib/intel64/libmkl_rt.so") )
  setenv("LAPACK_VERSION", pathJoin(mklroot,"lib/intel64/libmkl_rt.so") )
  setenv("MKL_INTERFACE_LAYER","ILP64")
end

--License file
local UserHome=os.getenv("HOME")
append_path("LM_LICENSE_FILE", pathJoin(UserHome,".tacc_matlab_license") )


local help_message = [[
The fastqc module file defines the following environment variables:

 - TACC_FASTQC_DIR

for the location of the fastqc distribution.

Documentation: https://www.bioinformatics.babraham.ac.uk/projects/fastqc/

Version 0.11.5
]]

help(help_message,"\n")

whatis("Name: tacc-fastqc-0.11.5")
whatis("Version: 0.11.5")
whatis("Category: computational biology, genomics")
whatis("Keywords: Biology, Genomics, QC, QA")
whatis("Description: A quality control tool for high throughput sequence data")
whatis("URL: https://www.bioinformatics.babraham.ac.uk/projects/fastqc/")

prepend_path("PATH",		"/home1/apps/fastqc/0.11.5")

setenv("TACC_FASTQC_DIR",     "/home1/apps/fastqc/0.11.5")

local base        = "/opt"
local versionloc  = "2018.2.020"

whatis( "Name: itac" )
whatis( "Version: 18.0.2" )
whatis( "Category: System Software" )
whatis( "Keywords: System, Utility, Tools" )
whatis( "Description: Intel Trace Analyzer and Collector" )
whatis( "URL: https://software.intel.com/en-us/intel-trace-analyzer" )

local itac_full   = pathJoin( "intel", "itac", "2018.2.020" )
local relocatedir = pathJoin(  base,    itac_full      )
local arch64dir   = pathJoin( relocatedir, "intel64"   )

local addlibs     = "-ldwarf -lelf -lvtunwind -lm -lpthread"

setenv(       "VT_ARCH",               "intel64"                                  )
setenv(       "VT_MPI",                "impi4"                                    )
setenv(       "VT_ROOT",                relocatedir                               )

prepend_path( "LD_LIBRARY_PATH",        pathJoin( arch64dir, "slib"    )          )
prepend_path( "PATH",                   pathJoin( arch64dir, "bin"     )          )
prepend_path( "INTEL_LICENSE_FILE",    "/opt/intel/licenses:/root/intel/licenses" )
prepend_path( "MANPATH",                pathJoin( relocatedir, "man"   )          )

setenv(       "VT_ADD_LIBS",            addlibs                                   )
setenv(       "VT_LIB_DIR",             pathJoin( arch64dir, "lib"     )          )
setenv(       "VT_SLIB_DIR",            pathJoin( arch64dir, "slib"    )          )

setenv(       "MPS_INTEL_LIBITTNOTIFY64",
                                       "libmps.so"                                )
setenv(       "MPS_STAT_DIR_POSTFIX",  "_%D-%T"                                   )
setenv(       "MPS_LD_PRELOAD",        "libmps.so"                                )
setenv(       "MPS_STAT_ENABLE_IDLE_VAL",
                                       "1"                                        )
setenv(       "MPS_STAT_LEVEL",        "5"                                        )
setenv(       "MPS_KMP_FORKJOIN_FRAMES_MODE",
                                       "3"                                        )
setenv(       "MPS_STAT_ENABLE_IDLE",  "I_MPI_PVAR_IDLE"                          )
setenv(       "MPS_TOOL_ROOT",          relocatedir                               )
setenv(       "MPS_STAT_MESSAGES",     "1"                                        )

setenv(       "TACC_ITAC_DIR",          relocatedir                               )
setenv(       "TACC_ITAC_BIN",          pathJoin( arch64dir, "bin"     )          )
setenv(       "TACC_ITAC_INC",          pathJoin( arch64dir, "include" )          )
setenv(       "TACC_ITAC_LIB",          pathJoin( arch64dir, "lib"     )          )
setenv(       "TACC_ITAC_SLIB",         pathJoin( arch64dir, "slib"    )          )

help(
[[

Intel Analyzer and Collector (ITAC) is a graphical tool for understanding
MPI application behavior, quickly finding bottlenecks, improving
correctness, and achieving high performance.

For detailed info, consult the extensive documentation in
$TACC_ITAC_DIR/doc or online at
software.intel.com/en-us/intel-trace-analyzer/documentation.

ITAC is easiest to use with the Intel compiler and IMPI.
See Intel documentation for information regarding using ITAC with
other MPI stacks.

Using ITAC with the Intel Compiler and IMPI
*******************************************

To build your MPI application for ITAC and IMPI, load an intel
compiler module and impi module, then compile and link with
the trace switch; for example...

  $ module load intel/18.0.2
  $ module load impi/18.0.2
  $ module load itac/18.2
  $ mpicc -trace mycode.c -o mycode

To run an collection with ITAC, launch your MPI job with sbatch, srun,
or idev as desired.  Include the trace switch in your call to ibrun.
For example...

  $ ibrun -trace mycode

  ITAC will generate trace files in the current directory.   These will
  include multiple files for each MPI task, and a master file named
  mycode.stf (here "mycode" represents the name of your executable).

To analyze your collection, start a VNC or X11 session, then execute:

  $ traceanalyzer mycode.stf  # replace "mycode" with your executable

For instructions regarding MPI Performance Snapshot (MPS), see
$TACC_ITAC_DIR/doc/MPI_Perf_Snapshot_User_Guide.pdf.

NOTE: an easy way to start a VNC session is through the TACC vis portal
at https://vis.tacc.utexas.edu.

SPECIAL CIRCUMSTANCES
*********************

Here is a (partial) list of special circumstances; see the Intel docs for
more info:

  -- MPI stacks other than IMPI
  -- C++ programs that use the MPI C++ API instead of the C API
  -- Programs that make explicit calls to the ITAC API
  -- MPI programs with multi-threading (hybrid programs)

ENVIRONMENT VARIABLES
*********************

This module defines the following additional environment variables:

   VT_ARCH           host architecture (intel64)
   VT_ROOT           ITAC top-level directory
   VT_MPI            MPI type ("impi4" even with newer versions of IMPI)

   VT_ADD_LIBS       list of required libraries
   VT_LIB_DIR        directory containing static libs
   VT_SLIB_DIR       directory containing shared libs

   MPS_*             nine variables of this form needed by MPS

   TACC_ITAC_DIR     TACC equivalent of VT_ROOT
   TACC_ITAC_BIN     directory containing ITAC executables
   TACC_ITAC_INC     directory containing ITAC include files
   TACC_ITAC_LIB     TACC equivalent of VT_LIB_DIR
   TACC_ITAC_SLIB    TACC equivalent of VT_SLIB_DIR

The modulefile also prepends to PATH, CLASSPATH, LD_LIBRARY_PATH,
and a variety of other environment variables.

To see the exact effect of loading the module, execute "module show itac".

Version 18.0.2 (file version 18.0.2)
]]
)


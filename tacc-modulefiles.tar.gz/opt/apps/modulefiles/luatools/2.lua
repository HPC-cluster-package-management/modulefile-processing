-- -*- lua -*-
help(
[[
This module is for luatools.  These are lua modulefiles that provide the strict.lua package.
Version 2
]])

local version = "2"
whatis("Name: luatools")
whatis("Version: " .. version)
whatis("Category: System Software")
whatis("Keywords: System, Utility, Tools")
whatis("Description: tools for lua")

if (os.getenv("LUA_PATH") == nil) then
   prepend_path("LUA_PATH",";",";")
end
if (os.getenv("LUA_CPATH") == nil) then
   prepend_path("LUA_CPATH",";",";")
end

prepend_path("LUA_PATH", "/opt/apps/luatools/2/share/lua/5.1/?/init.lua", ";")
prepend_path("LUA_PATH", "/opt/apps/luatools/2/share/lua/5.1/?.lua",      ";")
prepend_path("LUA_CPATH","/opt/apps/luatools/2/lib/lua/5.1/?.so",         ";")


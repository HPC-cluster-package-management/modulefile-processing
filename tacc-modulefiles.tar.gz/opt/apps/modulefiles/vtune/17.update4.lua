-- ****************************************************************************
--
-- modulefile for VTune (module vtune/17.update4)
--
-- Built for Stampede 2
--
-- Probably best to install in /opt/apps/modulefiles.
--   Doesn't depend on any particular version of the Intel compiler.
--   And in theory one could use this with another compiler.
--
-- djames (at) tacc.utexas.edu
--
-- Revision history
-- 
-- 11 Jul 2017    v1   Initial release
--
-- ****************************************************************************

local vtune_dir   = "/opt/intel//vtune_amplifier_xe_2017.4.0.518798"
local version     = "2017.4.0"

whatis( "Name: vtune" )
whatis( "Version: "..version )
whatis( "Category: performance analysis" )
whatis( "Keywords: System, Utility, Tools" )
whatis( "Description: Intel VTune Amplifier" )
whatis( "URL: https://software.intel.com/en-us/intel-vtune-amplifier-xe" )

prepend_path(     "PATH", pathJoin( vtune_dir, "bin64"   )   )

setenv( "TACC_VTUNE_DIR", vtune_dir                          )
setenv( "TACC_VTUNE_BIN", pathJoin( vtune_dir, "bin64"   )   )
setenv( "TACC_VTUNE_LIB", pathJoin( vtune_dir, "lib64"   )   )
setenv( "TACC_VTUNE_INC", pathJoin( vtune_dir, "include" )   )

help(
[[

VTune is Intel's signature performance profiling tool.

For detailed info, consult the extensive documentation in 
$TACC_VTUNE_DIR/documentation or online at 
software.intel.com/en-us/intel-vtune-amplifier-xe.

COLLECTION
**********

First, compile with "-g".

To collect data on an executable named main.exe,
using a collection named "hotspots", execute the following 
command on a compute node:

   amplxe-cl -collect hotspots -- main.exe

Note the "--" followed by a space.

This will generate a directory with a name like 'r000hs' or 'r000ah'
("hs" means "hotspots";  "ah" means "advanced-hotspots").
It will also print a brief summary report to stdout.

You can reduce the sampling rate to use less memory,
reduce collection time,  and generate smaller database files.
To reduce the sampling rate to 15ms (default is 1-4ms):

   amplxe-cl -collect hotspots -knob sampling-interval=15 -- main.exe

ANALYSIS AND REPORTING
**********************

Assuming a collection directory named "r000hs".
From a login or compute node with X11:

   amplxe-gui r000hs

There are also text-based command-line analysis and report utilities.

ENVIRONMENT VARIABLES
*********************

This modulefile defines TACC_VTUNE_DIR, TACC_VTUNE_BIN, TACC_VTUNE_LIB,
and TACC_VTUNE_INC in the usual way.  It also preprends VTune's bin64
directory to $PATH.

To see the exact effect of loading the module, execute "module show vtune".

Version 2017 update 4  (file version 17.update4)
]]
)

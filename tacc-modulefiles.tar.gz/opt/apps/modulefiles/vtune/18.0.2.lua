local vtune_dir   = "/opt/intel/vtune_amplifier_2018.4.0.574913"

whatis( "Name: vtune" )
whatis( "Version: 18.0.2" )
whatis( "Category: performance analysis" )
whatis( "Keywords: System, Utility, Tools" )
whatis( "Description: Intel VTune Amplifier" )
whatis( "URL: https://software.intel.com/en-us/intel-vtune-amplifier-xe" )

prepend_path(     "PATH", pathJoin( vtune_dir, "bin64"   )   )

setenv( "TACC_VTUNE_DIR", vtune_dir                          )
setenv( "TACC_VTUNE_BIN", pathJoin( vtune_dir, "bin64"   )   )
setenv( "TACC_VTUNE_LIB", pathJoin( vtune_dir, "lib64"   )   )
setenv( "TACC_VTUNE_INC", pathJoin( vtune_dir, "include" )   )

help(
[[

VTune is Intel's signature performance profiling tool.

For detailed info, consult the extensive documentation in
$TACC_VTUNE_DIR/documentation or online at
software.intel.com/en-us/intel-vtune-amplifier-xe.

COLLECTION
**********

First, compile with "-g".

To collect data on an executable named main.exe,
using a collection named "hotspots", execute the following
command on a compute node:

   amplxe-cl -collect hotspots -- main.exe

Note the "--" followed by a space.

This will generate a directory with a name like 'r000hs' or 'r000ah'
("hs" means "hotspots";  "ah" means "advanced-hotspots").
It will also print a brief summary report to stdout.

You can reduce the sampling rate to use less memory,
reduce collection time,  and generate smaller database files.
To reduce the sampling rate to 15ms (default is 1-4ms):

   amplxe-cl -collect hotspots -knob sampling-interval=15 -- main.exe

ANALYSIS AND REPORTING
**********************

Assuming a collection directory named "r000hs".
From a login or compute node with X11:

   amplxe-gui r000hs

There are also text-based command-line analysis and report utilities.

ENVIRONMENT VARIABLES
*********************

This modulefile defines TACC_VTUNE_DIR, TACC_VTUNE_BIN, TACC_VTUNE_LIB,
and TACC_VTUNE_INC in the usual way.  It also preprends VTune's bin64
directory to $PATH.

To see the exact effect of loading the module, execute "module show vtune".

Version 18.0.2
]]
)


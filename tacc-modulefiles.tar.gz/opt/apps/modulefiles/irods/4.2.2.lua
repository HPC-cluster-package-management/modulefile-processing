local help_message = [[
The irods module file defines the following environment variables:

 - TACC_IRODS_DIR
 - TACC_IRODS_BIN
 - TACC_IRODS_LIB
 - TACC_IRODS_INC

for the location of the irods distribution.

Documentation: https://docs.irods.org/master/icommands/user/

Version 4.2.2
]]

help(help_message,"\n")

whatis("Name: irods")
whatis("Version: 4.2.2")
whatis("Category: irods, cli, transfer")
whatis("Keywords: irods, cli, iget")
whatis("Description: iCommands - command line interface to iRODS")
whatis("URL: https://docs.irods.org/master/icommands/user/")

prepend_path("PATH",		"/home1/apps/irods/4.2.2/usr/bin")
prepend_path("LD_LIBRARY_PATH",	"/home1/apps/irods/4.2.2/usr/lib")
prepend_path("MANPATH",		"/home1/apps/irods/4.2.2/usr/share/man")

setenv("TACC_IRODS_DIR",     "/home1/apps/irods/4.2.2")
setenv("TACC_IRODS_BIN",	"/home1/apps/irods/4.2.2/usr/bin")
setenv("TACC_IRODS_LIB",	"/home1/apps/irods/4.2.2/usr/lib")
setenv("TACC_IRODS_INC",	"/home1/apps/irods/4.2.2/usr/include")
setenv("IRODS_PLUGINS_HOME",	"/home1/apps/irods/4.2.2/usr/lib/irods/plugins")

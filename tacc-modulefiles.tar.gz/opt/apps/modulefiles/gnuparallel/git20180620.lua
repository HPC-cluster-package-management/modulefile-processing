help( [[
Module tacc-gnuparallel loads environmental variables defining
the location of GNUPARALLEL directory and binaries:
TACC_GNUPARALLEL_DIR TACC_GNUPARALLEL_BIN

Executing a file of commandlines:

gnuparallel_command_file_execute.sh commands

Version: git20180620
]] )

whatis( "GNUPARALLEL" )
whatis( "Version: git20180620" )
whatis( "Category: system" )
whatis( "Keywords: System, utilities" )
whatis( "Description: GNU Parallel utility" )
whatis( "URL: https://www.gnu.org/software/parallel/" )

local version =  "git20180620"
local gnuparallel_dir =  "/opt/apps/gnuparallel/git20180620"

setenv("TACC_GNUPARALLEL_DIR",gnuparallel_dir)
setenv("TACC_GNUPARALLEL_BIN",pathJoin( gnuparallel_dir,"bin" ) )

prepend_path ("PATH",pathJoin( gnuparallel_dir,"bin" ) )
prepend_path ("PATH",pathJoin( gnuparallel_dir,"scripts" ) )

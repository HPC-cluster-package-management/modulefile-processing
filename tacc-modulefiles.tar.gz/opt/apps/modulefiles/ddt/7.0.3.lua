
--  modulefile for DDT 

local help_message = [[

For detailed instructions, go to:
   https://portal.tacc.utexas.edu/software/ddt

0.  Login to Stampede with X11 enabled:
        ssh -Y knl-login1.stampede.tacc.utexas.edu

1.  Load the ddt module:
        module load ddt

2.  Start ddt
        ddt ./<host_exe> <args>

3.  Set your mpi type via the "Change" button in the MPI pane in the 
    "DDT - Run" window.  Choose "Intel MPI (MPD)" from the 
     "MPI/UPC Implementation" dropdown menu.

4.  Set the number of tasks to the TOTAL number of MPI tasks in the 
    "Number of processes" window in the MPI section.

5.  Set the number of nodes to the number of nodes you would like to 
    run on.  This is analagous to using "-N #" in a slurm batch script.

6.  Set your project via the "Parameters" button in the 
    "Queue Submission Parameters" pane.

7.  Submit your job using the "Submit" at the bottom of the 
    "DDT - Run" window.

8.  A "Job Submitted" window should appear and show all of the jobs you 
    have in the queue, including a job named "ddt".  Once the batch 
    job begins, the DDT Debugging window will appear.

]]

help(help_message,"\n")

whatis("Version: 7.0.3")
whatis("Category: utility, runtime support")
whatis("Keywords: System, Utility")
whatis("URL: http://content.allinea.com/downloads/userguide.pdf")
whatis("Description: Parallel, graphical, symbolic debugger")

local home = os.getenv("HOME")


setenv("DDTROOT","/home1/apps/ddt/7.0.3")
setenv("DDTPATH","/home1/apps/ddt/7.0.3/bin")
setenv("TACC_DDT_DIR","/home1/apps/ddt/7.0.3")
setenv("TACC_DDT_BIN","/home1/apps/ddt/7.0.3/bin")
setenv("ALLINEA_TOOLS_CONFIG_DIR",pathJoin(home,".allinea_7.0.3"))
prepend_path("PATH","/home1/apps/ddt/7.0.3/bin")
prepend_path("LD_LIBRARY_PATH","/home1/apps/ddt/7.0.3/lib")


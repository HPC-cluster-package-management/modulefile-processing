local help_msg=[[
The QT4 module defines the following environment variables:
TACC_QT4_DIR, TACC_QT4_LIB, TACC_QT4_INC and
TACC_QT4_BIN for the location of the QT4 distribution, libraries,
include files, and tools respectively.
]]

--help(help_msg)
help(help_msg)

whatis("Name: qt4")
whatis("Version: 4.8.7")

-- Create environment variables.
local qt_dir           = "/opt/apps/qt4/4.8.7"

family("qt")
prepend_path(    "PATH",                pathJoin(qt_dir, "bin"))
prepend_path(    "LD_LIBRARY_PATH",     pathJoin(qt_dir, "lib"))
prepend_path(    "MODULEPATH",         "/opt/apps/qt4.8.7/modulefiles")
prepend_path(    "QT_QPA_PLATFORM_PLUGIN_PATH", pathJoin(qt_dir, "plugins"))
setenv( "QTDIR",                qt_dir)
setenv( "QT4DIR",                qt_dir)
setenv( "TACC_QT4_DIR",                qt_dir)
setenv( "TACC_QT4_INC",       pathJoin(qt_dir, "include"))
setenv( "TACC_QT4_LIB",       pathJoin(qt_dir, "lib"))
setenv( "TACC_QT4_BIN",       pathJoin(qt_dir, "bin"))


-- ****************************************************************************
--
-- modulefile for Mathematica (module mathematica/11.2)
--
-- Since the application is in /work/apps, this modulefile works on
-- any TACC system that mounts /work.
--
-- Install in /opt/apps/modulefiles.
--   Doesn't depend on any particular version of the Intel compiler.
--
-- djames (at) tacc.utexas.edu
--
-- Revision history
-- 
-- 22 Jan 2018    v1   Initial release; substantially revised adaptation
--                     of an existing TCL modulefile
--
-- ****************************************************************************

local mathematica_base = "/work/apps/mathematica"
local version          = "11.2"

local mathematica_dir  = pathJoin( mathematica_base, version      )
local mathematica_bin  = pathJoin( mathematica_dir, "Executables" )

whatis( "Name: Mathematica" )
whatis( "Version: "..version )
whatis( "Category: mathematics" )
whatis( "Keywords: Mathematics, Symbolic, Tools" )
whatis( "Description: commercial technical computing system" )
whatis( "URL: wolfram.com/mathematica" )

setenv( "MATHEMATICA_BASE",     mathematica_base )
setenv( "TACC_MATHEMATICA_DIR", mathematica_dir  )
setenv( "TACC_MATHEMATICA_BIN", mathematica_bin  )

prepend_path( "PATH",           mathematica_bin  )


help(
[[

Mathematica is a commercial technical computing system.

Please do not run mathematica on a login node.

To run Mathematica interactively, use idev to get a compute node,
then execute one of these commands:

$ math          # command-line (text-based) interface
$ mathematica   # graphical interface (requires X11 or equivalent)

Documentation is available at wolfram.com/mathematica.

This module defines the environment variables MATHEMATICA_BASE,
TACC_MATHEMATICA_DIR, and TACC_MATHEMATICA_BIN.  The module also prepends
$TACC_MATHEMATICA_BIN to PATH.  To see the exact effect of loading the 
module, execute "module show mathematica".

Version 11.2 (file version 11.2)
]]
)


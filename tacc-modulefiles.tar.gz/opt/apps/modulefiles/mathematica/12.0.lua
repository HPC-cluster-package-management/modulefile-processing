local help_msg=[[
Wolfram Mathematica (usually termed Mathematica) is a modern technical
computing system spanning most areas of technical computing - including neural
networks, machine learning, image processing, geometry, data science,
visualizations, and others.

Please do not run mathematica on a login node.
To run Mathematica interactively, use idev to get a compute node,
then execute one of these commands:

$ math          # command-line (text-based) interface
$ mathematica   # graphical interface (requires X11 or equivalent)

Documentation is available at wolfram.com/mathematica.

The MATHEMATICA module also defines the following environment variables:
TACC_MATHEMATICA_DIR, TACC_MATHEMATICA_BASE, and TACC_MATHEMATICA_BIN 
for the location of the MATHEMATICA distribution, binaries, and tools respectively.
The module also prepends TACC_MATHEMATICA_BIN to PATH.

Version 12.0
]]

help(help_msg)

-- Create environment variables.
local mathematica_base = "/work/apps/mathematica"
local version          = "12.0"

local mathematica_dir  = pathJoin( mathematica_base, version      )
local mathematica_bin  = pathJoin( mathematica_dir, "Executables" )

whatis( "Name: Mathematica" )
whatis( "Version: "..version )
whatis( "Category: mathematics" )
whatis( "Keywords: Mathematics, Symbolic, Tools" )
whatis( "Description: commercial technical computing system" )
whatis( "URL: wolfram.com/mathematica" )

setenv( "MATHEMATICA_BASE",     mathematica_base )
setenv( "TACC_MATHEMATICA_DIR", mathematica_dir  )
setenv( "TACC_MATHEMATICA_BIN", mathematica_bin  )
prepend_path( "PATH",           mathematica_bin  )


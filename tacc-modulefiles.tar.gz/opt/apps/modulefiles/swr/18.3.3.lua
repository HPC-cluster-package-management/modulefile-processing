local help_msg=[[
The SWR module defines the following environment variables:
TACC_SWR_DIR, TACC_SWR_LIB, TACC_SWR_INC and
TACC_SWR_BIN for the location of the SWR distribution, libraries,
include files, and tools respectively.
]]

--help(help_msg)
help(help_msg)

whatis("Name: swr")
whatis("Version: 18.3.3")

-- Create environment variables.
local swr_dir           = "/home1/apps/swr/18.3.3"

family("swr")
prepend_path(    "PATH",                pathJoin(swr_dir, "bin"))
prepend_path(    "MODULEPATH",         "/opt/apps/swr18.3.3/modulefiles")
setenv( "TACC_SWR_DIR",                swr_dir)
setenv( "TACC_SWR_INC",       pathJoin(swr_dir, "include"))
setenv( "TACC_SWR_LIB",       pathJoin(swr_dir, "lib"))
setenv( "TACC_SWR_BIN",       pathJoin(swr_dir, "bin"))

prepend_path( "PATH"                     , pathJoin(swr_dir,"bin"       )               )
prepend_path( "SWR_LD_LIBRARY_PATH"          , pathJoin(swr_dir,"lib"       )               )
prepend_path( "SWR_LD_LIBRARY_PATH"          , pathJoin(swr_dir,"lib64"     )               )
prepend_path( "INCLUDE"                  , pathJoin(swr_dir,"include"   )               )

local gcc_dir                              = "/opt/apps/gcc/6.3.0"
prepend_path( "PATH"                     , pathJoin(gcc_dir,"bin"       )               )
prepend_path( "SWR_LD_LIBRARY_PATH"          , pathJoin(gcc_dir,"lib"       )               )
prepend_path( "SWR_LD_LIBRARY_PATH"          , pathJoin(gcc_dir,"lib64"     )               )
prepend_path( "INCLUDE"                  , pathJoin(gcc_dir,"include"   )               )



local help_msg=[[
TACC LTOOLS (Lustre Tools) provides a customized set of core utilities
that have been modified to be Lustre-aware. This allows for automatic striping
of large files across multiple Object Storage Targets (OSTs) on Lustre file
systems.  This not only will help read/write performance in most cases but will
also minimize the potential for user-generated files to negatively impact
others on the system. 

Utilities include: cp, gzip, bzip2, xz, pcp, pigz, pbzip2, and pxz.

The LTOOLS module defines the following environment variables:
TACC_LTOOLS_DIR, TACC_LTOOLS_LIB, TACC_LTOOLS_INC and
TACC_LTOOLS_BIN for the location of the LTOOLS distribution,
libraries, include files, and tools respectively.

Version 1.2
]]

--help(help_msg)
help(help_msg)

whatis("Name: tacc-ltools")
whatis("Version: 1.2")

-- Create environment variables.
local base_dir           = "/opt/apps/ltools/1.2"

prepend_path(    "PATH",                pathJoin(base_dir, "bin"))
prepend_path(    "LD_LIBRARY_PATH",     pathJoin(base_dir, "lib"))
prepend_path(    "INCLUDE",             pathJoin(base_dir, "include"))
prepend_path(    "MANPATH",             pathJoin(base_dir, "man"))
prepend_path(    "MANPATH",             pathJoin(base_dir, "share/man"))
setenv( "TACC_LTOOLS_DIR",                base_dir)
setenv( "TACC_LTOOLS_INC",       pathJoin(base_dir, "include"))
setenv( "TACC_LTOOLS_LIB",       pathJoin(base_dir, "lib"))
setenv( "TACC_LTOOLS_BIN",       pathJoin(base_dir, "bin"))

-- -*- lua -*-
help(
[[
This module is for Lmod.  Normal user will probably not need to
load this module.  It is only required if one is using the tools
that are part of Lmod.

Version 7.8.21
]])

local version = "7.8.21"
whatis("Name: Lmod")
whatis("Version: " .. version)
whatis("Category: System Software")
whatis("Keywords: System, Utility, Tools")
whatis("Description: An environment module system")
whatis("URL: http://www.tacc.utexas.edu/tacc-projects/lmod")

prepend_path( "PATH",            "/opt/apps/lmod/lmod/libexec" )

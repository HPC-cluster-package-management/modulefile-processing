local help_msg=[[ 
The IDL module defines the following environment variables:
TACC_IDL_DIR, ITT_DIR and IDL_DIR
]]

--help(help_msg)
help(help_msg)

whatis("Name: idl")
whatis("Version: 8.4")

-- Create environment variables.
local idl_dir           = "/home1/apps/idl/8.4"

family("idl")

prepend_path("PATH",              pathJoin(idl_dir, "idl", "bin"))

prepend_path("MODULEPATH",        "/opt/apps/idl8_4/modulefiles")

setenv("TACC_IDL_DIR",  idl_dir)
setenv("IDL_DIR",  		  pathJoin(idl_dir, "idl"))
setenv("ITT_DIR",  		  idl_dir)

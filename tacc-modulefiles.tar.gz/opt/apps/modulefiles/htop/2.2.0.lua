help([[
Htop is a ncurses-based process viewer for Linux.

The HTOP module file defines the following environment variables:
TACC_HTOP_DIR, TACC_HTOP_BIN and TACC_HTOP_MAN 
for the location of the HTOP distribution, binaries, and man
pages, respectively.
The binary and man directories are pre-appended to the PATH and MANPATH variables.

Version 2.2.0
]])

whatis("Name: HTOP")
whatis("Version: 2.2.0")
whatis("Category: library, tools")
whatis("Keywords: System, Process Viewer, Tools")
whatis("URL: https://hisham.hm/htop/")
whatis("Description: Process Viewer using ncurses, info is similar to top")


prepend_path(                  "PATH" , "/opt/apps/htop/2.2.0/bin"              )
prepend_path(               "MANPATH" , "/opt/apps/htop/2.2.0/share/man"        )
setenv (     "TACC_HTOP_DIR" , "/opt/apps/htop/2.2.0"                  )
setenv (     "TACC_HTOP_BIN" , "/opt/apps/htop/2.2.0/bin"              )
setenv (     "TACC_HTOP_MAN" , "/opt/apps/htop/2.2.0/share/man"              )


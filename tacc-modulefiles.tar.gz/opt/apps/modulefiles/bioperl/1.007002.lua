local help_message = [[
The bioperl module file defines the following environment variables:

 - TACC_BIOPERL_DIR
 - TACC_BIOPERL_BIN
 - TACC_BIOPERL_LIB
 - TACC_BIOPERL_INC

for the location of the bioperl distribution.

Documentation: http://www.bioperl.org/wiki/Main_Page

Version 1.007002
]]

help(help_message,"\n")

whatis("Name: bioperl")
whatis("Version: 1.007002")
whatis("Category: computational biology, genomics")
whatis("Keywords: Biology, Genomics")
whatis("Description: BioPerl is a toolkit of perl modules useful in bioinformatics solutions in Perl.")
whatis("URL: http://www.bioperl.org/wiki/Main_Page")

prepend_path("PATH",		"/home1/apps/bioperl/1.007002/bin")
prepend_path("LD_LIBRARY_PATH",	"/home1/apps/bioperl/1.007002/lib")
prepend_path("MANPATH",		"/home1/apps/bioperl/1.007002/share/man")
prepend_path("PERL5LIB",        "/home1/apps/bioperl/1.007002/lib/perl5")

setenv("TACC_BIOPERL_DIR",     "/home1/apps/bioperl/1.007002")
setenv("TACC_BIOPERL_BIN",	"/home1/apps/bioperl/1.007002/bin")
setenv("TACC_BIOPERL_LIB",	"/home1/apps/bioperl/1.007002/lib")
setenv("TACC_BIOPERL_INC",	"/home1/apps/bioperl/1.007002/include")

help (
[[
                         Biocontainers
===============================================================

TACC has made biocontainers available through standard LMOD
modules for browsing and command line usability by exposing
important executables.

All biocontainer modules have their version prefixed with 
"ctr-" to help distinguish native packages from containers.

Please remember that since these tools live in containers, they
only function on compute nodes through idev or sbatch.

---------------------------------------------------------------
Usage
---------------------------------------------------------------

If you are looking for a specific tool, check for it and all
versions available with

  $ module spider [toolname]

If you are not sure what tool you need, and want to browse all
categories

  $ module keyword [category]

If you want to browse our entire overwhelming list of modules,
feel free to do so with

  $ module avail

We also disabled paging on LMOD, so you can pipe that output to
less or grep

  $ module avail | less -S

  $ module avail | grep "toolname"

---------------------------------------------------------------
Help
---------------------------------------------------------------

If the tool is broken, please create an issue on

  https://github.com/BioContainers/containers/issues

If the module is broken or the executable is not exposed
through the module file, please create a ticket on

  https://portal.tacc.utexas.edu/tacc-consulting

and cc gzynda@tacc.utexas.edu
]])

whatis("Name: biocontainers")
whatis("Version: 0.1.0")
whatis("Category: Biology")
whatis("Keywords: bio, containers, biocontainer, bioconda, singularity")
whatis("Description: Biocontainers accessible through module files")
whatis("URL: https://biocontainers.pro/")

depends_on("tacc-singularity")
prereq("tacc-singularity")

local bcd = "/work/projects/singularity/TACC/bio_modules"
setenv("BIOCONTAINER_DIR",	bcd)
setenv("LMOD_CACHED_LOADS",	"yes")
setenv("LMOD_PAGER",		"none")
setenv("LMOD_REDIRECT",		"yes")
prepend_path("LMOD_RC",		bcd .. "/lmod/lmodrc.lua")
if(mode() ~= "spider") then
	prepend_path("MODULEPATH",	bcd .. "/modulefiles")
end

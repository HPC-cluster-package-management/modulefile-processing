local help_message = [[
The gatk module file defines the following environment variables:

 - TACC_GATK_DIR

for the location of the gatk distribution.

Call the GATK jar file using the following syntax:

java <java options> -jar $TACC_GATK_DIR/GenomeAnalysisTK.jar <gatk options>

Documentation: https://software.broadinstitute.org/gatk/

Version 3.8.0
]]

help(help_message,"\n")

whatis("Name: gatk")
whatis("Version: 3.8.0")
whatis("Category: computational biology, genomics")
whatis("Keywords: Biology, Genomics, Genotyping, Resequencing, SNP")
whatis("Description: The Genome Analysis ToolKit is used to to analyze high-throughput sequencing data")
whatis("URL: https://software.broadinstitute.org/gatk/")

prepend_path("PATH",		"/home1/apps/gatk/3.8.0")

setenv("TACC_GATK_DIR",     "/home1/apps/gatk/3.8.0")

local help_message = [[
OpenFabrics Interfaces (OFI) is a framework focused on exporting fabric
communication services to applications. OFI is best described as a collection
of libraries and applications used to export fabric services. The key
components of OFI are: application interfaces, provider libraries, kernel
services, daemons, and test applications.

This module defines the environmental variables TACC_LIBFABRIC_DIR,
TACC_LIBFABRIC_BIN, TACC_LIBFABRIC_LIB, and TACC_LIBFABRIC_INC
for the location of the main libfabric directory, binaries, libraries,
and include files respectively.

The location of the binary files is also added to your PATH.
The location of the library files is also added to your LD_LIBRARY_PATH.
Documentation is also added to your MANPATH.

Version 1.7.0
]]

help(help_message,"\n")

whatis("Name: tacc-libfabric")
whatis("Version: 1.7.0")
whatis("Category: system, environment libaries")
whatis("Keywords: System, Environment Libraries")
whatis("Description: Fabric communication services")
whatis("URL: http://www.github.com/ofiwg/libfabric")

-- Export environmental variables
local libfabric_dir="/opt/apps/libfabric/1.7.0"
local libfabric_bin=pathJoin(libfabric_dir,"bin")
local libfabric_lib=pathJoin(libfabric_dir,"lib")
local libfabric_inc=pathJoin(libfabric_dir,"include")
setenv("TACC_LIBFABRIC_DIR",libfabric_dir)
setenv("TACC_LIBFABRIC_BIN",libfabric_bin)
setenv("TACC_LIBFABRIC_LIB",libfabric_lib)
setenv("TACC_LIBFABRIC_INC",libfabric_inc)

-- Prepend the libfabric directories to the adequate PATH variables
prepend_path("PATH",libfabric_bin)
prepend_path("LD_LIBRARY_PATH",libfabric_lib)
prepend_path("MANPATH", pathJoin(libfabric_dir, "share/man"))


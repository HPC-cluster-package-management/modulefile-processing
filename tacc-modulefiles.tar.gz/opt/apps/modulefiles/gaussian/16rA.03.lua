
local help_message = [[
The use of Gaussian is restricted to TACC users who have formally agreed to
the associated Usage Agreement document supplied by TACC. For questions about 
access or a copy of the required form, please email jfonner@tacc.utexas.edu.

This compilation of gaussian 16rA.03 is not optimized for the Intel Xeon Phi
processor, but it is compatible.  TACC is provisionally supplying it until a Phi
optimized version becomes available.

The gaussian module file defines TACC_GAUSSIAN_DIR in the environment, sets
g19root to that directory and sets GAUSS_SCRDIR to /tmp/, which is local
scratch space on all the nodes. If you think you want to store temporary files
in your personal SCRATCH directory, set the GAUSS_SCRDIR in your job submission
script or local environment.

Linda is not included in the module, so Gaussian should be set to use the max
number of cores on a single node, which is set by the NProcShared variable in
your input file.  Gaussian does not use ibrun.  Your command will look
something like this:

g16 < input > output

Gaussian online documentation is here:
http://gaussian.com/man/

Version 16rA.03
]]

local err_message = [[
You do not have access to Gaussian 16.

The use of Gaussian is restricted to TACC users who have formally agreed to
the associated Confidentiality Agreement document supplied by TACC. For
questions about access or a copy of the required form, please email
jfonner@tacc.utexas.edu.

]]

local group = "G-813687"
local grps  = capture("groups")
local found = false
local isRoot = tonumber(capture("id -u")) == 0
for g in grps:split("[ \n]") do
    if (g == group or isRoot)  then
        found = true
        break
    end
end

whatis("Name: Gaussian")
whatis("Version: 16rA.03 rev A.03")
whatis("Category: computational biology, chemistry")
whatis("Keywords: Biology, Quantum Mechanics, QM")
whatis("URL: http://www.gaussian.com/")
whatis("Description: Gaussian 16 quantum chemistry package")

help(help_message,"\n")

if (found) then
append_path( "PATH",              "/home1/apps/gaussian/16rA.03/g16")
    setenv (  "g16root",           "/home1/apps/gaussian/16rA.03/")
    setenv (  "GAUSS_SCRDIR",      "/tmp/")
    setenv (  "GAUSS_EXEDIR",      "/home1/apps/gaussian/16rA.03/g16")
    setenv (  "TACC_GAUSSIAN_DIR", "/home1/apps/gaussian/16rA.03/")
    setenv (  "TACC_GAUSSIAN_BIN", "/home1/apps/gaussian/16rA.03/g16")

else
    LmodError(err_message,"\n")
end


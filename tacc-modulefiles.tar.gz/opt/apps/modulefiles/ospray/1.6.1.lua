local help_msg=[[
The OSPRAY module defines the following environment variables:
TACC_OSPRAY_DIR, TACC_OSPRAY_LIB, TACC_OSPRAY_INC and
TACC_OSPRAY_BIN for the location of the OSPRAY distribution, libraries,
include files, and tools respectively.
]]

--help(help_msg)
help(help_msg)

whatis("Name: OSPray")
whatis("Version: 1.6.1")

-- Create environment variables.
local ospray_dir           = "/opt/apps/ospray/1.6.1"

family("ospray")
prepend_path(    "PATH",                pathJoin(ospray_dir, "bin"))
prepend_path(    "LD_LIBRARY_PATH",     pathJoin(ospray_dir, "lib"))
prepend_path(    "LD_LIBRARY_PATH",     pathJoin(ospray_dir, "lib64"))
prepend_path(    "MODULEPATH",         "/opt/apps/ospray1.6.1/modulefiles")

setenv( "TACC_OSPRAY_DIR",                "/opt/apps/ospray/1.6.1")
setenv( "TACC_OSPRAY_INC",       pathJoin(ospray_dir, "include"))
setenv( "TACC_OSPRAY_LIB",       pathJoin(ospray_dir, "lib64"))
setenv( "TACC_OSPRAY_BIN",       pathJoin(ospray_dir, "bin"))

setenv( "embree_DIR",	"/opt/apps/ospray/1.6.1")
setenv( "ospray_DIR",	"/opt/apps/ospray/1.6.1")
setenv( "TACC_EMBREE_DIR",                "/opt/apps/ospray/1.6.1")
setenv( "TACC_EMBREE_INC",       pathJoin(ospray_dir, "include"))
setenv( "TACC_EMBREE_LIB",       pathJoin(ospray_dir, "lib64"))
setenv( "TACC_EMBREE_BIN",       pathJoin(ospray_dir, "bin"))

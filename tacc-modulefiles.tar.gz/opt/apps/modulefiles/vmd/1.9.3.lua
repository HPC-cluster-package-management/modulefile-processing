local help_msg=[[
The VMD module defines the following environment variables:
TACC_VMD_DIR, TACC_VMD_LIB, TACC_VMD_INC and
TACC_VMD_BIN for the location of the VMD distribution, libraries,
include files, and tools respectively.
]]

--help(help_msg)
help(help_msg)

whatis("Name: bar")
whatis("Version: 1.9.3")

-- Create environment variables.
local bar_dir           = "/opt/apps/vmd/1.9.3"

family("bar")
prepend_path(    "PATH",                pathJoin(bar_dir, "bin"))
prepend_path(    "LD_LIBRARY_PATH",     pathJoin(bar_dir, "lib"))
prepend_path(    "MODULEPATH",         "/opt/apps/bar1_1/modulefiles")
setenv( "TACC_VMD_DIR",                bar_dir)
setenv( "TACC_VMD_INC",       pathJoin(bar_dir, "include"))
setenv( "TACC_VMD_LIB",       pathJoin(bar_dir, "lib"))
setenv( "TACC_VMD_BIN",       pathJoin(bar_dir, "bin"))

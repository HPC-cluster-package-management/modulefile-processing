local help_message = [[
The blast module file defines the following environment variables:

 - TACC_BLAST_DIR
 - TACC_BLAST_BIN

for the location of the blast distribution.

Documentation: https://blast.ncbi.nlm.nih.gov

Version 2.6.0
]]

help(help_message,"\n")

whatis("Name: blast")
whatis("Version: 2.6.0")
whatis("Category: computational biology, genomics")
whatis("Keywords: Biology, Genomics")
whatis("Description: NCBI BLAST+ sequence alignment package")
whatis("URL: https://blast.ncbi.nlm.nih.gov")

prepend_path("PATH",		"/home1/apps/blast/2.6.0/bin")

setenv("TACC_BLAST_DIR",     "/home1/apps/blast/2.6.0")
setenv("TACC_BLAST_BIN",	"/home1/apps/blast/2.6.0/bin")

local help_msg=[[
The QT5 module defines the following environment variables:
TACC_QT5_DIR, TACC_QT5_LIB, TACC_QT5_INC and
TACC_QT5_BIN for the location of the QT5 distribution, libraries,
include files, and tools respectively.
]]

--help(help_msg)
help(help_msg)

whatis("Name: qt5")
whatis("Version: 5.11.2")

-- Create environment variables.
local qt_dir           = "/opt/apps/qt5/5.11.2"

family("qt")
prepend_path(    "PATH",                pathJoin(qt_dir, "bin"))
prepend_path(    "LD_LIBRARY_PATH",     pathJoin(qt_dir, "lib"))
prepend_path(    "MODULEPATH",         "/opt/apps/qt5.11.2/modulefiles")
prepend_path(    "QT_QPA_PLATFORM_PLUGIN_PATH", pathJoin(qt_dir, "plugins"))
setenv( "QTDIR",                qt_dir)
setenv( "TACC_QT5_DIR",                qt_dir)
setenv( "TACC_QT5_INC",       pathJoin(qt_dir, "include"))
setenv( "TACC_QT5_LIB",       pathJoin(qt_dir, "lib"))
setenv( "TACC_QT5_BIN",       pathJoin(qt_dir, "bin"))
local gcc_dir                              = "/opt/apps/gcc/6.3.0"
prepend_path( "PATH"                     , pathJoin(gcc_dir,"bin"       )               )
prepend_path( "LD_LIBRARY_PATH"          , pathJoin(gcc_dir,"lib"       )               )
prepend_path( "LD_LIBRARY_PATH"          , pathJoin(gcc_dir,"lib64"     )               )
prepend_path( "INCLUDE"                  , pathJoin(gcc_dir,"include"   )               )

help (
[[
Singularity is not installed and should not be run on the login nodes.

A functional Singularity module is available on the compute nodes. Submit
Singularity job scripts to the queue with 'sbatch'. If you would like to run
Singularity interactively, please start an interactive session with 'idev'.

[login]\$ idev
[compute]\$ singularity run container.img

#############################################################################

Images and layers are now cached to $STOCKYARD/singularity_cache. All images
created with singularity pull will be deposited to that location, and can
only be controlled by changing the cache location. We recommend running with
the container url

singularity exec docker://ubuntu:xenial echo "This works"

or copying the pulled container to a different location

singularity pull docker://ubuntu:xenial
cp $STOCKYARD/singularity_cache/ubuntu-xenial.simg $SCRATCH/
singularity exec $SCRATCH/ubuntu-xenial.simg echo "This also works"

#############################################################################

               OverlayFS is disabled on tacc-singularity

tacc-singularity utilizes the more secure underlay method automatically mount
shared filesystems and any user-specified locations. This means you no longer
need to include directories like

  /work and /scratch

in your images, but still cannot utilize advanced overlay-specific features.

#############################################################################

Additional Documentation

- Singularity Main - http://singularity.lbl.gov
- TACC-Singularity - https://github.com/TACC/TACC-Singularity

Version 2.6.0
]])

whatis("Name: tacc-singularity")
whatis("Version: 2.6.0")
whatis("Category: applications, virtualization")
whatis("Keywords: virtualization, applications")
whatis("Description: Application and environment virtualization")
whatis("URL: http://singularity.lbl.gov")

prepend_path("PATH",		"/opt/apps/tacc-singularity/2.6.0/bin")
prepend_path("LD_LIBRARY_PATH",	"/opt/apps/tacc-singularity/2.6.0/lib64")
prepend_path("MANPATH",		"/opt/apps/tacc-singularity/2.6.0/share/man")

setenv("TACC_SINGULARITY_DIR",	"/opt/apps/tacc-singularity/2.6.0")
setenv("TACC_SINGULARITY_EXAMPLES","/opt/apps/tacc-singularity/2.6.0/share/singularity-2.6.0/examples")
setenv("TACC_SINGULARITY_BIN",	"/opt/apps/tacc-singularity/2.6.0/bin")
setenv("TACC_SINGULARITY_ETC",	"/opt/apps/tacc-singularity/2.6.0/etc")
setenv("TACC_SINGULARITY_INC",	"/opt/apps/tacc-singularity/2.6.0/include")
setenv("TACC_SINGULARITY_LIB",	"/opt/apps/tacc-singularity/2.6.0/lib64")
setenv("TACC_SINGULARITY_LEXE",	"/opt/apps/tacc-singularity/2.6.0/libexec")

-- Reduce network load on LS5
if os.getenv("TACC_SYSTEM") == "ls5" then
	setenv("SINGULARITY_PYTHREADS", 2)
	depends_on("libarchive/3.3.2")
else
	setenv("SINGULARITY_PYTHREADS", 9)
end
-- Cache layers on stockyard instead of HOME
setenv("SINGULARITY_CACHEDIR",  os.getenv("STOCKYARD") .. "/singularity_cache")
-- Load bash completion
if (myShellName() == "bash") then
	execute{cmd="source ".. "/opt/apps/tacc-singularity/2.6.0/etc/bash_completion.d/singularity", modeA={"load"}}
end
-- Ensure a working python
try_load("python2")
if (isloaded("python2")) then
	depends_on("python2")
else
	depends_on("python")
end
prereq_any("python","python2")

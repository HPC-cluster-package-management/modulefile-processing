local help_message = [[
The deeptools module file defines the following environment variables:

 - TACC_DEEPTOOL_DIR
 - TACC_DEEPTOOL_BIN
 - TACC_DEEPTOOL_LIB
 - TACC_DEEPTOOL_INC

for the location of the deeptools distribution.

Documentation: https://github.com/deeptools/deepTools

Version 3.1.0
]]

help(help_message,"\n")

whatis("Name: deeptools")
whatis("Version: 3.1.0")
whatis("Category: computational biology, genomics")
whatis("Keywords: Biology, Genomics")
whatis("Description: User-friendly tools for exploring deep-sequencing data")
whatis("URL: https://github.com/deeptools/deepTools")

prepend_path("PATH",		"/home1/apps/deeptools/3.1.0/bin")
prepend_path("LD_LIBRARY_PATH",	"/home1/apps/deeptools/3.1.0/lib")
prepend_path("MANPATH",		"/home1/apps/deeptools/3.1.0/share/man")
prepend_path("PYTHONPATH",	"/home1/apps/deeptools/3.1.0/lib/python2.7/site-packages")
setenv("TACC_DEEPTOOL_DIR",     "/home1/apps/deeptools/3.1.0")
setenv("TACC_DEEPTOOL_BIN",	"/home1/apps/deeptools/3.1.0/bin")
setenv("TACC_DEEPTOOL_LIB",	"/home1/apps/deeptools/3.1.0/lib")

depends_on("python2/2.7.14")

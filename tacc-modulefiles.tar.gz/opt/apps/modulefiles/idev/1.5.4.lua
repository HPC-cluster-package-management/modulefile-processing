local help_message = [[
The idev modulefile defines the following environment variables:
TACC_IDEV_DIR (for the location of the idev command and idev_utilities).
#
The latest version (1.5.4) of  idev is in the /usr/bin directory.
At TACC /usr/bin is in the default PATH.  It is NOT necessary
to have the idev module loaded to use idev.

Purpose: For developing MPI or GPU code interactively.
Features:
Allows user to work directly on a compute node:
  You can execute the MPI ibrun command interactively.
  You can execute cuda code interactively (Stampede/Lonestar/Longhorn).

Usage:
        idev

(First time: users with multiple accounts  must select default account.)


Idev works for bash and tcsh shells (may not work for zsh).
Idev uses a job submission to obtain a node(s) for an interactive session.
Exiting the idev shell on the compute node will delete the job.
You can run multiple idev sessions.
Command line options allow you to change the default resources 
for the batch job (number of cores, time, queue, etc.) .

For details, execute: 

        idev -help

See help for setting defaults for account, queue and time.
]]

help(help_message,"\n")

whatis("Name: idev")
whatis("Version: 1.5.4")
whatis("Category: utility, development")
whatis("URL: http://www.tacc.utexas.edu")
whatis("Description: Interactive Access to Compute Node(s) for Development via Batch System")


local idev_dir="/usr/bin"

setenv("TACC_IDEV_DIR",idev_dir)


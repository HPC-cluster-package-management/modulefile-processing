
local help_message=[[
The tacc-launcher module file defines the environment variable:
$TACC_LAUNCHER_DIR for the location of the TACC Parametric 
Job Launcher which is a simple utility for submitting multiple
serial applications simultaneously.

For more information on using the Launcher, please consult
the README.launcher file located in $TACC_LAUNCHER_DIR

Version 3.2
]]

help(help_message,"\n")

whatis ("Name: TACC Parametric Job Launcher")
whatis ("Version: 3.2")
whatis ("Category: utility, runtime support")
whatis ("Keywords: System, Utility, Tools")
whatis ("Description: Utility for starting parametric job sweeps")

local launcher_dir="/opt/apps/launcher/launcher-3.2"
local launcher_plugin_dir="/opt/apps/launcher/launcher-3.2/plugins"
setenv("TACC_LAUNCHER_DIR", launcher_dir)
setenv("LAUNCHER_DIR", launcher_dir)
setenv("LAUNCHER_PLUGIN_DIR", launcher_plugin_dir)
setenv("LAUNCHER_RMI", "SLURM")



help(
[[
The module loads TACC SanityTool for you.
Version: 1.4

You can run the command "sanitycheck" to examine your current environment settings on Stampede, Lonestar, or Maverick.
If you encounter any problems, please send an email to siliu@tacc.utexas.edu with your user id and error messages.
Please also contact siliu@tacc.utexas.edu, if you have any other concerns or require additional tests.


]]
)

whatis("Name: SanityTool")
whatis("Version: 1.4")
whatis("Category: TACC HPC Tools")

local sanitypath = "/home1/apps/sanitytool/1.4"
append_path("PATH",sanitypath)
setenv("TACC_SANITYTOOL_DIR", "/home1/apps/sanitytool/1.4")


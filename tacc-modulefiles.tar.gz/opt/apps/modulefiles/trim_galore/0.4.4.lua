local help_message = [[
The trim_galore module file defines the following environment variables:

 - TACC_TRIM_GAL_DIR

for the location of the trim_galore distribution.

Documentation: https://www.bioinformatics.babraham.ac.uk/projects/trim_galore/

Version 0.4.4
]]

help(help_message,"\n")

whatis("Name: tacc-trim_galore-0.4.4")
whatis("Version: 0.4.4")
whatis("Category: computational biology, genomics")
whatis("Keywords: Biology, Genomics, QC, QA")
whatis("Description: Consistent quality and adapter trimming for RRBS or standard FastQ files")
whatis("URL: https://www.bioinformatics.babraham.ac.uk/projects/trim_galore/")

prepend_path("PATH",		"/home1/apps/trim_galore/0.4.4")

setenv("TACC_TRIM_GAL_DIR",     "/home1/apps/trim_galore/0.4.4")

always_load("cutadapt","fastqc")
prereq("cutadapt","fastqc")

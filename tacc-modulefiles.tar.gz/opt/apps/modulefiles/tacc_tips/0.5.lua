help(
[[
The binary is called showTip.  You can do:

   $ showTip -n 14

to see tip 14 again.

To show all tips do:

   $ showTip -a

To disable do:

   $ touch ~/.no.tips

Version 0.5
]]
)

whatis("Name: Tacc Tips")
whatis("Version: 0.5")
whatis("Category: User training")
whatis("Keywords: Training ")
whatis("URL: http://tacc.utexas.edu")
whatis("Description: Tips generated at each login.")


prepend_path("PATH",              "/opt/apps/tacc_tips/0.5/bin")
setenv (     "TACC_TIPS_DIR", "/opt/apps/tacc_tips/0.5/")
setenv (     "TACC_TIPS_BIN", "/opt/apps/tacc_tips/0.5/bin")


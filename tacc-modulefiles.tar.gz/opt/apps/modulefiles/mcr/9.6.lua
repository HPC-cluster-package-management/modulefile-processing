
help(
[[
The MATLAB Compiler Runtime (MCR) is a standalone set of
shared libraries that enables the execution of compiled
MATLAB applications or components on computers that do
not have MATLAB installed. When used together, MATLAB,
MATLAB Compiler, and the MCR enable you to create and
distribute numerical applications or software components
quickly and securely.

Version v9.6
]]
)

whatis("Name: MCR")
whatis("Version: v9.6")
whatis("Category: library, mathematics")
whatis("Keywords: Library, Mathematics, Tools")
whatis("URL: http://www.mathworks.com/")
whatis("Description: Matlab v9.6 Compiler Runtime from MathWorks")

append_path("PATH", "/home1/apps/mcr/9.6/bin")
append_path("LD_LIBRARY_PATH", "/home1/apps/mcr/9.6/bin/glnxa64")
append_path("LD_LIBRARY_PATH", "/home1/apps/mcr/9.6/runtime/glnxa64")
append_path("LD_LIBRARY_PATH", "/home1/apps/mcr/9.6/bin/glnxa64")
append_path("LD_LIBRARY_PATH", "/home1/apps/mcr/9.6/sys/os/glnxa64")
append_path("LD_LIBRARY_PATH", "/home1/apps/mcr/9.6/sys/java/jre/glnxa64/jre/lib/amd64/server")
append_path("LD_LIBRARY_PATH", "/home1/apps/mcr/9.6/sys/java/jre/glnxa64/jre/lib/amd64")

setenv ("TACC_MCR_DIR", "/home1/apps/mcr/9.6")
setenv ("XAPPLRESDIR", "/home1/apps/mcr/9.6/X11/app-defaults")


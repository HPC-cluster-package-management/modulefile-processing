help(
[[
The xalt module collects system usage data.

Version 2.6.5
]]
)

whatis("Name: XALT")
whatis("Version: 2.6.5")
whatis("Category: tools")
whatis("Keywords: System, TOOLS")
whatis("URL: http://xalt.sf.net")
whatis("Description: Collects system usage data")

prepend_path{"PATH",                      "/opt/apps/xalt/xalt/bin", priority = 100}
prepend_path("COMPILER_PATH",             "/opt/apps/xalt/xalt/bin")
prepend_path("LD_PRELOAD",                "/opt/apps/xalt/xalt/lib64/libxalt_init.so")
setenv (     "TACC_XALT_DIR",         "/opt/apps/xalt/xalt/")
setenv (     "TACC_XALT_BIN",         "/opt/apps/xalt/xalt/bin")
setenv (     "XALT_EXECUTABLE_TRACKING",  "yes")
setenv (     "XALT_SCALAR_SAMPLING",      "yes")

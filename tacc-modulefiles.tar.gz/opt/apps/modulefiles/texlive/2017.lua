local helpMsg = [[
Here is texlive for 2017
]]

help(helpMsg)

local base = "/home1/apps/texlive/2017"
prepend_path("MANPATH",  pathJoin(base,"texmf-dist/doc/man"))
prepend_path("INFOPATH", pathJoin(base,"texmf-dist/doc/info"))
prepend_path("PATH",     pathJoin(base,"bin/x86_64-linux"))



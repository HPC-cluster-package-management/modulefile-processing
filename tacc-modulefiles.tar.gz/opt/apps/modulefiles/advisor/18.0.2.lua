local advisor_dir   = "/opt/intel/advisor_2018.2.0.551025"

whatis( "Name: advisor" )
whatis( "Version: 18.0.2" )
whatis( "Category: performance analysis" )
whatis( "Keywords: System, Utility, Tools" )
whatis( "Description: Intel Advisor" )
whatis( "URL: https://software.intel.com/en-us/intel-advisor-xe" )

prepend_path(       "PATH",       pathJoin( advisor_dir, "bin64"     )   )
append_path(        "PYTHONPATH", pathJoin( advisor_dir, "pythonapi" )   )

setenv( "ADVISOR_2018_DIR", advisor_dir                          )

setenv( "TACC_ADVISOR_DIR", advisor_dir                          )
setenv( "TACC_ADVISOR_BIN", pathJoin( advisor_dir, "bin64"   )   )
setenv( "TACC_ADVISOR_LIB", pathJoin( advisor_dir, "lib64"   )   )
setenv( "TACC_ADVISOR_INC", pathJoin( advisor_dir, "include" )   )

help(
[[

Intel Advisor focuses on vector optimization and thread prototyping.

For detailed info, consult the extensive documentation in
$TACC_ADVISOR_DIR/documentation or online at
software.intel.com/en-us/intel-advisor-xe.
See also software.intel.com/en-us/articles/advisor-tutorials.

To see the exact effect of loading the module, execute "module show advisor".

Version 18.0.2  (file version 18.0.2)

]]
)
  

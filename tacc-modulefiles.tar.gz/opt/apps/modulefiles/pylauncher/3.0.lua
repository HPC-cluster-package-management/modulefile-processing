local help_msg=[[
The PYLAUNCHER module defines the following environment variables:
TACC_PYLAUNCHER_DIR, TACC_PYLAUNCHER_DOC, 
for the location of the PYLAUNCHER distribution, and documentation
respectively.

Usage:
  import pylauncher3
and use one of the launcher classes. See the examples 
directory for inspiration. Preferably used with python3.
]]

--help(help_msg)
help(help_msg)

whatis("Name: pylauncher")
whatis("Version: 3.0")

-- Create environment variables.
local launcher_dir           = "/opt/apps/pylauncher/3.0"

prepend_path(    "PYTHONPATH",     launcher_dir )
setenv( "TACC_PYLAUNCHER_DIR",                launcher_dir)
setenv( "TACC_PYLAUNCHER_DOC",       pathJoin(launcher_dir, "docs"))

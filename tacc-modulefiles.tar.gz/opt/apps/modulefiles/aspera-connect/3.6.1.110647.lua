local help_message = [[
The aspera-connect module file defines the following environment variables:

 - TACC_ASPERA_DIR
 - TACC_ASPERA_ASCP - the location of the ascp program
 - TACC_ASPERA_OPENSSH - the location of the openssh key

for the location of the aspera-connect distribution.

Documentation: http://download.asperasoft.com/download/docs/ascp/3.5.2/html/index.html#dita/ascp_usage.html

Version 3.6.1.110647
]]

help(help_message,"\n")

whatis("Name: aspera-connect")
whatis("Version: 3.6.1.110647")
whatis("Category: computational biology, genomics")
whatis("Keywords: Biology, Genomics, transfer, ncbi, utility")
whatis("Description: Aspera Connect client")
whatis("URL: http://download.asperasoft.com/download/docs/ascp/3.5.2/html/index.html#dita/ascp_usage.html")

setenv("TACC_ASPERA_DIR",	"/home1/apps/aspera-connect/3.6.1.110647/bin")
setenv("TACC_ASPERA_ASCP",	"/home1/apps/aspera-connect/3.6.1.110647/bin/ascp")
setenv("TACC_ASPERA_KEY",	"/home1/apps/aspera-connect/3.6.1.110647/etc/asperaweb_id_dsa.openssh")

prepend_path("PATH",		"/home1/apps/aspera-connect/3.6.1.110647/bin")

local help_message = [[
The fastx_toolkit module file defines the following environment variables:

 - TACC_FASTX_TO_DIR
 - TACC_FASTX_TO_BIN
 - TACC_FASTX_TO_LIB
 - TACC_FASTX_TO_INC

for the location of the fastx_toolkit distribution.

Documentation: http://hannonlab.cshl.edu/fastx_toolkit/

Version 0.0.14
]]

help(help_message,"\n")

whatis("Name: tacc-fastx_toolkit-0.0.14")
whatis("Version: 0.0.14")
whatis("Category: computational biology, genomics")
whatis("Keywords: Biology, Genomics")
whatis("Description: Command line tools for Short-Reads FASTA/FASTQ files preprocessing.")
whatis("URL: http://hannonlab.cshl.edu/fastx_toolkit/")

prepend_path("PATH",		"/home1/apps/fastx_toolkit/0.0.14/bin")
prepend_path("LD_LIBRARY_PATH",	"/home1/apps/fastx_toolkit/0.0.14/libgtextutils-0.7/lib")

setenv("TACC_FASTX_TO_DIR",     "/home1/apps/fastx_toolkit/0.0.14")
setenv("TACC_FASTX_TO_BIN",	"/home1/apps/fastx_toolkit/0.0.14/bin")
setenv("TACC_FASTX_TO_LIB",	"/home1/apps/fastx_toolkit/0.0.14/libgtextutils-0.7/lib")
setenv("TACC_FASTX_TO_INC",	"/home1/apps/fastx_toolkit/0.0.14/libgtextutils-0.7/include")

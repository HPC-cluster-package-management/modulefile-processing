local help_message = [[
The sratoolkit module file defines the following environment variables:

 - TACC_SRATOOLK_DIR
 - TACC_SRATOOLK_EXAMPLE - example files

To improve download speed, the prefetch command has been aliased to always
use aspera. We also suggest running

$ scratch_cache

to change your cache directory to use the scratch filesystem.

Documentation can be found online at https://github.com/ncbi/sra-tools/wiki

Version 2.8.2
]]

help(help_message,"\n")

whatis("Name: sratoolkit")
whatis("Version: 2.8.2")
whatis("Category: computational biology, genomics")
whatis("Keywords: Biology, Genomics, archive, ncbi")
whatis("Description: The SRA Toolkit and SDK from NCBI is a collection of tools and libraries for using data in the INSDC Sequence Read Archives")
whatis("URL: https://github.com/ncbi/sra-tools")

setenv("TACC_SRATOOLK_DIR",	"/home1/apps/sratoolkit/2.8.2")
setenv("TACC_SRATOOLK_EXAMPLE",	pathJoin("/home1/apps/sratoolkit/2.8.2","example"))

prepend_path("PATH",		pathJoin("/home1/apps/sratoolkit/2.8.2","bin"))
set_alias("prefetch","prefetch -a \"$TACC_ASPERA_ASCP|$TACC_ASPERA_KEY\"")
always_load("aspera-connect")

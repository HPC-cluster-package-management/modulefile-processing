help(
[[
RStudio Server enables you to provide a browser based
interface to a version of R running on a remote Linux
server, bringing the power and productivity of the
RStudio IDE to server-based deployments of R.

Do not run rstudio on the login node, please use ssh port
forwarding. Or the sample job submission script here:
/share/doc/slurm/rstudio.slurm

Version 1.0.153
]]
)

whatis("Name: Rstudio")
whatis("Version: 1.0.153")
whatis("Category: Applications, Statistics, Graphics")
whatis("Keywords: Applications, Statistics, Graphics, Scripting Language")
whatis("URL: https://www.rstudio.com/")
whatis("Description: Powerful IDE for R")

--
-- Create environment variables.
--
local rstudio_dir   = "/opt/apps/Rstudio/1.0.153"
local rstudio_bin   = "/opt/apps/Rstudio/1.0.153/bin"
local rstudio_inc   = "/opt/apps/Rstudio/1.0.153/include"
local rstudio_lib   = "/opt/apps/Rstudio/1.0.153/lib"
local rstudio_man   = "/opt/apps/Rstudio/1.0.153/share/man:/opt/apps/Rstudio/1.0.153/man"

setenv("TACC_RSTUDIO_DIR", rstudio_dir)
setenv("TACC_RSTUDIO_BIN", rstudio_bin)
setenv("TACC_RSTUDIO_LIB", rstudio_lib)

append_path("PATH", rstudio_bin)
append_path("LD_LIBRARY_PATH", rstudio_lib)

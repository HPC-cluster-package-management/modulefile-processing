local help_message = [[
The GNU Compiler Collection 6.3.0 includes front ends for C, C++,
Objective-C, Fortran, Java, Ada, and Go, as well as libraries for these
languages (libstdc++, libgcj,...). GCC was originally written as the compiler
for the GNU operating system. The GNU system was developed to be 100% free
software, free in the sense that it respects the users freedom.

This module loads GCC Compiler variables.
The command directory is added to PATH.
The library directory is added to LD_LIBRARY_PATH.
The include directory is added to INCLUDE.
The man     directory is added to MANPATH.

Also Defined:
TACC_GCC_DIR   = GCC base             directory
TACC_GCC_BIN   = GCC binary           directory
TACC_GCC_LIB   = GCC library          directory
TACC_GCC_LIB64 = GCC library (64-bit) directory
TACC_GCC_INC   = GCC include          directory

Version 6.3.0
]]

help(help_message,"\n")

whatis("Name: GCC Compilers")
whatis("Version: 6.3.0")
whatis("Category: compiler")
whatis("Keywords: System, compiler")
whatis("URL: http://gcc.gnu.org")

-- Create environment variables
local gcc_dir                              = "/opt/apps/gcc/6.3.0"
prepend_path( "PATH"                     , pathJoin(gcc_dir,"bin"       )               )
prepend_path( "LD_LIBRARY_PATH"          , pathJoin(gcc_dir,"lib"       )               )
prepend_path( "LD_LIBRARY_PATH"          , pathJoin(gcc_dir,"lib64"     )               )
prepend_path( "MANPATH"                  , pathJoin(gcc_dir,"share/man" )               )
prepend_path( "INCLUDE"                  , pathJoin(gcc_dir,"include"   )               )
prepend_path( "MODULEPATH"               , "/opt/apps/gcc6_3/modulefiles" )
setenv(       "GCC_LIB"        , pathJoin(gcc_dir,"lib64"     )               )
setenv(       "TACC_GCC_DIR"   , gcc_dir                                      )
setenv(       "TACC_GCC_BIN"   , pathJoin(gcc_dir,"bin"       )               )
setenv(       "TACC_GCC_LIB"   , pathJoin(gcc_dir,"lib"       )               )
setenv(       "TACC_GCC_LIB64" , pathJoin(gcc_dir,"lib64"     )               )
setenv(       "TACC_GCC_INC"   , pathJoin(gcc_dir,"include"   )               )

family("compiler")
